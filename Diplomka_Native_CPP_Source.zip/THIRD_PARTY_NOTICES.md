# Third-party components

- **OpenCV 4.10.0**: used for classical image processing, HOG/SVM pedestrian proposals, ORB feature matching, optical flow and geometry. The Android workflow downloads the upstream Android SDK at build time; the Raspberry Pi build links system OpenCV packages. Keep and review the upstream license/notice files when redistributing binaries.
- **Dear ImGui v1.91.6**: immediate-mode UI library, fetched by CMake during the build. Upstream license: MIT.
- **Android NDK / NativeActivity / NDK Camera / EGL / OpenGL ES**: Android platform APIs.
- **Raspberry Pi camera tools**: `rpicam-vid` from Raspberry Pi OS packages.

This project does not download, bundle or run NCNN, YOLO, neural-network weights or other neural inference models. OpenCV's built-in HOG pedestrian detector is a classical HOG + linear-SVM detector.
