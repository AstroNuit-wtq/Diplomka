# Third-party components and model notices

- **Tencent NCNN**: native neural-network inference framework. The project downloads the Android CPU package from Tencent/ncnn releases during CI. Review the license and notices in the upstream release before redistribution.
- **Dear ImGui**: immediate-mode UI library. CI fetches version `v1.91.6` during CMake configuration. Its upstream license is MIT.
- **YOLOv8n / YOLOv8n-pose weights**: CI fetches converted NCNN assets from `nihui/ncnn-android-yolov8`. The underlying Ultralytics YOLO model licensing must be reviewed before distributing the APK. Ultralytics model/software licensing may be AGPL-3.0 or a commercial license depending on the use case. Do not assume that converting weights to NCNN removes the original model license obligations.
- **Android NDK / NativeActivity / NDK Camera**: Android platform APIs.

The source ZIP does not redistribute the model binaries. The CI workflow downloads them into the temporary build tree and bundles them into the APK.
