#include "session_logger.h"

#include <cassert>
#include <cstring>
#include <string>

extern "C" int __android_log_write(int, const char*, const char*) { return 0; }

int main() {
    appLogWrite(4, "Test", "application started");
    appLogWrite(5, "Camera2", "session configure failed code=%d", 3);
    appLogWrite(6, "Torch", "flash request failed");
    const std::string log = appLogSnapshot();
    assert(log.find("DIPLOMKA APPLICATION SESSION LOG") != std::string::npos);
    assert(log.find("application started") != std::string::npos);
    assert(log.find("session configure failed code=3") != std::string::npos);
    assert(log.find("flash request failed") != std::string::npos);
    assert(log.find("BEGIN FULL SESSION LOG") != std::string::npos);
    assert(appLogLineCount() == 3);
    return 0;
}
