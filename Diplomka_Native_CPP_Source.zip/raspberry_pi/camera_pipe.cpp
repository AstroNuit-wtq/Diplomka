#include "camera_pipe.h"

#include <algorithm>
#include <cerrno>
#include <csignal>
#include <cstring>
#include <poll.h>
#include <string>
#include <sys/wait.h>
#include <unistd.h>
#include <utility>

namespace {
uint8_t clampByte(int value) {
    return static_cast<uint8_t>(std::max(0, std::min(255, value)));
}
}

RaspberryPiCamera::~RaspberryPiCamera() { stop(); }

std::string RaspberryPiCamera::lastError() const {
    std::lock_guard<std::mutex> lock(errorMutex_);
    return lastError_;
}

bool RaspberryPiCamera::start(FrameConsumer consumer, int width, int height, int fps) {
    if (running_.load()) return true;
    stop();
    width_ = std::max(160, width - (width % 2));
    height_ = std::max(120, height - (height % 2));
    fps_ = std::clamp(fps, 1, 30);
    consumer_ = std::move(consumer);
    frames_.store(0);
    {
        std::lock_guard<std::mutex> lock(errorMutex_);
        lastError_.clear();
    }

    int descriptors[2] = {-1, -1};
    if (pipe(descriptors) != 0) {
        std::lock_guard<std::mutex> lock(errorMutex_);
        lastError_ = std::string("pipe(): ") + std::strerror(errno);
        return false;
    }

    childPid_ = fork();
    if (childPid_ < 0) {
        close(descriptors[0]); close(descriptors[1]);
        std::lock_guard<std::mutex> lock(errorMutex_);
        lastError_ = std::string("fork(): ") + std::strerror(errno);
        return false;
    }
    if (childPid_ == 0) {
        dup2(descriptors[1], STDOUT_FILENO);
        close(descriptors[0]);
        close(descriptors[1]);
        const std::string widthArg = std::to_string(width_);
        const std::string heightArg = std::to_string(height_);
        const std::string fpsArg = std::to_string(fps_);
        execlp("rpicam-vid", "rpicam-vid", "--timeout", "0", "--codec", "yuv420",
               "--width", widthArg.c_str(), "--height", heightArg.c_str(),
               "--framerate", fpsArg.c_str(), "--nopreview", "--output", "-", static_cast<char*>(nullptr));
        _exit(127);
    }

    close(descriptors[1]);
    pipeFd_ = descriptors[0];
    running_.store(true);
    thread_ = std::thread(&RaspberryPiCamera::captureLoop, this);
    return true;
}

void RaspberryPiCamera::stop() {
    running_.store(false);
    if (childPid_ > 0) kill(childPid_, SIGTERM);
    if (thread_.joinable()) thread_.join();
    if (pipeFd_ >= 0) {
        close(pipeFd_);
        pipeFd_ = -1;
    }
    if (childPid_ > 0) {
        int status = 0;
        waitpid(childPid_, &status, 0);
        childPid_ = -1;
    }
    consumer_ = nullptr;
}

bool RaspberryPiCamera::readExact(uint8_t* output, size_t length) {
    size_t offset = 0;
    while (running_.load() && offset < length) {
        pollfd descriptor{};
        descriptor.fd = pipeFd_;
        descriptor.events = POLLIN | POLLHUP | POLLERR;
        const int ready = poll(&descriptor, 1, 500);
        if (ready < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (ready == 0) continue;
        if (descriptor.revents & (POLLIN | POLLHUP)) {
            const ssize_t count = read(pipeFd_, output + offset, length - offset);
            if (count <= 0) return false;
            offset += static_cast<size_t>(count);
        } else if (descriptor.revents & POLLERR) {
            return false;
        }
    }
    return offset == length;
}

std::vector<uint8_t> RaspberryPiCamera::yuv420ToRgba(const std::vector<uint8_t>& yuv, int width, int height) {
    const size_t ySize = static_cast<size_t>(width) * static_cast<size_t>(height);
    const size_t chromaSize = ySize / 4U;
    if (yuv.size() < ySize + 2U * chromaSize) return {};
    std::vector<uint8_t> rgba(ySize * 4U);
    const uint8_t* yPlane = yuv.data();
    const uint8_t* uPlane = yuv.data() + ySize;
    const uint8_t* vPlane = uPlane + chromaSize;
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const int yy = std::max(0, static_cast<int>(yPlane[static_cast<size_t>(y) * width + x]) - 16);
            const int chromaIndex = static_cast<size_t>(y / 2) * (width / 2) + (x / 2);
            const int u = static_cast<int>(uPlane[chromaIndex]) - 128;
            const int v = static_cast<int>(vPlane[chromaIndex]) - 128;
            const int c = 298 * yy;
            const size_t pixel = (static_cast<size_t>(y) * width + x) * 4U;
            rgba[pixel + 0] = clampByte((c + 409 * v + 128) >> 8);
            rgba[pixel + 1] = clampByte((c - 100 * u - 208 * v + 128) >> 8);
            rgba[pixel + 2] = clampByte((c + 516 * u + 128) >> 8);
            rgba[pixel + 3] = 255;
        }
    }
    return rgba;
}

void RaspberryPiCamera::captureLoop() {
    const size_t frameBytes = static_cast<size_t>(width_) * static_cast<size_t>(height_) * 3U / 2U;
    std::vector<uint8_t> yuv(frameBytes);
    while (running_.load()) {
        if (!readExact(yuv.data(), yuv.size())) {
            if (running_.load()) {
                std::lock_guard<std::mutex> lock(errorMutex_);
                lastError_ = "Поток rpicam-vid завершился или перестал передавать кадры";
            }
            running_.store(false);
            break;
        }
        auto rgba = yuv420ToRgba(yuv, width_, height_);
        if (rgba.empty()) continue;
        frames_.fetch_add(1);
        if (consumer_) consumer_(std::move(rgba), width_, height_);
    }
}
