#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="${DIPLOMKA_PI_BIN:-$ROOT/build-pi/diplomka-pi}"
if [[ ! -x "$BIN" ]]; then
  echo "Binary not found: $BIN" >&2
  echo "Run raspberry_pi/build_pi.sh first." >&2
  exit 2
fi
exec "$BIN" "$@"
