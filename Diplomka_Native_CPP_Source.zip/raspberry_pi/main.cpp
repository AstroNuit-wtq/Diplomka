#include <SDL.h>
#include <GLES3/gl3.h>

#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_opengl3.h"

#include "camera_pipe.h"
#include "../app/src/main/cpp/vision_engine.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstring>
#include <functional>
#include <unordered_map>
#include <cmath>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <utility>
#include <vector>

namespace {
constexpr int kFrameWidth = 640;
constexpr int kFrameHeight = 480;

struct FrameData {
    std::vector<uint8_t> rgba;
    int width = 0;
    int height = 0;
    uint64_t version = 0;
};

struct InferenceData {
    VisionFrame result;
    float latencyMs = 0.0f;
};

void setupMaterialYouStyle() {
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 22.0f;
    style.ChildRounding = 18.0f;
    style.FrameRounding = 16.0f;
    style.PopupRounding = 18.0f;
    style.ScrollbarRounding = 14.0f;
    style.GrabRounding = 14.0f;
    style.WindowPadding = ImVec2(16, 14);
    style.FramePadding = ImVec2(14, 11);
    style.ItemSpacing = ImVec2(9, 9);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.055f, 0.055f, 0.075f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.105f, 0.105f, 0.145f, 0.98f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.17f, 0.16f, 0.23f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.22f, 0.20f, 0.31f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.34f, 0.29f, 0.47f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.48f, 0.40f, 0.62f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.83f, 0.75f, 1.0f, 1.0f);
}

void glyphButton(const char* id, const char* label, bool active, const ImVec4& accent,
                 ImVec2 size, const std::function<void()>& action) {
    static std::unordered_map<std::string, double> pulse;
    ImGui::PushID(id);
    if (active) ImGui::PushStyleColor(ImGuiCol_Button, accent);
    const bool clicked = ImGui::Button(label, size);
    const ImVec2 min = ImGui::GetItemRectMin();
    const ImVec2 max = ImGui::GetItemRectMax();
    if (active) ImGui::PopStyleColor();
    ImGui::PopID();
    if (clicked) { pulse[id] = ImGui::GetTime(); action(); }
    const auto it = pulse.find(id);
    if (it != pulse.end()) {
        const float t = static_cast<float>((ImGui::GetTime() - it->second) / 0.6);
        if (t >= 0.0f && t < 1.0f) {
            const float alpha = 1.0f - t;
            ImDrawList* draw = ImGui::GetWindowDrawList();
            const ImU32 color = ImGui::ColorConvertFloat4ToU32(ImVec4(accent.x, accent.y, accent.z, alpha * 0.6f));
            draw->AddRect(min, max, color, 16.0f, ImDrawFlags_RoundCornersAll, 2.0f);
            const float x = min.x + (max.x - min.x) * t;
            draw->AddLine(ImVec2(x, min.y + 5), ImVec2(x, max.y - 5), color, 2.0f);
        }
    }
}

void drawOverlay(const FrameData& frame, const VisionFrame& vision, ImVec2 origin, ImVec2 size) {
    if (frame.rgba.empty()) return;
    ImDrawList* draw = ImGui::GetWindowDrawList();
    const float sx = size.x / static_cast<float>(frame.width);
    const float sy = size.y / static_cast<float>(frame.height);
    for (const auto& det : vision.detections) {
        const ImVec2 a(origin.x + det.box.left * sx, origin.y + det.box.top * sy);
        const ImVec2 b(origin.x + det.box.right * sx, origin.y + det.box.bottom * sy);
        draw->AddRect(a, b, IM_COL32(183, 166, 255, 255), 3.0f, 0, 2.0f);
        const std::string text = det.label + " " + std::to_string(static_cast<int>(det.confidence * 100.0f)) + "%";
        draw->AddText(ImVec2(a.x + 4, std::max(origin.y, a.y - 20)), IM_COL32(224, 214, 255, 255), text.c_str());
    }
}
}

int main(int argc, char** argv) {
    const std::string modelDir = argc > 1 ? argv[1] : "./models";
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) != 0) {
        SDL_Log("SDL_Init failed: %s", SDL_GetError());
        return 2;
    }

    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_Window* window = SDL_CreateWindow("Diplomka", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                           1280, 800, SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
    if (!window) {
        SDL_Log("SDL_CreateWindow failed: %s", SDL_GetError());
        SDL_Quit();
        return 2;
    }
    SDL_GLContext glContext = SDL_GL_CreateContext(window);
    if (!glContext) {
        SDL_Log("SDL_GL_CreateContext failed: %s", SDL_GetError());
        SDL_DestroyWindow(window); SDL_Quit(); return 2;
    }
    SDL_GL_MakeCurrent(window, glContext);
    SDL_GL_SetSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.Fonts->AddFontFromFileTTF("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18.0f, nullptr, io.Fonts->GetGlyphRangesCyrillic());
    setupMaterialYouStyle();
    ImGui_ImplSDL2_InitForOpenGL(window, glContext);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    VisionEngine vision;
    const bool detectorReady = vision.initializeFromDirectory(modelDir);
    RaspberryPiCamera camera;
    std::mutex frameMutex;
    FrameData latestFrame;
    std::mutex visionMutex;
    VisionFrame latestVision;
    std::atomic<bool> aiEnabled{true};
    std::atomic<bool> stopWorker{false};
    std::mutex inferenceMutex;
    std::condition_variable inferenceCv;
    std::optional<FrameData> pendingInference;
    std::thread inferenceThread([&]() {
        while (!stopWorker.load()) {
            FrameData frame;
            {
                std::unique_lock<std::mutex> lock(inferenceMutex);
                inferenceCv.wait(lock, [&]() { return stopWorker.load() || pendingInference.has_value(); });
                if (stopWorker.load()) return;
                frame = std::move(*pendingInference);
                pendingInference.reset();
            }
            if (!aiEnabled.load() || frame.rgba.empty()) continue;
            VisionFrame result = vision.processRgba(frame.rgba.data(), frame.width, frame.height, true, true);
            std::lock_guard<std::mutex> lock(visionMutex);
            latestVision = std::move(result);
        }
    });

    bool cameraWanted = true;
    bool showLog = true;
    bool expanded = true;
    bool running = false;
    bool quit = false;
    GLuint texture = 0;
    uint64_t uploadedVersion = 0;
    uint64_t frameNumber = 0;
    std::string status = detectorReady ? "Модель обнаружения загружена" : "Модель не найдена: проверь ./models";
    std::vector<std::string> logLines{status};
    FrameData displayFrame;

    auto startCamera = [&]() {
        cameraWanted = true;
        running = camera.start([&](std::vector<uint8_t>&& rgba, int width, int height) {
            FrameData copy;
            copy.width = width;
            copy.height = height;
            copy.version = ++frameNumber;
            copy.rgba = std::move(rgba);
            {
                std::lock_guard<std::mutex> lock(frameMutex);
                latestFrame = copy;
            }
            if (aiEnabled.load() && copy.version % 3 == 0) {
                std::lock_guard<std::mutex> lock(inferenceMutex);
                pendingInference = std::move(copy);
                inferenceCv.notify_one();
            }
        }, kFrameWidth, kFrameHeight, 15);
        status = running ? "Запущен rpicam-vid · ожидаю первый кадр" : "Не удалось запустить rpicam-vid: " + camera.lastError();
        logLines.push_back(status);
    };
    startCamera();

    while (!quit) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            ImGui_ImplSDL2_ProcessEvent(&event);
            if (event.type == SDL_QUIT) quit = true;
            if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) quit = true;
        }
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();

        int displayW = 0, displayH = 0;
        SDL_GL_GetDrawableSize(window, &displayW, &displayH);
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(ImVec2(static_cast<float>(displayW), static_cast<float>(displayH)));
        ImGui::Begin("Diplomka Main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
        running = camera.isRunning();
        if (cameraWanted && !running && camera.frameCount() == 0 && !camera.lastError().empty()) {
            status = "Камера остановилась: " + camera.lastError();
        }
        ImGui::TextColored(ImVec4(0.82f, 0.75f, 1.0f, 1.0f), "DIPLOMKA");
        ImGui::SameLine(); ImGui::TextDisabled("RASPBERRY PI 4B · NATIVE C++");
        const bool hasFrames = camera.frameCount() > 0;
        ImGui::SameLine(); ImGui::TextColored(hasFrames ? ImVec4(0.55f, 0.88f, 0.74f, 1) : ImVec4(1, 0.63f, 0.55f, 1), hasFrames ? "● LIVE" : "● WAIT");
        ImGui::BeginChild("status", ImVec2(0, 72), true);
        ImGui::TextWrapped("%s", status.c_str());
        ImGui::SameLine(); ImGui::TextDisabled("Кадры: %llu", static_cast<unsigned long long>(camera.frameCount()));
        ImGui::TextDisabled("Компаса/GPS нет в стандартной плате — подключи внешние датчики, если они нужны.");
        ImGui::EndChild();

        {
            std::lock_guard<std::mutex> lock(frameMutex);
            if (latestFrame.version > displayFrame.version) displayFrame = latestFrame;
        }
        const FrameData& frame = displayFrame;
        VisionFrame visionFrame;
        {
            std::lock_guard<std::mutex> lock(visionMutex);
            visionFrame = latestVision;
        }
        const float reserved = expanded ? 150.0f : 90.0f;
        const float logHeight = showLog ? 105.0f : 0.0f;
        const float viewHeight = std::max(250.0f, ImGui::GetContentRegionAvail().y - reserved - logHeight - 22.0f);
        ImGui::BeginChild("preview", ImVec2(0, viewHeight), true);
        const ImVec2 pos = ImGui::GetCursorScreenPos();
        const ImVec2 avail = ImGui::GetContentRegionAvail();
        if (!frame.rgba.empty()) {
            if (!texture) glGenTextures(1, &texture);
            glBindTexture(GL_TEXTURE_2D, texture);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            if (frame.version != uploadedVersion) {
                glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, frame.width, frame.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, frame.rgba.data());
                uploadedVersion = frame.version;
            }
            const float aspect = static_cast<float>(frame.width) / static_cast<float>(frame.height);
            ImVec2 imageSize(avail.x, avail.x / aspect);
            if (imageSize.y > avail.y) imageSize = ImVec2(avail.y * aspect, avail.y);
            ImGui::Image((ImTextureID)(intptr_t)texture, imageSize);
            drawOverlay(frame, visionFrame, pos, imageSize);
            glBindTexture(GL_TEXTURE_2D, 0);
            if (frame.version > 0) status = "Камера передаёт изображение";
        } else {
            ImGui::TextWrapped("Ожидание изображения с камеры Raspberry Pi. Установи rpicam-apps и подключи CSI-камеру.");
            if (!camera.lastError().empty()) ImGui::TextWrapped("%s", camera.lastError().c_str());
        }
        ImGui::EndChild();

        const auto toggleCamera = [&]() {
            if (cameraWanted) { cameraWanted = false; camera.stop(); running = false; status = "Камера остановлена"; }
            else startCamera();
        };
        const auto restartCamera = [&]() {
            camera.stop();
            running = false;
            startCamera();
        };
        if (expanded) {
            const float bw = (ImGui::GetContentRegionAvail().x - 3 * ImGui::GetStyle().ItemSpacing.x) / 3.0f;
            glyphButton("camera", cameraWanted ? "КАМЕРА · ON" : "КАМЕРА · OFF", cameraWanted, ImVec4(0.55f, 0.43f, 0.80f, 1), ImVec2(bw, 52), toggleCamera);
            ImGui::SameLine();
            glyphButton("ai", aiEnabled ? "ИИ · ON" : "ИИ · OFF", aiEnabled, ImVec4(0.35f, 0.66f, 0.63f, 1), ImVec2(bw, 52), [&]() { aiEnabled = !aiEnabled.load(); });
            ImGui::SameLine();
            glyphButton("log", showLog ? "СКРЫТЬ ЛОГ" : "ПОКАЗАТЬ ЛОГ", showLog, ImVec4(0.54f, 0.56f, 0.78f, 1), ImVec2(bw, 52), [&]() { showLog = !showLog; });
            glyphButton("restart", "ПЕРЕЗАПУСК КАМЕРЫ", false, ImVec4(0.48f, 0.24f, 0.30f, 1), ImVec2(bw * 2.0f + ImGui::GetStyle().ItemSpacing.x, 48), restartCamera);
        } else {
            glyphButton("camera_compact", cameraWanted ? "CAM" : "OFF", cameraWanted, ImVec4(0.55f, 0.43f, 0.80f, 1), ImVec2(76, 48), toggleCamera);
            ImGui::SameLine(); glyphButton("ai_compact", aiEnabled ? "AI" : "AI OFF", aiEnabled, ImVec4(0.35f, 0.66f, 0.63f, 1), ImVec2(76, 48), [&]() { aiEnabled = !aiEnabled.load(); });
            ImGui::SameLine(); glyphButton("log_compact", "LOG", showLog, ImVec4(0.54f, 0.56f, 0.78f, 1), ImVec2(76, 48), [&]() { showLog = !showLog; });
            ImGui::SameLine(); glyphButton("restart_compact", "↻", false, ImVec4(0.48f, 0.24f, 0.30f, 1), ImVec2(58, 48), restartCamera);
        }
        ImGui::SameLine();
        if (ImGui::Button(expanded ? "‹" : "›", ImVec2(48, 48))) expanded = !expanded;

        if (showLog) {
            ImGui::BeginChild("log", ImVec2(0, 88), true);
            ImGui::TextColored(ImVec4(0.82f, 0.75f, 1.0f, 1.0f), "ЖУРНАЛ");
            for (const auto& line : logLines) ImGui::TextWrapped("• %s", line.c_str());
            ImGui::EndChild();
        }
        ImGui::End();

        ImGui::Render();
        glViewport(0, 0, displayW, displayH);
        glClearColor(0.055f, 0.055f, 0.075f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        SDL_GL_SwapWindow(window);
        SDL_Delay(1);
    }

    camera.stop();
    stopWorker.store(true);
    inferenceCv.notify_all();
    if (inferenceThread.joinable()) inferenceThread.join();
    if (texture) glDeleteTextures(1, &texture);
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    SDL_GL_DeleteContext(glContext);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
