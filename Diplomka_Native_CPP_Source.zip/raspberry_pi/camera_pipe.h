#pragma once

#include <atomic>
#include <cstdint>
#include <cstddef>
#include <string>
#include <functional>
#include <mutex>
#include <thread>
#include <vector>
#include <sys/types.h>

class RaspberryPiCamera {
public:
    using FrameConsumer = std::function<void(std::vector<uint8_t>&&, int, int)>;

    RaspberryPiCamera() = default;
    ~RaspberryPiCamera();
    bool start(FrameConsumer consumer, int width = 640, int height = 480, int fps = 15);
    void stop();
    bool isRunning() const { return running_.load(); }
    uint64_t frameCount() const { return frames_.load(); }
    std::string lastError() const;

private:
    void captureLoop();
    bool readExact(uint8_t* output, size_t length);
    static std::vector<uint8_t> yuv420ToRgba(const std::vector<uint8_t>& yuv, int width, int height);

    std::atomic<bool> running_{false};
    std::atomic<uint64_t> frames_{0};
    int pipeFd_ = -1;
    pid_t childPid_ = -1;
    int width_ = 640;
    int height_ = 480;
    int fps_ = 15;
    std::thread thread_;
    FrameConsumer consumer_;
    mutable std::mutex errorMutex_;
    std::string lastError_;
};
