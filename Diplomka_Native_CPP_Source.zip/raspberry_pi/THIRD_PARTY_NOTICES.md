# Third-party notices — Raspberry Pi build

- **OpenCV 4.x** is linked from the Raspberry Pi OS system packages. Its license and copyright notices are provided by the installed OpenCV distribution.
- **Dear ImGui v1.91.6** is fetched by CMake from the upstream project during the initial build. Dear ImGui is distributed under the MIT license; see the upstream `LICENSE.txt` included in the fetched source tree.
- **SDL2 / OpenGL ES** are linked from Raspberry Pi OS system packages and retain their upstream licenses.

This Raspberry Pi package does not include NCNN, YOLO weights, neural-network model files, or model download steps.
