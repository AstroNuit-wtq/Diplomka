#pragma once

#include <opencv2/core.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/video/tracking.hpp>

#include <cstdint>
#include <chrono>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <vector>

struct PiDetection {
    cv::Rect box;
    std::string label;
    float confidence = 0.0f;
    bool isPerson = false;
    bool isVehicleCandidate = false;
};

struct MapWaypoint {
    int id = -1;
    cv::Point2f position;
    std::vector<int> neighbors;
};

class RouteMap {
public:
    bool loadImage(const std::string& path, std::string& error);
    bool loadWaypoints(const std::string& path, std::string& error);
    bool hasImage() const { return !imageBgr_.empty(); }
    bool hasWaypoints() const { return !waypoints_.empty(); }
    const cv::Mat& imageBgr() const { return imageBgr_; }
    const std::string& imagePath() const { return imagePath_; }
    const std::vector<MapWaypoint>& waypoints() const { return waypoints_; }
    std::optional<int> nearestWaypoint(const cv::Point2f& mapPosition);
    bool markReached(int id);
    std::optional<int> nextWaypoint() const;
    bool isReached(int id) const;
    void resetProgress();

private:
    cv::Mat imageBgr_;
    std::string imagePath_;
    std::vector<MapWaypoint> waypoints_;
    std::set<int> reached_;
    int currentWaypoint_ = -1;
    int nextWaypoint_ = -1;
};

struct PiVisionResult {
    std::vector<PiDetection> detections;
    std::vector<cv::Rect> staticObjects;
    std::vector<cv::Rect> movingObjects;
    std::vector<cv::Vec4i> yellowLines;
    std::vector<cv::Rect> curbs;

    bool stopSignal = false;
    bool bypassSelected = false;
    bool hasTarget = false;
    cv::Point target;
    cv::Point2f mapPosition;
    bool mapLocalized = false;
    bool hasMapTarget = false;
    cv::Point mapTarget;
    int nearestWaypointId = -1;

    float roadWidthPixels = 0.0f;
    float opticalFlowPixelsPerSecond = 0.0f;
    float travelledPixels = 0.0f;
    float processingMs = 0.0f;

    std::string direction = "ОЖИДАНИЕ";
    std::string stopReason;
    std::string weather = "Оценка ожидает кадры";
    std::string mapStatus = "Карта не загружена";
};

class ClassicalVisionEngine {
public:
    ClassicalVisionEngine();
    bool loadMap(const std::string& imagePath, const std::string& routeCsv, std::string& error);
    PiVisionResult processRgba(const std::vector<uint8_t>& rgba, int width, int height);
    bool confirmNextWaypoint();
    const RouteMap& routeMap() const { return routeMap_; }
    RouteMap& routeMap() { return routeMap_; }

private:
    void detectPeople(const cv::Mat& frame, std::vector<PiDetection>& out);
    void detectRoad(const cv::Mat& frame, PiVisionResult& out);
    void detectMotionAndStatic(const cv::Mat& frame, PiVisionResult& out);
    void detectVehicleCandidates(const cv::Mat& frame, std::vector<PiDetection>& out);
    void estimateOpticalFlow(const cv::Mat& gray, PiVisionResult& out);
    void estimateVisualWeather(const cv::Mat& frame, PiVisionResult& out);
    void localizeOnMap(const cv::Mat& frame, PiVisionResult& out);
    void chooseNearestSafeTarget(const cv::Size& size, PiVisionResult& out);
    static bool segmentHitsRect(const cv::Point& from, const cv::Point& to, const cv::Rect& rect);

    cv::HOGDescriptor hog_;
    cv::Ptr<cv::ORB> orb_;
    cv::Ptr<cv::BFMatcher> matcher_;
    cv::Mat mapGray_;
    std::vector<cv::KeyPoint> mapKeypoints_;
    cv::Mat mapDescriptors_;
    RouteMap routeMap_;

    cv::Mat motionPreviousGray_;
    cv::Mat flowPreviousGray_;
    std::vector<cv::Point2f> previousFeatures_;
    std::vector<PiDetection> cachedPeople_;
    std::vector<PiDetection> cachedVehicles_;
    float previousTargetX_ = -1.0f;
    float opticalFlowPixelsPerSecond_ = 0.0f;
    float travelledPixels_ = 0.0f;
    std::chrono::steady_clock::time_point lastFlowTimestamp_{};
    bool hasFlowTimestamp_ = false;
    int frameNumber_ = 0;
    int blockedFrames_ = 0;
    int stopLatchFrames_ = 0;
    int mapArrivalFrames_ = 0;
    int lastNearestWaypoint_ = -1;
    bool lastMapLocalized_ = false;
    cv::Point2f lastMapPosition_{};
    std::string lastMapStatus_ = "Карта не загружена";
    bool lastHasMapTarget_ = false;
    cv::Point lastMapTarget_;
    std::string weather_ = "Оценка ожидает кадры";
};
