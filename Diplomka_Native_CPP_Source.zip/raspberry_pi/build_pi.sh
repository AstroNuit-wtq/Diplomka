#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PI_DIR="$ROOT/raspberry_pi"
BUILD_DIR="${BUILD_DIR:-$ROOT/build-pi}"
JOBS="${BUILD_JOBS:-2}"

if [[ "${EUID}" -eq 0 ]]; then SUDO=""; else SUDO="sudo"; fi

printf '\n== Diplomka / Raspberry Pi 4B / classical OpenCV build ==\n'
printf 'Project: %s\nBuild:   %s\n' "$ROOT" "$BUILD_DIR"

$SUDO apt-get update
$SUDO apt-get install -y --no-install-recommends \
  build-essential cmake ninja-build git ca-certificates pkg-config \
  libsdl2-dev libgles-dev libegl-dev rpicam-apps libopencv-dev \
  fonts-dejavu-core

cmake -S "$PI_DIR" -B "$BUILD_DIR" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_FLAGS_RELEASE='-O2 -DNDEBUG'
cmake --build "$BUILD_DIR" --parallel "$JOBS"

printf '\nBuild complete: %s/diplomka-pi\n' "$BUILD_DIR"
printf 'Camera test: rpicam-hello -t 5000\n'
printf 'Run: %s/raspberry_pi/run_pi.sh [--map /path/to/map.jpg] [--route /path/to/route.csv]\n' "$ROOT"
printf 'Runtime requires no network connection; build dependencies are installed above.\n'
