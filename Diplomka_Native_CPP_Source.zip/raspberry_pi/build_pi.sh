#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PI_DIR="$ROOT/raspberry_pi"
BUILD_DIR="${BUILD_DIR:-$ROOT/build-pi}"
DEPS_DIR="${DEPS_DIR:-$HOME/.cache/diplomka-deps}"
NCNN_SRC="$DEPS_DIR/ncnn"
NCNN_PREFIX="${NCNN_PREFIX:-/usr/local}"
JOBS="${BUILD_JOBS:-2}"
MODEL_DIR="$ROOT/models"
MODEL_BASE="https://raw.githubusercontent.com/nihui/ncnn-android-yolov8/20260527.f1ac75e/app/src/main/assets"

if [[ "${EUID}" -eq 0 ]]; then
  SUDO=""
else
  SUDO="sudo"
fi

printf '\n== Diplomka / Raspberry Pi 4B native C++ build ==\n'
printf 'Project: %s\nBuild:   %s\n' "$ROOT" "$BUILD_DIR"

$SUDO apt-get update
$SUDO apt-get install -y --no-install-recommends \
  build-essential cmake ninja-build git curl ca-certificates pkg-config \
  libsdl2-dev libgles-dev libegl-dev rpicam-apps

mkdir -p "$DEPS_DIR" "$MODEL_DIR"
if [[ ! -f "$NCNN_SRC/CMakeLists.txt" ]]; then
  git clone --depth 1 --branch 20261020 https://github.com/Tencent/ncnn.git "$NCNN_SRC"
fi

cmake -S "$NCNN_SRC" -B "$DEPS_DIR/ncnn-build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="$NCNN_PREFIX" \
  -DNCNN_VULKAN=OFF \
  -DNCNN_OPENMP=ON \
  -DNCNN_BUILD_TOOLS=OFF \
  -DNCNN_BUILD_EXAMPLES=OFF \
  -DNCNN_BUILD_BENCHMARK=OFF \
  -DNCNN_BUILD_TESTS=OFF
cmake --build "$DEPS_DIR/ncnn-build" --parallel "$JOBS"
$SUDO cmake --install "$DEPS_DIR/ncnn-build"

for model in yolov8n.ncnn.param yolov8n.ncnn.bin yolov8n_pose.ncnn.param yolov8n_pose.ncnn.bin; do
  curl --fail --location --retry 4 "$MODEL_BASE/$model" -o "$MODEL_DIR/$model"
done

test "$(wc -c < "$MODEL_DIR/yolov8n.ncnn.param")" -gt 1000
test "$(wc -c < "$MODEL_DIR/yolov8n.ncnn.bin")" -gt 100000
test "$(wc -c < "$MODEL_DIR/yolov8n_pose.ncnn.param")" -gt 1000
test "$(wc -c < "$MODEL_DIR/yolov8n_pose.ncnn.bin")" -gt 100000

cmake -S "$PI_DIR" -B "$BUILD_DIR" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH="$NCNN_PREFIX"
cmake --build "$BUILD_DIR" --parallel "$JOBS"

printf '\nBuild complete: %s/diplomka-pi\n' "$BUILD_DIR"
printf 'Models: %s\n' "$MODEL_DIR"
printf 'Camera test: rpicam-hello -t 5000\n'
printf 'Run: %s/diplomka-pi "%s"\n' "$BUILD_DIR" "$MODEL_DIR"
