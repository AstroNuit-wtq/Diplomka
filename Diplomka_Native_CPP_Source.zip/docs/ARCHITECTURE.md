# Native architecture — 2.5.0

```text
Android NativeActivity
  └── android_main (C++)
      ├── Dear ImGui + OpenGL ES 3 UI
      │   ├── live camera preview
      │   ├── detection and pose overlays
      │   ├── custom vector action icons
      │   ├── six-wheel rover brand mark
      │   ├── rotating segmented glyph accents + press sweep
      │   ├── two-row expanded action labels
      │   └── hideable event log
      ├── CameraEngine
      │   ├── dedicated C++ worker thread + private ALooper
      │   ├── command queue: start/stop/torch/shutdown
      │   ├── Camera2 state callbacks enqueue events only
      │   ├── worker owns all Camera2 device/session/request objects
      │   ├── AImageReader callback gate + lifetime bridge
      │   └── Camera2 YUV_420_888 → validated RGBA
      ├── VisionEngine (dedicated bounded worker thread)
      │   ├── latest-frame queue (one pending frame; old work is dropped)
      │   ├── NCNN YOLOv8n object detector (COCO)
      │   ├── NCNN YOLOv8n-pose keypoints (17 landmarks)
      │   ├── DFL decode + class-aware NMS
      │   └── short temporal box smoothing
      ├── SensorEngine
      │   └── Rotation Vector → CircularHeadingFilter
      └── Android framework JNI calls from C++
          ├── camera/location runtime permissions
          └── last-known GPS fix
```

## Camera thread ownership

All Camera2 object creation, request submission, stop/abort, session close, device close and cleanup are performed by one worker thread. UI calls enqueue commands and return immediately. NDK device/session callbacks may execute on framework-managed callback threads; they do not call Camera2 APIs or inspect worker-owned object state. Instead, they enqueue an event carrying the opaque object pointer. The worker compares that pointer to its currently owned object and performs the required operation only if it is still current.

A small callback bridge outlives the `CameraEngine` object. Shutdown joins the worker, disables the bridge owner, and waits for active ImageReader callbacks to leave before the bridge can be considered inactive. `AImageReader` has its own dedicated callback thread; its listener is detached and in-flight image conversion is drained before the image reader or frame consumer is released. This prevents a late callback from using a destroyed `CameraEngine` or `AppState`.

`ACameraCaptureSession_stateCallbacks::onReady` indicates that the session has no more capture requests to process. The callback only queues a `SessionReady` event; the worker then validates session identity and calls `ACameraCaptureSession_setRepeatingRequest`. Camera state is not mutated from the callback thread.

## Compass filtering

The azimuth is extracted from the Android rotation-vector quaternion using the device top-edge (+Y) orientation, then treated as a circular variable. The update uses the shortest signed angular error, a time-constant low-pass filter and a one-frame jump gate. This avoids averaging 359° and 1° as if they were far apart. Device-specific calibration and orientation checks remain necessary on physical phones.

## Neural inference

Neural inference runs on a dedicated worker thread. The camera callback converts and publishes the latest frame; a single-slot queue replaces stale pending work instead of growing without bound. Pose inference runs less frequently than object detection to reduce CPU load.

## Object detection

YOLOv8n uses 80 COCO object classes. Candidate boxes are decoded from DFL distributions, filtered by confidence, mapped back from the letterboxed 640×640 tensor and filtered with class-aware NMS. A short IoU-based temporal blend damps rectangle jitter.

YOLOv8n-pose is configured as a separate model and is scheduled less frequently than the main detector. Its 17 keypoints are drawn as a simple human skeleton.

## Statue recognition limitation

The downloaded COCO model does not contain a statue/monument label. A person detection that remains still is not sufficient evidence of a statue. Do not relabel still people as statues. A dedicated model trained with statue/monument/mannequin/person examples is needed.

## Android launcher icon

The manifest references `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`. Adaptive launcher resources are provided under `mipmap-anydpi-v26`; PNG fallback images are provided for mdpi through xxxhdpi. The foreground rover artwork is included under `drawable-nodpi`.

## Build isolation

The workflow checks out the two uploaded files, unpacks source under the GitHub runner temp folder, downloads native dependencies/models to temp, builds there and uploads the APK as a workflow artifact. A final `always()` step removes repository files except `.github/workflows`. The source ZIP must therefore be uploaded again for each new build cycle.


## Camera session invalidation and model worker (2.5.0)

The `onClosed` callback invalidates the NDK capture-session pointer. The camera worker now clears the current session pointer as soon as it handles that event and never calls `stopRepeating` or `close` on the invalid pointer. Remaining request/output/device resources are released by the worker's regular teardown path.

NCNN model loading is requested from `APP_CMD_INIT_WINDOW` but performed only by the inference worker. Detector and pose inference are throttled to every fifth and twentieth camera frame respectively.
