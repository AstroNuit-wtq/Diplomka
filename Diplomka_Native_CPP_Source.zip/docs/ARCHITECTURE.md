# Diplomka 2.7.3 architecture

## Shared vision core

`app/src/main/cpp/pi_vision_engine.{h,cpp}` contains the shared `ClassicalVisionEngine` used by Android and Raspberry Pi. It consumes RGBA frames and performs CPU-only OpenCV processing: HOG + SVM pedestrian proposals; contour/geometry candidates for large objects and vehicles; motion/frame differencing; yellow-line and curb extraction; Lucas–Kanade optical flow in pixel units; visual weather heuristics; optional ORB/BFMatcher map matching and nearest unvisited graph waypoint selection; and candidate corridor selection with a conservative STOP latch.

No neural-network runtime or model weights are used.

## Android

`vision_engine.{h,cpp}` adapts Android NativeActivity/Camera2 RGBA frames to the shared engine. `main.cpp` owns camera, sensors, GPS, the vision worker, UI and session logger. The app reads `route.csv` and optional `map.jpg` from `app/src/main/assets`.

The GitHub Actions workflow downloads a pinned OpenCV Android SDK, verifies its SHA-256, configures CMake and produces an arm64-v8a APK.

## Raspberry Pi

`raspberry_pi/main.cpp` owns the SDL2/OpenGL ES interface and camera stream. `camera_pipe.cpp` reads the CSI stream supplied by `rpicam-vid`. The Pi target compiles the same classical engine source and links system OpenCV.

## Route format

CSV columns: `id,x,y,neighbors`. Coordinates are pixels in the map image or normalized values from 0 to 1. Neighbors are separated by semicolons. The image must contain visual landmarks also visible from the camera for ORB localization to work.

## Safety and accuracy

This is a research navigation aid, not an autonomous-driving or certified collision-avoidance system. Monocular RGB does not provide metric depth. HOG and contour candidates can miss or misclassify objects. STOP suggestions must not replace independent range sensors, an emergency stop, or supervised testing.
