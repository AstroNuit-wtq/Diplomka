# Diplomka Native C++ — аудит, реализация и оставшиеся задачи

Дата обновления: 26 ноября 2026 г.
Версия: `2.5.1-pi-constant-fix` (versionCode 8)

## 1. Причина предыдущих неисправностей

Пользователь сообщил, что камера не показывала кадры, нажатие кнопок зависало, интерфейс был визуально слабым, не было полноценной launcher-иконки и ожидаемых Glyph-анимаций.

Аудит C++ исходников 2.3.1 выявил опасную организацию потоков: callback-и Camera2 напрямую обращались к состоянию камеры, которое должно принадлежать рабочему потоку; операции запуска/остановки/управления вспышкой могли выполняться из UI-пути; жизненный цикл `AImageReader` требовал более строгого ограждения callback-ов. В манифесте не было launcher-иконки и не было mipmap/drawable-ресурсов. Кнопки были нарисованы сокращёнными буквенными обозначениями, а анимация состояла лишь из краткого светового блика.

На пользовательском скриншоте ранее отображались четыре английские кнопки `Torch / Detect / Pose / Restart Camera`, которых не было в архиве 2.3.1 (в нём было шесть русских кнопок). Это несоответствие означает, что APK на телефоне мог быть собран из другого исходного ZIP или другого workflow. В 2.5.1 добавлена заметная версия в интерфейсе и повышен versionCode.

## 2. Изменения версии 2.5.1

### 2.1 Camera2 и потоки

1. Весь жизненный цикл Camera2 передан выделенному C++ worker-потоку.
2. Команды запуска, остановки, управления вспышкой и завершения передаются через потокобезопасную очередь.
3. UI не вызывает синхронно `ACameraCaptureSession_stopRepeating`, `abortCaptures`, `ACameraCaptureSession_close` и `ACameraDevice_close`.
4. Callback-и Camera2 больше не обращаются к `session_`, `request_` и `device_` напрямую.
5. Callback-и устройства и сессии только помещают события в очередь CameraEngine.
6. Worker проверяет, относится ли событие к текущей сессии/устройству, и только затем выполняет Camera2 API.
7. Добавлен независимый callback bridge, который остаётся действительным до завершения отложенных callback-ов.
8. При закрытии Activity worker полностью останавливается и присоединяется через `join()` до уничтожения AppState.
9. Для `AImageReader` добавлен callback gate и счётчик активных callbacks.
10. Перед освобождением frame consumer отключается listener и дренируются callbacks, уже выполняющие преобразование.
11. `onReady` передаёт событие в worker; повторяющийся request запускается worker-потоком после проверки актуальности сессии.
12. Сохранены выбор поддерживаемого YUV-формата, проверка strides, размеров и длины буферов.
13. Сохранены тайм-аут первого кадра, контроль остановки видеопотока и повторный запуск с backoff.
14. Разрешение камеры по-прежнему запрашивается отдельно от геолокации.
15. Изменён цикл управления: start/stop/torch не выполняют тяжёлую работу в UI callback.

### 2.2 Интерфейс и действия

1. Обновлена тёмная графитовая Material You-inspired палитра с бирюзовыми акцентами.
2. Кнопки используют векторные пиктограммы, а не буквенные сокращения.
3. Добавлена компактная эмблема ровера с шестью колёсами.
4. Все шесть действий остаются доступными в нижней панели.
5. В развёрнутом виде подписи распределяются в два ряда.
6. Журнал можно скрывать и открывать.
7. Сохранено отображение LIVE/OPENING/OFFLINE.
8. Добавлены плавные статусные индикаторы.
9. Добавлена медленная сегментная Glyph-подсветка активных действий.
10. Добавлен расширенный sweep/glow при нажатии на любую кнопку.
11. Сохранён компактный и расширенный режим панели действий.

### 2.3 Launcher icon

1. Добавлен `android:icon` в AndroidManifest.xml.
2. Добавлен `android:roundIcon`.
3. Созданы adaptive icon XML для Android 8+.
4. Добавлена отдельная цветовая подложка.
5. Добавлены PNG fallback варианты mdpi, hdpi, xhdpi, xxhdpi и xxxhdpi.
6. Добавлен foreground PNG с изображением ровера.
7. Подготовлен исходный SVG в `docs/assets/rover-icon.svg`.
8. Иконка изображает компактный исследовательский/доставочный ровер с шестью колёсами, подвеской, сенсорной мачтой и сегментированным световым ореолом.

### 2.4 Версия

- `versionName`: `2.5.1-pi-constant-fix`
- `versionCode`: `7`
- Шапка интерфейса: `DIPLOMKA · VISION SYSTEM 2.5.1`

### 2.5 Неизменившиеся функциональные ограничения

- YOLOv8n использует COCO; отдельного класса статуи нет.
- YOLOv8n-pose выдаёт 17 ключевых точек; полноценная сегментация тела не реализована.
- Нет метрической оценки глубины и гарантированного измерения расстояния.
- Нет полноценной карты, маршрутизации и валидированного определения безопасного направления.
- GPS пока использует last-known fix; непрерывное обновление позиции не реализовано.
- Видеоимпорт и покадровый анализ пользовательских файлов не перенесены.
- В Pi-проекте нет подключённого внешнего GPS/компаса и USB UVC-камеры.

## 3. Проверки, выполненные в текущей рабочей среде

- Проверено наличие Android launcher-ресурсов для adaptive и legacy icon.
- Проверено наличие `android:icon` и `android:roundIcon` в Manifest.
- SVG иконки вынесен из Android `res` в документацию, чтобы Android resource compiler не обрабатывал неподдерживаемый тип ресурса.
- Проверено отсутствие `ALooper_pollAll`; используется `ALooper_pollOnce`.
- Проверена структура очереди camera worker и перенесены Camera2 state callback-и на командную очередь.
- C++-тест фильтра компаса скомпилирован локальным clang++ с `-Wall -Wextra -Werror` и успешно выполнен.
- Проверен синтаксис Bash-скриптов Raspberry Pi и всех семи Bash-блоков workflow.
- Проверен синтаксис YAML workflow.
- Проверен XML Manifest и adaptive icon resources; PNG иконки проверены на целостность.

## 4. Что не подтверждено

- Полная Android release-сборка для версии 2.5.1 в этой среде не запускалась: здесь нет Android SDK/NDK.
- Камера не проверена на физическом Android-телефоне.
- Нельзя утверждать, что кнопки и анимации уже прошли инструментальное UI-тестирование на телефоне.
- Raspberry Pi build не запускался на физической Raspberry Pi 4B.
- Скорость/нагрев/потребление RAM на Android/Pi не измерялись.

## 5. Обязательные тесты после загрузки в GitHub

### Android

- [ ] Убедиться, что workflow извлекает именно `Diplomka_Native_CPP_Source.zip` из корня репозитория.
- [ ] Убедиться, что в Actions запускается workflow `.github/workflows/build-astro-cpp.yml` версии 2.5.1.
- [ ] Успешно собрать `:app:assembleRelease`.
- [ ] Проверить, что новый APK показывает `2.5.1-pi-constant-fix` и `VISION SYSTEM · 2.5.1`.
- [ ] Удалить старую установку или обновить её пакетом с тем же `applicationId` и новым versionCode.
- [ ] Разрешить доступ к камере.
- [ ] Проверить, что frame counter увеличивается от нуля.
- [ ] Проверить запуск камеры после выхода/возврата в приложение.
- [ ] Проверить выключение/включение камеры и ручной перезапуск.
- [ ] Проверить все шесть кнопок, включая быстрые повторные нажатия.
- [ ] Проверить вспышку на устройстве с задней вспышкой.
- [ ] Проверить работу без разрешения GPS.
- [ ] Проверить длительную работу и нагрев.
- [ ] Проверить ориентацию/расположение preview.

### Raspberry Pi 4B

- [ ] Использовать Raspberry Pi OS 64-bit Bookworm или новее.
- [ ] Проверить CSI-камеру командой `rpicam-hello -t 5000`.
- [ ] Собрать `BUILD_JOBS=1 bash raspberry_pi/build_pi.sh` (или `2`, если достаточно RAM).
- [ ] Запустить `bash raspberry_pi/run_pi.sh` из графической сессии.
- [ ] Проверить реальные кадры и частоту инференса.
- [ ] Измерить нагрев, RAM и стабильность длительной работы.
- [ ] Отдельно разработать адаптеры USB/UVC, GPS и магнитометра при необходимости.

## 6. Следующие задачи после подтверждения базовой стабильности

1. Стабильный end-to-end Camera2 тест на нескольких Android-устройствах.
2. Инструментальные UI-тесты всех кнопок и сценариев восстановления.
3. Профилирование преобразования YUV→RGBA и снижение копирований кадров.
4. Проверка корректности ориентации/вращения изображения на фронтальной и задней камерах.
5. Отдельная модель для статуй/памятников/манекенов.
6. Сегментация человека/частей тела.
7. Модель оценки глубины и калибровка камеры.
8. Реальное определение свободного пространства и препятствий.
9. Онлайн-/оффлайн-карты и полноценное GPS-обновление.
10. Raspberry Pi тестирование и оптимизация для 4B.

## 7. Безопасность

Нынешний детектор/оценка глубины не являются сертифицированной системой предотвращения столкновений. Не полагаться на расстояния и метки объектов как на единственное средство безопасности. Для безопасного использования требуются измерения, калибровка, независимые тестовые наборы и тесты на целевом оборудовании.


## Дополнительные исправления версии 2.5.1

1. Устранено повторное обращение к `ACameraCaptureSession*` после `onClosed`: указатель очищается сразу в worker event handler, остальные ресурсы камеры освобождаются отдельно.
2. Загрузка NCNN/YOLO моделей перенесена из `APP_CMD_INIT_WINDOW` в inference worker; интерфейс не выполняет синхронное чтение тяжёлых файлов при открытии окна.
3. Ограничена нагрузка моделей: детекция — каждый пятый кадр, поза — каждый двадцатый кадр.
4. Добавлено имя фонового потока `diplomka-infer` для удобства профилирования.

Эти изменения прошли статическую проверку исходников. Полная Android-компиляция и тестирование камеры на устройстве по-прежнему требуют запуска GitHub Actions и установки APK на Android.


### 2.5.1 — camera close safety and background model loading

- Исправлено завершение Camera2-сессии: `onClosed` означает, что указатель сессии уже недействителен. Код больше не вызывает методы на этом указателе после callback.
- Очистка `ImageReader` Surface, request и output ресурсов выполняется после подтверждённого `onClosed`. Если событие задерживается, камера удерживает ресурсы до получения callback, не освобождая поверхность преждевременно.
- Загрузка моделей NCNN/YOLO вынесена из `APP_CMD_INIT_WINDOW` в поток `diplomka-infer`; UI не ждёт чтения больших файлов модели.
- Детекция запускается на каждом пятом кадре, оценка позы — на каждом двадцатом кадре.
- В workflow добавлен отдельный шаг сборки и запуска portable C++-теста компаса до Android сборки.


## Исправление компиляции 2.5.1 — IM_PI

В логе GitHub Actions от 25 ноября 2026 года компиляция остановилась в `app/src/main/cpp/main.cpp` на восьми ошибках `use of undeclared identifier 'IM_PI'`. Причина: `IM_PI` не является публичной константой `imgui.h` и недоступен в текущей конфигурации включаемых заголовков.

Исправления:
- В Android C++ добавлена собственная `constexpr float kPi = 3.14159265358979323846f` в локальном anonymous namespace.
- Все восемь использований `IM_PI` в Android UI заменены на `kPi`.
- Аналогичная замена сделана в Raspberry Pi UI, где использовался тот же недоступный макрос.
- Версия повышена до `2.5.1-pi-constant-fix`, `versionCode` — 8.
- В шапке Android интерфейса отображается `VISION SYSTEM · 2.5.1`.

Проверка исходников: после замены в проекте не должно остаться обращений к `IM_PI`; проверяются оба UI-файла Android и Raspberry Pi. Полная Android-сборка должна быть подтверждена следующим запуском GitHub Actions.


## Version 2.6.0 updates

### Implemented in source
- Thread-safe full process session log with UTC and monotonic timestamps.
- Application logging routed from NativeActivity/UI, Camera2, sensors and NCNN model loading into one session log and Android logcat.
- Dedicated toolbar button `Собрать лог`.
- TXT export to public Downloads/Diplomka via MediaStore on Android 10+, with app-specific storage fallback on Android 8/9.
- Camera diagnostics: stage transitions, capture result/failure counts, image-reader callback count, image acquisition status, YUV plane strides and flash metadata state.
- Camera startup timeout is 45 seconds; first-frame timeout is 30 seconds; automatic retry is limited to one attempt before requiring a manual restart.

### Device validation still required
The source-level diagnostics and logger tests do not prove physical Camera2/flash operation. The next exported log from the actual phone must be inspected to identify whether the pipeline stops at camera enumeration, device open, session configure/onReady, repeating request, capture result, ImageReader callback, or YUV conversion.


## Version 2.6.0 — full startup session log and Camera2 diagnostics

### Implemented in source
- Added a thread-safe session logger initialized at the first `android_main` event. Every entry includes UTC wall-clock time, monotonic elapsed milliseconds, level and component tag.
- Routed native Activity/UI, Camera2, sensors and vision/model messages to the same log buffer while retaining Android logcat output.
- Added a dedicated `Собрать лог` action. Export and JNI/storage work execute on a dedicated worker thread so the render/input thread does not wait for file I/O.
- Android 10+ export uses MediaStore and creates a timestamped TXT file in `Downloads/Diplomka`. Android 8/9 use the app-specific `Android/data/com.diplomka.app/files/logs` directory.
- Added startup device details (brand, manufacturer, model, device, Android API level) and permission-state transition logging.
- Camera log now includes camera candidates, facing, supported YUV stream size, flash availability, AF/AE modes, every pipeline stage, device/session callbacks, first capture result, capture failures, flash metadata transitions, ImageReader callback/acquisition status and YUV plane stride/bounds information.
- Torch request status and failures are logged separately from actual flash-state metadata. Camera2 torch requests use `CONTROL_MODE_AUTO`, `AE_MODE_ON` and `FLASH_MODE_TORCH`; Android Camera2 requires AE ON/OFF for a torch request and reports flash state in capture results.
- Startup watchdog is 45 seconds, first-frame watchdog 30 seconds and automatic retry is limited to one attempt; after that the app waits for an explicit manual restart instead of repeatedly reopening the camera.
- Added a portable C++ unit test for session log formatting and line counting.

### Diagnostic limits
- The exported TXT contains Diplomka process logs only. It is not a full system-wide Android `logcat` dump.
- Source and portable unit tests do not prove physical camera or flash operation. The next log collected from the actual phone must be inspected to identify the exact stage that fails.
- Full Android release build and device validation still require a GitHub Actions run and an Android handset.
