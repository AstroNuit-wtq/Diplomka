# Diplomka 2.7.3 — Android + Raspberry Pi 4B

Проект содержит **две самостоятельные версии** приложения с общим C++-движком классического компьютерного зрения на OpenCV. Нейросети, NCNN, YOLO и файлы весов не используются. Обработка выполняется локально на устройстве; после сборки интернет не нужен.

## Версии

### Android

- NativeActivity + Android NDK, C++20, Camera2.
- Живой предпросмотр камеры и наложение рамок/направления/STOP.
- HOG + SVM для предложений людей; контурные признаки для кандидатов крупных объектов/машин.
- Lucas–Kanade optical flow, анализ движения, жёлтой разметки и бордюров.
- Визуальная оценка погодных признаков.
- ORB/BFMatcher для сопоставления кадра с изображением карты и nearest-neighbor для выбора следующей непосещённой точки маршрута.
- Журнал с момента запуска и кнопка «Собрать лог».

Для карты помести совместимое изображение местности в `app/src/main/assets/map.jpg`; маршрут — в `app/src/main/assets/route.csv`. CSV имеет столбцы `id,x,y,neighbors`, координаты относятся к пикселям `map.jpg` или к нормированному диапазону `0..1`. Пример: `app/src/main/assets/route.csv`. В текущем UI нет произвольного выбора карты через файловый диалог: карту нужно включить в APK до сборки.

### Raspberry Pi 4B

- Отдельное Linux C++-приложение с локальной обработкой CPU.
- Захват CSI-камеры через `rpicam-vid`; экран предпросмотра в графической сессии.
- Те же алгоритмы объектов/движения/дороги/погоды/карты/nearest-neighbor.
- Фото карты и маршрут можно передать параметрами `--map` и `--route`.

## Сборка Android через GitHub Actions

Комплект для GitHub состоит из двух файлов:

1. `build-astro-cpp.yml` — положить в `.github/workflows/build-astro-cpp.yml`.
2. `Diplomka_Native_CPP_Source.zip` — загрузить в корень репозитория.

Запусти `Actions → Build Diplomka Native C++ APK · 2.7.3 → Run workflow`. Workflow загружает OpenCV Android SDK, собирает arm64-v8a APK и публикует его как artifact `Diplomka-Android-APK-2.7.3`. После завершения workflow очищает корень репозитория, оставляя каталог `.github/workflows`, поэтому для следующего запуска ZIP потребуется загрузить повторно. APK в текущем комплекте заранее не собран.

## Сборка Raspberry Pi 4B

На Raspberry Pi OS 64-bit (Bookworm или новее), из распакованного архива:

```bash
chmod +x raspberry_pi/build_pi.sh raspberry_pi/run_pi.sh
BUILD_JOBS=2 bash raspberry_pi/build_pi.sh
bash raspberry_pi/run_pi.sh
```

С картой и графом маршрута:

```bash
bash raspberry_pi/run_pi.sh --map /home/pi/maps/map.jpg --route /home/pi/maps/route.csv
```

## Общее ограничение точности и безопасности

Это исследовательский визуальный помощник, не сертифицированный автопилот и не система предотвращения столкновений. HOG и контурные признаки могут пропускать людей/машины и давать ложные срабатывания. Одна RGB-камера не измеряет метрическую глубину: приложение показывает изображенческие смещения, а не достоверную дистанцию в метрах или реальную скорость.

ORB-сопоставление работает только если кадр камеры и `map.jpg` имеют общие визуальные ориентиры. Обычная схема улиц или спутниковый снимок могут не совпасть с перспективным видом камеры. При недостаточных совпадениях приложение сообщает, что привязка недоступна, а не придумывает позицию. GPS телефона показывается отдельно и сам по себе не синхронизирован с графом маршрута.

STOP/обход — это консервативная эвристика по обнаруженным препятствиям и проверяемым коридорам, а не гарантия безопасного прохода. Не используйте приложение для управления реальным роботом без независимых датчиков, аварийного выключателя, аппаратной остановки и испытаний в закрытой зоне. GPIO-управление моторами и передача видеопотока между телефоном и Pi в этот комплект не входят.

## Проверки

В текущей среде проверяются портируемые C++-тесты, статические проверки исходников, структура архивов и Bash-синтаксис. Полная Android-сборка выполняется в GitHub Actions; физическая работа камеры, точность детекции, map matching и FPS должны быть проверены на целевых устройствах. Полную сборку Raspberry Pi нужно выполнить на самой плате с OpenCV/SDL2.


### Android hotfix 2.7.3

The GitHub workflow selects the OpenCV CMake package specifically from `abi-arm64-v8a` and validates ARM64 static library files before invoking Gradle. This prevents accidentally linking `staticlibs/x86` into the ARM64 APK.


Android hotfix 2.7.3: Camera2 submits the first repeating preview request immediately after creating the capture session and retries it on the worker thread; the toolbar uses a responsive compact row and a two-column expanded grid with four rows and clipped labels.
