# Diplomka Native C++ 2.6.0 — Android + Raspberry Pi 4B

Нативная C++-переработка Diplomka. Android использует NativeActivity/NDK; Raspberry Pi 4B — отдельное Linux-приложение. В исходниках Android нет Python, Kotlin и Java-кода приложения.

## Базовые исправления 2.5.1, сохранённые в версии 2.6.0

### Критические исправления 2.5.1

- Обнаружено и исправлено небезопасное использование `ACameraCaptureSession*` после callback `onClosed`: Android NDK помечает объект недействительным сразу после этого callback; теперь указатель немедленно обнуляется и не передаётся в `stopRepeating/close` повторно.
- Загрузка NCNN/YOLO моделей перенесена из `APP_CMD_INIT_WINDOW` в отдельный inference-поток; запуск окна больше не ждёт чтения файлов модели.
- Частота инференса ограничена: детекция выполняется на каждом пятом кадре, оценка позы — на каждом двадцатом кадре.
- Поток распознавания получает имя `diplomka-infer` для диагностики.

### Камера и управление потоками

- Все вызовы Android Camera2 (`ACameraManager`, `ACameraDevice`, `ACameraCaptureSession`, request/session lifecycle) выполняются на одном выделенном C++ worker thread.
- Запуск, остановка, фонарик и перезапуск камеры из UI только помещают команды в очередь; UI не ждёт Camera HAL и не выполняет `close/abort/stopRepeating` синхронно.
- NDK callback-и устройства/сессии не обращаются к Camera2-объектам напрямую: они только отправляют событие в очередь worker-потока. Worker проверяет актуальность указателя и выполняет API-вызов.
- Callback context имеет независимый lifetime bridge. Поздние callback-и после закрытия Activity не могут обращаться к уничтоженному `CameraEngine`.
- `AImageReader` callback защищён callback gate; listener отключается, текущие callbacks дренируются, и только после этого освобождаются reader/consumer.
- `onReady` передаёт событие worker-потоку; repeating request создаётся worker-потоком после проверки, что сессия всё ещё текущая.
- Выбирается поддерживаемая камерой конфигурация `YUV_420_888`; валидируются плоскости Y/U/V, strides и границы буферов.
- Статус LIVE устанавливается только после получения реального кадра. Тайм-ауты и backoff повторного запуска сохраняются.

### Интерфейс и иконка

- Добавлена полноценная Android launcher icon: adaptive icon для Android 8+ и PNG fallback для разных плотностей экрана.
- Иконка нарисована как шестиколёсный исследовательский/доставочный ровер с мачтой сенсора и сегментированным световым ореолом.
- В интерфейсе добавлена компактная шестиколёсная эмблема ровера.
- Кнопки используют нарисованные векторные пиктограммы вместо буквенных сокращений.
- Добавлена медленная вращающаяся сегментная Glyph-подсветка для активных действий и световой sweep/glow при нажатии.
- Сохранены скрываемый журнал и сворачиваемая панель действий; в развёрнутом виде названия действий видны в двух рядах.
- Обновлены тёмная графитовая палитра, бирюзовые акценты, скругления и статусные индикаторы Material You-inspired.

### Компьютерное зрение

- Сохранена интеграция NCNN, YOLOv8n (COCO) и YOLOv8n-pose (17 ключевых точек).
- Инференс остаётся в отдельном ограниченном worker queue; устаревшие кадры заменяются более свежими.
- Модель COCO не распознаёт статуи как отдельный класс; для этого нужна специализированная модель и проверка качества.

### Версии

- Текущий Version name: `2.6.0-session-log-camera-diagnostics`
- Текущий Version code: `9`
- В шапке приложения: `DIPLOMKA · VISION SYSTEM 2.6.0`

## Android сборка через GitHub Actions

Комплект доставки для iPhone содержит два файла верхнего уровня:

1. `build-astro-cpp.yml` — положить в GitHub как `.github/workflows/build-astro-cpp.yml`.
2. `Diplomka_Native_CPP_Source.zip` — загрузить в корень репозитория.

Workflow распаковывает исходники в `$RUNNER_TEMP`, скачивает NCNN и модели, собирает APK и сохраняет его как `Actions → Artifacts → Diplomka-Native-Cpp-APK-2.6.0`. После успешной или неуспешной сборки workflow очищает ветку репозитория, оставляя `.github/workflows`. Поэтому ZIP исходников потребуется повторно загрузить перед следующим запуском.

APK: `Diplomka-Native-C++-arm64-v8a.apk`.

Для проверки установленной версии открой сведения о приложении Android: должна отображаться версия `2.6.0-session-log-camera-diagnostics` (versionCode 9). В шапке приложения отображается `VISION SYSTEM · 2.6.0`.

## Raspberry Pi 4B

См. `raspberry_pi/README.md`. Требуется Raspberry Pi OS 64-bit (Bookworm или новее), CSI-камера и графическая сессия. Сборка: `BUILD_JOBS=2 bash raspberry_pi/build_pi.sh`; запуск: `bash raspberry_pi/run_pi.sh`.

Pi-версия не является Android APK. Она использует `rpicam-vid` и NCNN на ARM64 CPU. GPS и компас потребуют внешних датчиков и отдельного драйверного слоя.

## Проверки и ограничения

Локально можно проверить переносимый C++-тест компаса, YAML/XML, Bash-скрипты, состав ZIP и наличие ресурсов иконки. В этой среде нет Android SDK/NDK и физического Android-устройства, поэтому полная Android-компиляция и работа Camera2 на телефоне не подтверждены. Linux-сборка также не проверена на физической Raspberry Pi 4B.

Не использовать текущие оценки объектов/расстояния как единственное средство предотвращения столкновений. Для надёжной навигации и безопасности нужны метрическая оценка глубины, отдельные тестовые наборы и проверки на реальных устройствах.


## Version 2.6.0 — full application session log and Camera2 diagnostics

- Added a process-wide, thread-safe application log from the first native startup event, with UTC timestamps and monotonic elapsed milliseconds.
- Centralized NativeActivity/UI, Camera2, sensor and vision/model logging while preserving Android logcat output.
- Added startup device details (brand, manufacturer, model, device and Android API level) and runtime permission transition events.
- Added a dedicated **Собрать лог** toolbar action. Disk I/O/JNI export runs on a dedicated worker and does not block the render/input thread. On Android 10+ it exports a timestamped TXT file to `Downloads/Diplomka`; on Android 8/9 it uses the app-specific `files/logs` directory.
- Added Camera2 stage, camera capability, session callback, capture-result, capture-failure, ImageReader callback/acquisition, YUV plane stride/bounds and flash-state diagnostics.
- Camera startup watchdog is 45 seconds; first-frame watchdog is 30 seconds. Automatic retries are limited to one before manual restart is required.
- Added portable unit test for the session logger.

The exported file contains Diplomka process events, not the Android system-wide logcat.


### Collecting a diagnostic log

The toolbar has a separate `Собрать лог` action. It exports the complete Diplomka application session log (from `android_main` startup, with UTC and elapsed timestamps) to `Downloads/Diplomka/diplomka-session-<timestamp>.txt` on Android 10+. Android 8/9 use the application-specific `Android/data/com.diplomka.app/files/logs` directory. The exported log includes app/UI, Camera2 stages and callbacks, image acquisition/YUV conversion, flash state, sensor and model events. It does not include unrelated system-wide logcat entries.
