#include "pi_vision_engine.h"

#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/calib3d.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <exception>
#include <limits>
#include <sstream>

namespace {
std::string trim(std::string value) {
    const auto first = value.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}

std::vector<std::string> split(const std::string& value, char delimiter) {
    std::vector<std::string> result;
    std::stringstream stream(value);
    std::string item;
    while (std::getline(stream, item, delimiter)) result.push_back(trim(item));
    return result;
}

float median(std::vector<float>& values) {
    if (values.empty()) return 0.0f;
    const auto middle = values.begin() + static_cast<std::ptrdiff_t>(values.size() / 2);
    std::nth_element(values.begin(), middle, values.end());
    return *middle;
}

cv::Rect clipped(const cv::Rect& rect, const cv::Size& size) {
    return rect & cv::Rect(0, 0, size.width, size.height);
}

float rectAreaRatio(const cv::Rect& rect, const cv::Size& size) {
    const double total = static_cast<double>(size.width) * size.height;
    return total > 0.0 ? static_cast<float>(rect.area() / total) : 0.0f;
}

bool lineIntersectsRect(const cv::Point& a, const cv::Point& b, const cv::Rect& rect) {
    constexpr int samples = 32;
    for (int i = 0; i <= samples; ++i) {
        const float t = static_cast<float>(i) / samples;
        const cv::Point p(
            cvRound(a.x + (b.x - a.x) * t),
            cvRound(a.y + (b.y - a.y) * t));
        if (rect.contains(p)) return true;
    }
    return false;
}

} // namespace

bool RouteMap::loadImage(const std::string& path, std::string& error) {
    imageBgr_ = cv::imread(path, cv::IMREAD_COLOR);
    if (imageBgr_.empty()) {
        error = "Не удалось открыть изображение карты: " + path;
        imagePath_.clear();
        return false;
    }
    imagePath_ = path;
    return true;
}

bool RouteMap::loadImageBytes(const std::vector<uint8_t>& bytes, std::string& error) {
    if (bytes.empty()) { error = "Файл карты пуст"; return false; }
    imageBgr_ = cv::imdecode(bytes, cv::IMREAD_COLOR);
    if (imageBgr_.empty()) { error = "Не удалось декодировать изображение карты"; return false; }
    imagePath_ = "<assets/map.jpg>";
    return true;
}

bool RouteMap::loadWaypoints(const std::string& path, std::string& error) {
    std::ifstream input(path);
    if (!input) { error = "Не удалось открыть CSV маршрута: " + path; return false; }
    std::ostringstream content;
    content << input.rdbuf();
    return loadWaypointsText(content.str(), error);
}

bool RouteMap::loadWaypointsText(const std::string& text, std::string& error) {
    std::istringstream input(text);
    std::vector<MapWaypoint> parsed;
    std::string line;
    int lineNumber = 0;
    while (std::getline(input, line)) {
        ++lineNumber;
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        const auto fields = split(line, ',');
        if (fields.size() < 3) {
            if (lineNumber == 1) continue;
            error = "Неверная строка CSV маршрута: " + std::to_string(lineNumber);
            return false;
        }
        try {
            MapWaypoint point;
            point.id = std::stoi(fields[0]);
            point.position.x = std::stof(fields[1]);
            point.position.y = std::stof(fields[2]);
            if (fields.size() >= 4 && !fields[3].empty())
                for (const auto& neighbor : split(fields[3], ';'))
                    if (!neighbor.empty()) point.neighbors.push_back(std::stoi(neighbor));
            parsed.push_back(std::move(point));
        } catch (const std::exception&) {
            if (lineNumber == 1 && (fields[0] == "id" || fields[0] == "ID")) continue;
            error = "Не удалось разобрать CSV маршрута, строка " + std::to_string(lineNumber);
            return false;
        }
    }
    if (parsed.empty()) { error = "CSV маршрута не содержит точек"; return false; }
    if (!imageBgr_.empty()) {
        for (auto& point : parsed) {
            if (point.position.x >= 0.0f && point.position.x <= 1.0f &&
                point.position.y >= 0.0f && point.position.y <= 1.0f) {
                point.position.x *= static_cast<float>(imageBgr_.cols);
                point.position.y *= static_cast<float>(imageBgr_.rows);
            }
        }
    }
    std::set<int> ids;
    for (const auto& point : parsed) {
        if (!ids.insert(point.id).second) {
            error = "В CSV маршрута повторяется ID точки " + std::to_string(point.id); return false;
        }
    }
    for (const auto& point : parsed) for (const int neighbor : point.neighbors) {
        if (ids.count(neighbor) == 0) {
            error = "Точка " + std::to_string(point.id) + " ссылается на отсутствующего соседа " + std::to_string(neighbor);
            return false;
        }
    }
    waypoints_ = std::move(parsed);
    resetProgress();
    return true;
}

std::optional<int> RouteMap::nearestWaypoint(const cv::Point2f& mapPosition) {
    if (waypoints_.empty()) return std::nullopt;

    const MapWaypoint* current = nullptr;
    if (currentWaypoint_ >= 0) {
        for (const auto& point : waypoints_) if (point.id == currentWaypoint_) current = &point;
    }

    std::vector<int> allowed;
    if (current && !current->neighbors.empty()) {
        allowed = current->neighbors;
    } else {
        for (const auto& point : waypoints_) {
            if (point.id != currentWaypoint_ && reached_.count(point.id) == 0) allowed.push_back(point.id);
        }
    }

    const MapWaypoint* best = nullptr;
    float bestDistance = std::numeric_limits<float>::max();
    for (const auto& point : waypoints_) {
        if (reached_.count(point.id) != 0 || point.id == currentWaypoint_) continue;
        if (!allowed.empty() && std::find(allowed.begin(), allowed.end(), point.id) == allowed.end()) continue;
        const float distance = cv::norm(point.position - mapPosition);
        if (distance < bestDistance) {
            bestDistance = distance;
            best = &point;
        }
    }
    if (!best) {
        // If a waypoint graph is disconnected, fall back to the nearest unvisited
        // node but keep the choice explicit in the returned route state.
        for (const auto& point : waypoints_) {
            if (reached_.count(point.id) != 0 || point.id == currentWaypoint_) continue;
            const float distance = cv::norm(point.position - mapPosition);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = &point;
            }
        }
    }
    nextWaypoint_ = best ? best->id : -1;
    return best ? std::optional<int>(best->id) : std::nullopt;
}

bool RouteMap::markReached(int id) {
    const auto found = std::find_if(waypoints_.begin(), waypoints_.end(), [id](const MapWaypoint& p) { return p.id == id; });
    if (found == waypoints_.end()) return false;
    reached_.insert(id);
    currentWaypoint_ = id;
    nextWaypoint_ = -1;
    return true;
}

std::optional<int> RouteMap::nextWaypoint() const {
    if (nextWaypoint_ >= 0) return nextWaypoint_;
    if (waypoints_.empty()) return std::nullopt;
    const MapWaypoint* current = nullptr;
    for (const auto& point : waypoints_) if (point.id == currentWaypoint_) current = &point;
    if (!current) return waypoints_.front().id;
    if (!current->neighbors.empty()) {
        for (const int neighborId : current->neighbors) {
            if (reached_.count(neighborId) == 0) return neighborId;
        }
    }
    for (const auto& point : waypoints_) {
        if (point.id != currentWaypoint_ && reached_.count(point.id) == 0) return point.id;
    }
    return std::nullopt;
}

bool RouteMap::isReached(int id) const { return reached_.count(id) != 0; }

void RouteMap::resetProgress() {
    reached_.clear();
    currentWaypoint_ = waypoints_.empty() ? -1 : waypoints_.front().id;
    if (currentWaypoint_ >= 0) reached_.insert(currentWaypoint_);
    nextWaypoint_ = -1;
}

ClassicalVisionEngine::ClassicalVisionEngine() {
    hog_.setSVMDetector(cv::HOGDescriptor::getDefaultPeopleDetector());
    orb_ = cv::ORB::create(900, 1.2f, 8, 24, 0, 2, cv::ORB::HARRIS_SCORE, 31, 18);
    matcher_ = cv::BFMatcher::create(cv::NORM_HAMMING, false);
}

bool ClassicalVisionEngine::loadMap(const std::string& imagePath, const std::string& routeCsv, std::string& error) {
    bool ok = false;
    if (!imagePath.empty()) {
        ok = routeMap_.loadImage(imagePath, error);
        if (!ok) return false;
        cv::cvtColor(routeMap_.imageBgr(), mapGray_, cv::COLOR_BGR2GRAY);
        orb_->detectAndCompute(mapGray_, cv::noArray(), mapKeypoints_, mapDescriptors_);
    }
    if (!routeCsv.empty()) {
        if (!routeMap_.loadWaypoints(routeCsv, error)) return false;
        ok = true;
    }
    if (!ok) error = "Не задан файл карты или CSV маршрута";
    return ok;
}

bool ClassicalVisionEngine::loadMapBytes(const std::vector<uint8_t>& imageBytes,
                                          const std::string& routeCsvText, std::string& error) {
    bool ok = false;
    if (!imageBytes.empty()) {
        if (!routeMap_.loadImageBytes(imageBytes, error)) return false;
        cv::cvtColor(routeMap_.imageBgr(), mapGray_, cv::COLOR_BGR2GRAY);
        orb_->detectAndCompute(mapGray_, cv::noArray(), mapKeypoints_, mapDescriptors_);
        ok = true;
    }
    if (!routeCsvText.empty()) {
        if (!routeMap_.loadWaypointsText(routeCsvText, error)) return false;
        ok = true;
    }
    if (!ok) error = "Не найдены map.jpg и route.csv в assets";
    return ok;
}

void ClassicalVisionEngine::detectPeople(const cv::Mat& frame, std::vector<PiDetection>& out) {
    cv::Mat small;
    const float scale = std::min(1.0f, 480.0f / static_cast<float>(frame.cols));
    cv::resize(frame, small, cv::Size(), scale, scale, cv::INTER_AREA);
    std::vector<cv::Rect> boxes;
    std::vector<double> weights;
    hog_.detectMultiScale(small, boxes, weights, 0.0, cv::Size(8, 8), cv::Size(0, 0), 1.06, 2, false);
    out.clear();
    for (size_t i = 0; i < boxes.size(); ++i) {
        cv::Rect box(
            cvRound(boxes[i].x / scale), cvRound(boxes[i].y / scale),
            cvRound(boxes[i].width / scale), cvRound(boxes[i].height / scale));
        box = clipped(box, frame.size());
        if (box.area() < 500) continue;
        PiDetection detection;
        detection.box = box;
        detection.label = "Человек";
        const double rawWeight = i < weights.size() ? weights[i] : 0.5;
        detection.confidence = static_cast<float>(std::clamp(rawWeight / 2.0, 0.25, 0.95));
        detection.isPerson = true;
        out.push_back(std::move(detection));
    }
}

void ClassicalVisionEngine::detectRoad(const cv::Mat& frame, PiVisionResult& out) {
    const int width = frame.cols;
    const int height = frame.rows;
    cv::Mat hsv;
    cv::cvtColor(frame, hsv, cv::COLOR_BGR2HSV);
    cv::Mat yellow1, yellow2, yellow;
    cv::inRange(hsv, cv::Scalar(15, 75, 75), cv::Scalar(38, 255, 255), yellow1);
    cv::inRange(hsv, cv::Scalar(18, 35, 45), cv::Scalar(42, 255, 255), yellow2);
    yellow = yellow1 | yellow2;
    cv::morphologyEx(yellow, yellow, cv::MORPH_CLOSE,
                     cv::getStructuringElement(cv::MORPH_RECT, cv::Size(5, 5)));
    std::vector<cv::Vec4i> lines;
    cv::HoughLinesP(yellow, lines, 1, CV_PI / 180.0, 35, 28, 16);
    out.yellowLines = lines;

    const int roiY = static_cast<int>(height * 0.68f);
    const int roiHeight = std::max(1, height - roiY);
    cv::Mat gray, roi, edges;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
    roi = gray(cv::Rect(0, roiY, width, roiHeight));
    const double average = cv::mean(roi)[0];
    const int low = std::clamp(static_cast<int>((1.0 - 0.33) * average), 0, 255);
    const int high = std::clamp(static_cast<int>((1.0 + 0.33) * average), 0, 255);
    cv::Canny(roi, edges, low, std::max(low + 1, high));
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(edges, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    out.curbs.clear();
    std::vector<float> curbCenters;
    for (const auto& contour : contours) {
        if (cv::contourArea(contour) < 70.0) continue;
        cv::Rect box = cv::boundingRect(contour);
        box.y += roiY;
        if (box.width < 5 || box.height < 3) continue;
        out.curbs.push_back(box);
        curbCenters.push_back(box.x + box.width * 0.5f);
    }
    if (curbCenters.size() >= 2) {
        const auto bounds = std::minmax_element(curbCenters.begin(), curbCenters.end());
        out.roadWidthPixels = *bounds.second - *bounds.first;
    } else if (!lines.empty()) {
        float minX = static_cast<float>(width), maxX = 0.0f;
        for (const auto& line : lines) {
            minX = std::min({minX, static_cast<float>(line[0]), static_cast<float>(line[2])});
            maxX = std::max({maxX, static_cast<float>(line[0]), static_cast<float>(line[2])});
        }
        out.roadWidthPixels = std::max(0.0f, maxX - minX);
    }
}

void ClassicalVisionEngine::detectMotionAndStatic(const cv::Mat& frame, PiVisionResult& out) {
    cv::Mat gray, blurred;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
    cv::GaussianBlur(gray, blurred, cv::Size(11, 11), 0.0);
    out.staticObjects.clear();
    cv::Mat edges;
    cv::Canny(blurred, edges, 55, 150);
    std::vector<std::vector<cv::Point>> staticContours;
    cv::findContours(edges, staticContours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    for (const auto& contour : staticContours) {
        if (cv::contourArea(contour) < 4500.0) continue;
        const cv::Rect box = cv::boundingRect(contour);
        if (box.y < frame.rows * 0.62 && rectAreaRatio(box, frame.size()) < 0.45f)
            out.staticObjects.push_back(box);
    }

    out.movingObjects.clear();
    if (!motionPreviousGray_.empty() && motionPreviousGray_.size() == blurred.size()) {
        // Compensate for handheld camera movement before frame differencing.
        // Without this, nearly the whole scene appears to move when a person walks.
        std::vector<cv::Point2f> previousPoints, currentPoints, stablePrevious, stableCurrent;
        std::vector<uchar> status;
        std::vector<float> errors;
        cv::goodFeaturesToTrack(motionPreviousGray_, previousPoints, 180, 0.012, 10.0);
        if (previousPoints.size() >= 10) {
            cv::calcOpticalFlowPyrLK(motionPreviousGray_, blurred, previousPoints, currentPoints,
                                     status, errors, cv::Size(17, 17), 2,
                                     cv::TermCriteria(cv::TermCriteria::EPS | cv::TermCriteria::COUNT, 20, 0.025));
            for (size_t i = 0; i < status.size(); ++i) {
                if (status[i] && errors[i] < 30.0f) {
                    stablePrevious.push_back(previousPoints[i]);
                    stableCurrent.push_back(currentPoints[i]);
                }
            }
        }
        cv::Mat alignedPrevious;
        bool stabilized = false;
        if (stablePrevious.size() >= 10) {
            cv::Mat inliers;
            const cv::Mat affine = cv::estimateAffinePartial2D(stablePrevious, stableCurrent, inliers,
                                                               cv::RANSAC, 3.0, 1500, 0.98, 10);
            if (!affine.empty()) {
                cv::warpAffine(motionPreviousGray_, alignedPrevious, affine, blurred.size(),
                               cv::INTER_LINEAR, cv::BORDER_REPLICATE);
                stabilized = true;
            }
        }
        if (stabilized) {
            cv::Mat difference, threshold;
            cv::absdiff(alignedPrevious, blurred, difference);
            cv::threshold(difference, threshold, 34, 255, cv::THRESH_BINARY);
            cv::morphologyEx(threshold, threshold, cv::MORPH_OPEN,
                             cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3)));
            cv::dilate(threshold, threshold, cv::Mat(), cv::Point(-1, -1), 1);
            std::vector<std::vector<cv::Point>> motionContours;
            cv::findContours(threshold, motionContours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
            for (const auto& contour : motionContours) {
                if (cv::contourArea(contour) < 700.0) continue;
                const cv::Rect box = clipped(cv::boundingRect(contour), frame.size());
                if (box.y + box.height > frame.rows * 0.48 && rectAreaRatio(box, frame.size()) < 0.18f)
                    out.movingObjects.push_back(box);
            }
        }
        // If camera stabilization is uncertain, do not interpret global image changes
        // as independently moving obstacles.
    }
    motionPreviousGray_ = blurred.clone();
}

void ClassicalVisionEngine::detectVehicleCandidates(const cv::Mat& frame, std::vector<PiDetection>& out) {
    out.clear();
    const int roiY = static_cast<int>(frame.rows * 0.38f);
    cv::Mat roi = frame(cv::Rect(0, roiY, frame.cols, frame.rows - roiY));
    cv::Mat gray, edges;
    cv::cvtColor(roi, gray, cv::COLOR_BGR2GRAY);
    cv::GaussianBlur(gray, gray, cv::Size(5, 5), 0.0);
    cv::Canny(gray, edges, 55, 150);
    cv::morphologyEx(edges, edges, cv::MORPH_CLOSE,
                     cv::getStructuringElement(cv::MORPH_RECT, cv::Size(7, 5)));
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(edges, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    for (const auto& contour : contours) {
        const double area = cv::contourArea(contour);
        if (area < static_cast<double>(frame.cols * frame.rows) * 0.004) continue;
        cv::Rect box = cv::boundingRect(contour);
        box.y += roiY;
        const float ratio = static_cast<float>(box.width) / std::max(1, box.height);
        if (ratio < 1.15f || ratio > 4.8f) continue;
        if (box.width < frame.cols * 0.13f || box.height < frame.rows * 0.055f) continue;
        if (box.y + box.height < frame.rows * 0.58f) continue;
        PiDetection candidate;
        candidate.box = clipped(box, frame.size());
        candidate.label = "Возможное авто / объект";
        candidate.confidence = std::clamp(0.35f + rectAreaRatio(candidate.box, frame.size()) * 4.0f, 0.35f, 0.72f);
        candidate.isVehicleCandidate = true;
        out.push_back(std::move(candidate));
    }
    // Merge nearly identical contour rectangles to reduce repeated boxes.
    std::vector<PiDetection> merged;
    for (const auto& candidate : out) {
        bool overlap = false;
        for (auto& kept : merged) {
            const cv::Rect intersection = candidate.box & kept.box;
            const float unionArea = static_cast<float>(candidate.box.area() + kept.box.area() - intersection.area());
            const float iou = unionArea > 0.0f ? intersection.area() / unionArea : 0.0f;
            if (iou > 0.45f) {
                if (candidate.box.area() > kept.box.area()) kept.box = candidate.box;
                overlap = true;
                break;
            }
        }
        if (!overlap) merged.push_back(candidate);
    }
    out = std::move(merged);
}

void ClassicalVisionEngine::estimateOpticalFlow(const cv::Mat& gray, PiVisionResult& out) {
    const auto now = std::chrono::steady_clock::now();
    float elapsedSeconds = 0.2f;
    if (hasFlowTimestamp_) {
        elapsedSeconds = std::chrono::duration<float>(now - lastFlowTimestamp_).count();
        if (elapsedSeconds < 0.001f || !std::isfinite(elapsedSeconds)) elapsedSeconds = 0.2f;
    }
    lastFlowTimestamp_ = now;
    hasFlowTimestamp_ = true;
    if (flowPreviousGray_.empty()) {
        flowPreviousGray_ = gray.clone();
        cv::goodFeaturesToTrack(gray, previousFeatures_, 220, 0.012, 12.0);
        out.opticalFlowPixelsPerSecond = opticalFlowPixelsPerSecond_;
        out.travelledPixels = travelledPixels_;
        return;
    }
    if (previousFeatures_.size() < 25) {
        cv::goodFeaturesToTrack(flowPreviousGray_, previousFeatures_, 220, 0.012, 12.0);
    }
    if (previousFeatures_.empty()) {
        flowPreviousGray_ = gray.clone();
        out.opticalFlowPixelsPerSecond = opticalFlowPixelsPerSecond_;
        out.travelledPixels = travelledPixels_;
        return;
    }
    std::vector<cv::Point2f> current;
    std::vector<uchar> status;
    std::vector<float> errors;
    cv::calcOpticalFlowPyrLK(flowPreviousGray_, gray, previousFeatures_, current, status, errors,
                             cv::Size(19, 19), 3,
                             cv::TermCriteria(cv::TermCriteria::EPS | cv::TermCriteria::COUNT, 24, 0.02));
    std::vector<float> dxs, dys, magnitudes;
    std::vector<cv::Point2f> good;
    for (size_t i = 0; i < status.size(); ++i) {
        if (!status[i] || errors[i] > 35.0f) continue;
        const float dx = current[i].x - previousFeatures_[i].x;
        const float dy = current[i].y - previousFeatures_[i].y;
        const float magnitude = std::sqrt(dx * dx + dy * dy);
        if (magnitude < 0.25f || magnitude > 35.0f) continue;
        dxs.push_back(dx);
        dys.push_back(dy);
        magnitudes.push_back(magnitude);
        good.push_back(current[i]);
    }
    if (!magnitudes.empty()) {
        const float medianMagnitude = median(magnitudes);
        const float dx = median(dxs);
        const float dy = median(dys);
        opticalFlowPixelsPerSecond_ = medianMagnitude / elapsedSeconds;
        travelledPixels_ += medianMagnitude;
        previousFeatures_ = std::move(good);
        if (previousFeatures_.size() < 40) cv::goodFeaturesToTrack(gray, previousFeatures_, 220, 0.012, 12.0);
        (void)dx;
        (void)dy;
    } else {
        previousFeatures_.clear();
    }
    flowPreviousGray_ = gray.clone();
    out.opticalFlowPixelsPerSecond = opticalFlowPixelsPerSecond_;
    out.travelledPixels = travelledPixels_;
}

void ClassicalVisionEngine::estimateVisualWeather(const cv::Mat& frame, PiVisionResult& out) {
    const cv::Rect skyRect(0, 0, frame.cols, std::max(1, static_cast<int>(frame.rows * 0.38f)));
    cv::Mat sky = frame(skyRect);
    cv::Mat hsv;
    cv::cvtColor(sky, hsv, cv::COLOR_BGR2HSV);
    cv::Mat blueMask, grayMask, darkMask;
    cv::inRange(hsv, cv::Scalar(85, 45, 70), cv::Scalar(135, 255, 255), blueMask);
    cv::inRange(hsv, cv::Scalar(0, 0, 80), cv::Scalar(179, 55, 235), grayMask);
    cv::inRange(hsv, cv::Scalar(0, 0, 0), cv::Scalar(179, 255, 65), darkMask);
    const double total = std::max(1, sky.rows * sky.cols);
    const float blueRatio = static_cast<float>(cv::countNonZero(blueMask) / total);
    const float grayRatio = static_cast<float>(cv::countNonZero(grayMask) / total);
    const float darkRatio = static_cast<float>(cv::countNonZero(darkMask) / total);
    cv::Mat gray;
    cv::cvtColor(sky, gray, cv::COLOR_BGR2GRAY);
    cv::Scalar meanValue, stdValue;
    cv::meanStdDev(gray, meanValue, stdValue);

    if (darkRatio > 0.48f || meanValue[0] < 55.0) {
        weather_ = "Тёмный кадр / низкая видимость";
    } else if (blueRatio > 0.18f) {
        weather_ = "Есть признаки ясного неба";
    } else if (grayRatio > 0.48f && stdValue[0] < 38.0) {
        weather_ = "Похоже на облачное небо";
    } else if (meanValue[0] < 100.0 && stdValue[0] < 32.0) {
        weather_ = "Пасмурно или недостаточно света";
    } else {
        weather_ = "Погодные признаки неоднозначны";
    }
    out.weather = weather_ + " · только визуальная оценка";
}

void ClassicalVisionEngine::localizeOnMap(const cv::Mat& frame, PiVisionResult& out) {
    lastNearestWaypoint_ = -1;
    lastHasMapTarget_ = false;
    if (mapDescriptors_.empty() || mapKeypoints_.size() < 12) {
        out.mapStatus = routeMap_.hasWaypoints() ? "Маршрут загружен; привязка к кадру недоступна" : "Карта не загружена";
        lastMapLocalized_ = false;
        lastMapStatus_ = out.mapStatus;
        lastNearestWaypoint_ = -1;
        lastHasMapTarget_ = false;
        return;
    }
    cv::Mat gray;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
    cv::resize(gray, gray, cv::Size(480, 360), 0.0, 0.0, cv::INTER_AREA);
    std::vector<cv::KeyPoint> frameKeypoints;
    cv::Mat frameDescriptors;
    orb_->detectAndCompute(gray, cv::noArray(), frameKeypoints, frameDescriptors);
    if (frameDescriptors.empty() || frameKeypoints.size() < 12) {
        out.mapStatus = "Недостаточно визуальных ориентиров для карты";
        lastMapLocalized_ = false;
        lastMapStatus_ = out.mapStatus;
        lastNearestWaypoint_ = -1;
        lastHasMapTarget_ = false;
        return;
    }

    std::vector<std::vector<cv::DMatch>> knn;
    matcher_->knnMatch(frameDescriptors, mapDescriptors_, knn, 2);
    std::vector<cv::Point2f> sourcePoints, mapPoints;
    for (const auto& pair : knn) {
        if (pair.size() < 2 || pair[0].distance >= 0.76f * pair[1].distance) continue;
        sourcePoints.push_back(frameKeypoints[pair[0].queryIdx].pt);
        mapPoints.push_back(mapKeypoints_[pair[0].trainIdx].pt);
    }
    if (sourcePoints.size() < 12) {
        out.mapStatus = "Карта не совпадает с видом камеры (мало совпадений)";
        lastMapLocalized_ = false;
        lastMapStatus_ = out.mapStatus;
        lastNearestWaypoint_ = -1;
        lastHasMapTarget_ = false;
        return;
    }
    cv::Mat inlierMask;
    cv::Mat homography = cv::findHomography(sourcePoints, mapPoints, cv::RANSAC, 4.0, inlierMask);
    if (homography.empty() || inlierMask.empty()) {
        out.mapStatus = "Не удалось привязать кадр к карте";
        lastMapLocalized_ = false;
        lastMapStatus_ = out.mapStatus;
        lastNearestWaypoint_ = -1;
        lastHasMapTarget_ = false;
        return;
    }
    const int inliers = cv::countNonZero(inlierMask);
    if (inliers < 9 || inliers < static_cast<int>(sourcePoints.size() * 0.28f)) {
        out.mapStatus = "Ненадёжное совпадение карты и камеры";
        lastMapLocalized_ = false;
        lastMapStatus_ = out.mapStatus;
        lastNearestWaypoint_ = -1;
        lastHasMapTarget_ = false;
        return;
    }

    std::vector<cv::Point2f> cameraCenter{cv::Point2f(240.0f, 180.0f)}, mappedCenter;
    cv::perspectiveTransform(cameraCenter, mappedCenter, homography);
    if (mappedCenter.empty() || !std::isfinite(mappedCenter[0].x) || !std::isfinite(mappedCenter[0].y) ||
        mappedCenter[0].x < 0.0f || mappedCenter[0].y < 0.0f ||
        mappedCenter[0].x >= routeMap_.imageBgr().cols || mappedCenter[0].y >= routeMap_.imageBgr().rows) {
        out.mapStatus = "Результат привязки вышел за пределы карты";
        lastMapLocalized_ = false;
        lastMapStatus_ = out.mapStatus;
        lastNearestWaypoint_ = -1;
        lastHasMapTarget_ = false;
        return;
    }
    out.mapLocalized = true;
    out.mapPosition = mappedCenter[0];
    out.mapStatus = "Карта сопоставлена по ORB · совпадений: " + std::to_string(inliers);
    lastMapLocalized_ = true;
    lastMapPosition_ = mappedCenter[0];
    lastMapStatus_ = out.mapStatus;

    if (routeMap_.hasWaypoints()) {
        const auto next = routeMap_.nearestWaypoint(out.mapPosition);
        if (next) {
            out.nearestWaypointId = *next;
            lastNearestWaypoint_ = *next;
            const auto found = std::find_if(routeMap_.waypoints().begin(), routeMap_.waypoints().end(),
                                            [&](const MapWaypoint& p) { return p.id == *next; });
            if (found != routeMap_.waypoints().end()) {
                const float arrivalRadius = std::max(12.0f, 0.018f * std::max(routeMap_.imageBgr().cols, routeMap_.imageBgr().rows));
                if (cv::norm(found->position - out.mapPosition) < arrivalRadius) ++mapArrivalFrames_;
                else mapArrivalFrames_ = 0;
                if (mapArrivalFrames_ >= 3) {
                    routeMap_.markReached(*next);
                    mapArrivalFrames_ = 0;
                    const auto following = routeMap_.nearestWaypoint(out.mapPosition);
                    out.nearestWaypointId = following ? *following : -1;
                    lastNearestWaypoint_ = out.nearestWaypointId;
                }
                const auto active = std::find_if(routeMap_.waypoints().begin(), routeMap_.waypoints().end(),
                                                 [&](const MapWaypoint& p) { return p.id == out.nearestWaypointId; });
                if (active != routeMap_.waypoints().end()) {
                    cv::Mat inverseHomography;
                    if (cv::invert(homography, inverseHomography, cv::DECOMP_SVD) != 0.0) {
                        std::vector<cv::Point2f> mapGoal{active->position}, cameraGoal;
                        cv::perspectiveTransform(mapGoal, cameraGoal, inverseHomography);
                        if (!cameraGoal.empty() && std::isfinite(cameraGoal[0].x) && std::isfinite(cameraGoal[0].y)) {
                            const float targetX = cameraGoal[0].x * (static_cast<float>(frame.cols) / 480.0f);
                            const float targetY = cameraGoal[0].y * (static_cast<float>(frame.rows) / 360.0f);
                            if (targetX >= 0.0f && targetY >= frame.rows * 0.25f &&
                                targetX < frame.cols && targetY < frame.rows * 0.98f) {
                                out.hasMapTarget = true;
                                out.mapTarget = cv::Point(cvRound(targetX), cvRound(targetY));
                                lastHasMapTarget_ = true;
                                lastMapTarget_ = out.mapTarget;
                            }
                        }
                    }
                }
            }
        }
    }
}

bool ClassicalVisionEngine::segmentHitsRect(const cv::Point& from, const cv::Point& to, const cv::Rect& rect) {
    return lineIntersectsRect(from, to, rect);
}

void ClassicalVisionEngine::chooseNearestSafeTarget(const cv::Size& size, PiVisionResult& out) {
    const int width = size.width;
    const int height = size.height;
    float roadCenter = width * 0.5f;
    float roadLeft = width * 0.18f;
    float roadRight = width * 0.82f;
    // Prefer the detected yellow corridor when sufficiently clear line fragments exist.
    std::vector<float> leftXs, rightXs;
    for (const auto& line : out.yellowLines) {
        const float dx = static_cast<float>(line[2] - line[0]);
        const float dy = static_cast<float>(line[3] - line[1]);
        if (std::abs(dy) < 5.0f) continue;
        const float slope = dx / dy;
        if (std::abs(slope) < 0.08f || std::abs(slope) > 3.5f) continue;
        const float xBottom = line[0] + slope * (height * 0.88f - line[1]);
        if (xBottom < width * 0.5f) leftXs.push_back(xBottom);
        else rightXs.push_back(xBottom);
    }
    if (!leftXs.empty() && !rightXs.empty()) {
        roadLeft = median(leftXs);
        roadRight = median(rightXs);
        if (roadRight - roadLeft < width * 0.22f || roadRight - roadLeft > width * 0.94f) {
            roadLeft = width * 0.18f;
            roadRight = width * 0.82f;
        }
    }
    roadCenter = (roadLeft + roadRight) * 0.5f;
    if (out.hasMapTarget && out.mapTarget.y > height * 0.30f && out.mapTarget.y < height * 0.98f) {
        roadCenter = std::clamp(static_cast<float>(out.mapTarget.x), roadLeft, roadRight);
    }
    const float margin = width * 0.055f;
    roadLeft = std::clamp(roadLeft + margin, width * 0.08f, width * 0.48f);
    roadRight = std::clamp(roadRight - margin, width * 0.52f, width * 0.92f);
    if (roadRight <= roadLeft) {
        roadLeft = width * 0.28f;
        roadRight = width * 0.72f;
    }

    std::vector<cv::Rect> hazards;
    for (const auto& detection : out.detections) {
        if (detection.isPerson || detection.isVehicleCandidate) hazards.push_back(detection.box);
    }
    for (const auto& motion : out.movingObjects) {
        if (motion.width > width * 0.045f && motion.height > height * 0.055f && motion.y + motion.height > height * 0.62f)
            hazards.push_back(motion);
    }

    const cv::Point origin(width / 2, height - 2);
    const int targetY = static_cast<int>(height * 0.58f);
    float bestCost = std::numeric_limits<float>::max();
    float bestX = roadCenter;
    bool hasSafeCandidate = false;
    constexpr int candidateCount = 13;
    for (int i = 0; i < candidateCount; ++i) {
        const float t = static_cast<float>(i) / (candidateCount - 1);
        const float x = roadLeft + t * (roadRight - roadLeft);
        const cv::Point target(cvRound(x), targetY);
        bool blocked = false;
        for (const auto& hazard : hazards) {
            const int marginX = std::max(8, static_cast<int>(width * 0.025f));
            const int marginY = std::max(8, static_cast<int>(height * 0.025f));
            const cv::Rect expanded = clipped(cv::Rect(hazard.x - marginX, hazard.y - marginY,
                                                       hazard.width + 2 * marginX, hazard.height + 2 * marginY), size);
            if (segmentHitsRect(origin, target, expanded)) { blocked = true; break; }
        }
        if (blocked) continue;
        const float centerCost = std::abs(x - roadCenter) / width;
        const float continuityCost = previousTargetX_ >= 0.0f ? std::abs(x - previousTargetX_) / width : 0.0f;
        const float cost = centerCost * 1.0f + continuityCost * 0.35f;
        if (cost < bestCost) {
            bestCost = cost;
            bestX = x;
            hasSafeCandidate = true;
        }
    }

    if (!hasSafeCandidate) {
        ++blockedFrames_;
        out.stopSignal = blockedFrames_ >= 2 || !hazards.empty();
        out.direction = "СТОП";
        out.stopReason = hazards.empty() ? "Нет свободной траектории / границы дороги неясны" : "Препятствие перекрывает все проверенные траектории";
        out.hasTarget = false;
        return;
    }

    blockedFrames_ = 0;
    const bool obstacleAhead = !hazards.empty();
    out.bypassSelected = obstacleAhead && std::abs(bestX - roadCenter) > width * 0.075f;
    previousTargetX_ = bestX;
    out.hasTarget = true;
    out.target = cv::Point(cvRound(bestX), targetY);
    const float directionOffset = bestX - width * 0.5f;
    if (std::abs(directionOffset) < width * 0.055f) out.direction = "ПРЯМО";
    else if (directionOffset < 0.0f) out.direction = out.bypassSelected ? "ОБХОД СЛЕВА" : "ЛЕВЕЕ";
    else out.direction = out.bypassSelected ? "ОБХОД СПРАВА" : "ПРАВЕЕ";
    out.stopSignal = false;
    if (out.bypassSelected) out.stopReason = "Выбрана свободная соседняя траектория";
    else if (obstacleAhead) out.stopReason = "Объект вне выбранной траектории";
    else out.stopReason.clear();
}

PiVisionResult ClassicalVisionEngine::processRgba(const std::vector<uint8_t>& rgba, int width, int height) {
    PiVisionResult result;
    if (width <= 0 || height <= 0 || rgba.size() < static_cast<size_t>(width) * height * 4U) {
        result.stopSignal = true;
        result.direction = "СТОП";
        result.stopReason = "Некорректный кадр камеры";
        return result;
    }
    const auto started = std::chrono::steady_clock::now();
    ++frameNumber_;
    cv::Mat rgbaView(height, width, CV_8UC4, const_cast<uint8_t*>(rgba.data()));
    cv::Mat frame;
    cv::cvtColor(rgbaView, frame, cv::COLOR_RGBA2BGR);
    if (frame.cols > 800) cv::resize(frame, frame, cv::Size(800, 600), 0.0, 0.0, cv::INTER_AREA);

    detectRoad(frame, result);
    detectMotionAndStatic(frame, result);
    if (frameNumber_ % 2 == 0 || cachedPeople_.empty()) {
        detectPeople(frame, cachedPeople_);
        detectVehicleCandidates(frame, cachedVehicles_);
    }
    result.detections = cachedPeople_;
    result.detections.insert(result.detections.end(), cachedVehicles_.begin(), cachedVehicles_.end());

    cv::Mat gray;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
    estimateOpticalFlow(gray, result);
    if (frameNumber_ % 8 == 0 || frameNumber_ == 1) estimateVisualWeather(frame, result);
    result.weather = weather_;
    if (frameNumber_ % 5 == 0 && routeMap_.hasImage()) {
        localizeOnMap(frame, result);
    } else if (routeMap_.hasImage()) {
        result.mapLocalized = lastMapLocalized_;
        result.mapPosition = lastMapPosition_;
        result.mapStatus = lastMapStatus_;
        result.nearestWaypointId = lastNearestWaypoint_;
        result.hasMapTarget = lastHasMapTarget_;
        result.mapTarget = lastMapTarget_;
    } else {
        result.mapStatus = routeMap_.hasWaypoints() ? "Маршрутный CSV загружен без фото карты" : "Карта не загружена";
        result.nearestWaypointId = routeMap_.nextWaypoint().value_or(-1);
    }

    chooseNearestSafeTarget(frame.size(), result);
    if (result.stopSignal) stopLatchFrames_ = 8;
    else if (stopLatchFrames_ > 0) --stopLatchFrames_;
    if (stopLatchFrames_ > 0 && !result.bypassSelected) {
        result.stopSignal = true;
        result.direction = "СТОП";
        if (result.stopReason.empty()) result.stopReason = "Проверка безопасного продолжения пути";
    }

    if (routeMap_.hasWaypoints() && result.nearestWaypointId < 0 && result.mapLocalized) {
        const auto nearest = routeMap_.nearestWaypoint(result.mapPosition);
        if (nearest) result.nearestWaypointId = *nearest;
    }
    const auto ended = std::chrono::steady_clock::now();
    result.processingMs = std::chrono::duration<float, std::milli>(ended - started).count();
    return result;
}

bool ClassicalVisionEngine::confirmNextWaypoint() {
    const auto next = routeMap_.nextWaypoint();
    return next ? routeMap_.markReached(*next) : false;
}
