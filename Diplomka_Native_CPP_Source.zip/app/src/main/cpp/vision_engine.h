#pragma once
#include <array>
#include <cstdint>
#include <string>
#include <vector>
#if defined(__ANDROID__)
#include <android/asset_manager.h>
#else
struct AAssetManager;
#endif
#include "pi_vision_engine.h"

struct RectF { float left=0, top=0, right=0, bottom=0; };
struct Detection {
    int classId=-1;
    std::string label;
    float confidence=0;
    RectF box;
    bool possibleStatue=false;
};
struct BodyPoint { float x=0, y=0, confidence=0; };
struct PersonPose { RectF box; float confidence=0; std::array<BodyPoint,17> keypoints{}; };
struct VisionFrame {
    std::vector<Detection> detections;
    std::vector<PersonPose> people;
    bool detectorReady=false;
    bool poseReady=false;
    float inferenceMs=0;
    int frameWidth=0, frameHeight=0;
    bool stopSignal=false;
    bool hasTarget=false;
    float targetX=0, targetY=0;
    bool bypassSelected=false;
    std::string direction="ОЖИДАНИЕ";
    std::string stopReason;
    std::string weather="Оценка ожидает кадры";
    std::string mapStatus="Карта не загружена";
    int nearestWaypointId=-1;
    bool mapLocalized=false;
    float opticalFlowPixelsPerSecond=0;
    float travelledPixels=0;
};

class VisionEngine {
public:
    bool initialize(AAssetManager* assets);
    VisionFrame processRgba(const uint8_t* rgba, int width, int height, bool enabled, bool runPoseThisFrame);
    bool isDetectorReady() const { return initialized_; }
    bool isPoseReady() const { return false; }
private:
    ClassicalVisionEngine engine_;
    bool initialized_=false;
};
