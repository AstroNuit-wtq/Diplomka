#pragma once

#include <cstdint>
#include <string>

// A process-wide, thread-safe log of Diplomka application events.
// It intentionally records app-owned events only; Android's global logcat is
// not readable by ordinary applications on modern Android versions.
void appLogWrite(int priority, const char* tag, const char* format, ...);
std::string appLogSnapshot();
uint64_t appLogLineCount();
