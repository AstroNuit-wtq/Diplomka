#include <android_native_app_glue.h>

#include <algorithm>
#include <array>
#include <unordered_map>
#include <atomic>
#include <chrono>
#include <cfloat>
#include <condition_variable>
#include <cmath>
#include <cstdint>
#include <deque>
#include <functional>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include <android/log.h>
#include <android/native_activity.h>
#include <android/configuration.h>
#include <android/input.h>
#include <android/native_window.h>
#include <android/sensor.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <jni.h>

#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"

#include "camera_engine.h"
#include "sensor_engine.h"
#include "vision_engine.h"

#define LOG_TAG "DiplomkaNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
constexpr int kSensorLooperId = 3;
constexpr int kCameraPermissionRequestCode = 714;
constexpr int kLocationPermissionRequestCode = 715;

struct GpsFix {
    bool available = false;
    double latitude = 0.0;
    double longitude = 0.0;
    float accuracyMeters = 0.0f;
    int64_t timestampMs = 0;
};

struct EglState {
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    int width = 0;
    int height = 0;
};

class AppState {
public:
    explicit AppState(android_app* app) : app_(app) {
        addLog("Приложение запущено: C++ / NDK");
        inferenceThread_ = std::thread([this]() { inferenceLoop(); });
    }

    ~AppState() {
        // Stop camera callbacks before shutting down the consumer thread.
        camera_.stop();
        sensors_.stop();
        {
            std::lock_guard<std::mutex> lock(inferenceMutex_);
            stopInference_ = true;
            pendingInference_.reset();
        }
        inferenceCv_.notify_all();
        if (inferenceThread_.joinable()) inferenceThread_.join();
    }

    void onFrame(std::vector<uint8_t>&& rgba, int width, int height) {
        const uint64_t frameNumber = cameraFrameCount_.fetch_add(1) + 1;
        const bool runInference = aiEnabled_.load() && (frameNumber % 3 == 0);
        const bool runPose = (frameNumber % 12) == 0;

        std::vector<uint8_t> inferencePixels;
        if (runInference) inferencePixels = rgba;
        {
            std::lock_guard<std::mutex> lock(frameMutex_);
            latestRgba_ = std::move(rgba);
            frameWidth_ = width;
            frameHeight_ = height;
            ++frameVersion_;
        }

        if (runInference) {
            {
                std::lock_guard<std::mutex> lock(inferenceMutex_);
                // Keep only the newest pending frame; never build an unbounded queue.
                pendingInference_ = PendingInferenceFrame{
                    std::move(inferencePixels), width, height, runPose, frameNumber
                };
            }
            inferenceCv_.notify_one();
        }
    }

    void addLog(const std::string& message) {
        std::lock_guard<std::mutex> lock(logMutex_);
        logs_.push_back(message);
        trimLogs();
    }

    std::vector<std::string> getLogs() {
        std::lock_guard<std::mutex> lock(logMutex_);
        return {logs_.begin(), logs_.end()};
    }

    void trimLogs() {
        while (logs_.size() > 80) logs_.pop_front();
    }

    bool cameraDesired = true;
    bool showLog = true;
    bool toolbarExpanded = false;
    std::atomic<bool> aiEnabled_{true};
    bool showMap = false;
    bool torchEnabled = false;
    bool cameraPermissionRequested = false;
    bool locationPermissionRequested = false;
    bool permissionDialogSent = false;
    bool locationDialogSent = false;
    bool touchDown = false;
    float uiScale = 1.0f;
    int touchEvents = 0;
    std::chrono::steady_clock::time_point cameraAttemptAt{};
    std::chrono::steady_clock::time_point nextCameraRetryAt{};
    std::chrono::steady_clock::time_point lastCameraFrameAt{};
    uint64_t lastObservedCameraFrames = 0;
    int cameraRetryCount = 0;
    bool visionInitialized = false;
    bool hasGpsPermission = false;
    bool hasCameraPermission = false;
    bool hasWindow = false;
    bool hasCameraError = false;
    std::string cameraStatus = "Ожидание разрешения камеры";
    GpsFix gps;
    std::atomic<uint64_t> cameraFrameCount_{0};
    std::chrono::steady_clock::time_point lastGpsPoll{};
    std::chrono::steady_clock::time_point lastPermissionPoll{};
    std::chrono::steady_clock::time_point lastUiSecond{};
    int fps = 0;
    float currentHeading = 0.0f;
    bool hasHeading = false;
    std::atomic<float> inferenceMs{0.0f};
    int previewTextureWidth = 0;
    int previewTextureHeight = 0;
    uint64_t uploadedFrameVersion = 0;
    GLuint previewTexture = 0;

    android_app* app_ = nullptr;
    CameraEngine camera_;
    SensorEngine sensors_;
    VisionEngine vision_;
    std::mutex frameMutex_;
    std::vector<uint8_t> latestRgba_;
    int frameWidth_ = 0;
    int frameHeight_ = 0;
    uint64_t frameVersion_ = 0;
    VisionFrame latestVision_;
    std::mutex logMutex_;
    std::deque<std::string> logs_;

private:
    struct PendingInferenceFrame {
        std::vector<uint8_t> rgba;
        int width = 0;
        int height = 0;
        bool runPose = false;
        uint64_t frameNumber = 0;
    };

    void inferenceLoop() {
        while (true) {
            PendingInferenceFrame frame;
            {
                std::unique_lock<std::mutex> lock(inferenceMutex_);
                inferenceCv_.wait(lock, [this]() { return stopInference_ || pendingInference_.has_value(); });
                if (stopInference_) return;
                frame = std::move(*pendingInference_);
                pendingInference_.reset();
            }

            if (!aiEnabled_.load()) continue;
            VisionFrame result = vision_.processRgba(
                frame.rgba.data(), frame.width, frame.height, true, frame.runPose);
            inferenceMs.store(result.inferenceMs);
            const size_t detectionCount = result.detections.size();
            {
                std::lock_guard<std::mutex> lock(frameMutex_);
                if (aiEnabled_.load()) latestVision_ = std::move(result);
            }
            if ((frame.frameNumber % 12 == 0) && detectionCount > 0) {
                addLog("Найдено объектов: " + std::to_string(detectionCount));
            }
        }
    }

    std::mutex inferenceMutex_;
    std::condition_variable inferenceCv_;
    std::optional<PendingInferenceFrame> pendingInference_;
    bool stopInference_ = false;
    std::thread inferenceThread_;
};

JNIEnv* attachJni(JavaVM* vm, bool* didAttach = nullptr) {
    if (didAttach) *didAttach = false;
    if (!vm) return nullptr;
    JNIEnv* env = nullptr;
    const jint status = vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (status == JNI_OK) return env;
    if (status == JNI_EDETACHED && vm->AttachCurrentThread(&env, nullptr) == JNI_OK) {
        if (didAttach) *didAttach = true;
        return env;
    }
    return nullptr;
}

void detachJni(JavaVM* vm, bool didAttach) {
    if (vm && didAttach) vm->DetachCurrentThread();
}

bool checkPermission(ANativeActivity* activity, const char* permission) {
    if (!activity || !activity->vm || !activity->clazz) return false;
    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) return false;
    jclass cls = env->GetObjectClass(activity->clazz);
    jmethodID method = env->GetMethodID(cls, "checkSelfPermission", "(Ljava/lang/String;)I");
    bool granted = false;
    if (method) {
        jstring name = env->NewStringUTF(permission);
        const jint result = env->CallIntMethod(activity->clazz, method, name);
        granted = (result == 0);
        env->DeleteLocalRef(name);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
    detachJni(activity->vm, attached);
    return granted;
}

void requestPermissions(ANativeActivity* activity, const std::vector<const char*>& permissionNames, int requestCode) {
    if (!activity || !activity->vm || !activity->clazz || permissionNames.empty()) return;
    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) return;
    jclass cls = env->GetObjectClass(activity->clazz);
    jmethodID method = env->GetMethodID(cls, "requestPermissions", "([Ljava/lang/String;I)V");
    if (method) {
        jclass stringClass = env->FindClass("java/lang/String");
        if (stringClass) {
            jobjectArray permissions = env->NewObjectArray(static_cast<jsize>(permissionNames.size()), stringClass, nullptr);
            if (permissions) {
                for (jsize i = 0; i < static_cast<jsize>(permissionNames.size()); ++i) {
                    jstring name = env->NewStringUTF(permissionNames[static_cast<size_t>(i)]);
                    env->SetObjectArrayElement(permissions, i, name);
                    env->DeleteLocalRef(name);
                }
                env->CallVoidMethod(activity->clazz, method, permissions, requestCode);
                env->DeleteLocalRef(permissions);
            }
            env->DeleteLocalRef(stringClass);
        }
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (cls) env->DeleteLocalRef(cls);
    detachJni(activity->vm, attached);
}

void requestCameraPermission(AppState& state) {
    if (state.hasCameraPermission || state.cameraPermissionRequested) return;
    state.cameraPermissionRequested = true;
    requestPermissions(state.app_->activity, {"android.permission.CAMERA"}, kCameraPermissionRequestCode);
    state.cameraStatus = "Ожидание разрешения камеры";
}

void requestLocationPermission(AppState& state) {
    if (state.hasGpsPermission || state.locationPermissionRequested) return;
    state.locationPermissionRequested = true;
    requestPermissions(state.app_->activity,
                       {"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"},
                       kLocationPermissionRequestCode);
    state.addLog("Запрошено разрешение геолокации");
}

GpsFix readLastKnownLocation(ANativeActivity* activity) {
    GpsFix fix;
    if (!activity || !activity->vm || !activity->clazz) return fix;
    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) return fix;

    jclass activityClass = env->GetObjectClass(activity->clazz);
    jmethodID getSystemService = env->GetMethodID(activityClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
    jobject locationManager = nullptr;
    if (getSystemService) {
        jstring serviceName = env->NewStringUTF("location");
        locationManager = env->CallObjectMethod(activity->clazz, getSystemService, serviceName);
        env->DeleteLocalRef(serviceName);
    }

    if (locationManager && !env->ExceptionCheck()) {
        jclass managerClass = env->GetObjectClass(locationManager);
        jmethodID getLastKnown = env->GetMethodID(managerClass, "getLastKnownLocation", "(Ljava/lang/String;)Landroid/location/Location;");
        jobject location = nullptr;
        const char* providers[] = {"gps", "network"};
        for (const char* provider : providers) {
            if (!getLastKnown) break;
            jstring providerName = env->NewStringUTF(provider);
            location = env->CallObjectMethod(locationManager, getLastKnown, providerName);
            env->DeleteLocalRef(providerName);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                location = nullptr;
            }
            if (location) break;
        }
        if (location) {
            jclass locationClass = env->GetObjectClass(location);
            jmethodID getLatitude = env->GetMethodID(locationClass, "getLatitude", "()D");
            jmethodID getLongitude = env->GetMethodID(locationClass, "getLongitude", "()D");
            jmethodID getAccuracy = env->GetMethodID(locationClass, "getAccuracy", "()F");
            jmethodID getTime = env->GetMethodID(locationClass, "getTime", "()J");
            if (getLatitude && getLongitude) {
                fix.latitude = env->CallDoubleMethod(location, getLatitude);
                fix.longitude = env->CallDoubleMethod(location, getLongitude);
                fix.accuracyMeters = getAccuracy ? env->CallFloatMethod(location, getAccuracy) : 0.0f;
                fix.timestampMs = getTime ? env->CallLongMethod(location, getTime) : 0;
                fix.available = !env->ExceptionCheck();
            }
            env->DeleteLocalRef(locationClass);
            env->DeleteLocalRef(location);
        }
        env->DeleteLocalRef(managerClass);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (locationManager) env->DeleteLocalRef(locationManager);
    env->DeleteLocalRef(activityClass);
    detachJni(activity->vm, attached);
    return fix;
}

void updatePermissionsAndServices(AppState& state) {
    const auto now = std::chrono::steady_clock::now();
    if (now - state.lastPermissionPoll > std::chrono::milliseconds(500)) {
        state.lastPermissionPoll = now;
        state.hasCameraPermission = checkPermission(state.app_->activity, "android.permission.CAMERA");
        state.hasGpsPermission = checkPermission(state.app_->activity, "android.permission.ACCESS_FINE_LOCATION") ||
                                 checkPermission(state.app_->activity, "android.permission.ACCESS_COARSE_LOCATION");
        if (!state.hasCameraPermission && !state.permissionDialogSent) {
            requestCameraPermission(state);
            state.permissionDialogSent = true;
        }
        if (state.hasCameraPermission) state.cameraPermissionRequested = false;
        if (state.hasGpsPermission) state.locationPermissionRequested = false;
    }

    if (state.hasCameraPermission && state.cameraDesired && state.hasWindow &&
        !state.camera_.isRunning() && state.cameraAttemptAt.time_since_epoch().count() != 0 &&
        state.camera_.lastErrorCode() != 0 && now >= state.nextCameraRetryAt) {
        ++state.cameraRetryCount;
        const int delaySeconds = std::min(12, 2 * state.cameraRetryCount);
        state.cameraStatus = "Камера завершилась с ошибкой " + std::to_string(state.camera_.lastErrorCode()) +
                             " · повтор через " + std::to_string(delaySeconds) + " с";
        state.addLog(state.cameraStatus);
        state.nextCameraRetryAt = now + std::chrono::seconds(delaySeconds);
        state.cameraAttemptAt = {};
    }

    if (!state.hasCameraPermission) {
        if (state.camera_.isRunning()) state.camera_.stop();
        if (state.cameraDesired) state.cameraStatus = "Нет разрешения на камеру · нажми Камера";
    } else if (!state.cameraDesired) {
        if (state.camera_.isRunning()) state.camera_.stop();
        state.cameraStatus = "Камера выключена";
    } else if (state.hasWindow && !state.camera_.isRunning() && now >= state.nextCameraRetryAt) {
        state.cameraStatus = "Подключение камеры…";
        const bool ok = state.camera_.start([&state](std::vector<uint8_t>&& rgba, int width, int height) {
            state.onFrame(std::move(rgba), width, height);
        });
        state.cameraAttemptAt = now;
        if (ok) {
            state.hasCameraError = false;
            state.lastCameraFrameAt = {};
            state.lastObservedCameraFrames = 0;
            state.cameraStatus = "Сессия запрошена · ожидаю подтверждение и первый кадр";
            state.addLog("Сессия камеры запрошена; ожидаются onReady и первый кадр");
        } else {
            state.hasCameraError = true;
            state.cameraStatus = "Не удалось открыть камеру · код " + std::to_string(state.camera_.lastErrorCode());
            state.nextCameraRetryAt = now + std::chrono::seconds(3);
            state.cameraAttemptAt = {};
            state.addLog(state.cameraStatus);
        }
    }

    if (state.camera_.isRunning()) {
        const uint64_t frames = state.camera_.frameCount();
        if (frames > state.lastObservedCameraFrames) {
            state.lastObservedCameraFrames = frames;
            state.lastCameraFrameAt = now;
            state.cameraRetryCount = 0;
            state.hasCameraError = false;
            state.cameraStatus = "Камера активна · кадров " + std::to_string(frames);
        }
        const auto frameReference = state.lastCameraFrameAt.time_since_epoch().count() != 0
            ? state.lastCameraFrameAt : state.cameraAttemptAt;
        if (frameReference.time_since_epoch().count() != 0 && now - frameReference > std::chrono::seconds(6)) {
            state.cameraStatus = frames == 0
                ? "Сессия камеры открыта, но кадров нет · перезапуск"
                : "Поток кадров остановился · перезапуск";
            state.addLog(state.cameraStatus);
            state.camera_.stop();
            ++state.cameraRetryCount;
            const int delaySeconds = std::min(12, 2 * state.cameraRetryCount);
            state.nextCameraRetryAt = now + std::chrono::seconds(delaySeconds);
            state.lastCameraFrameAt = {};
            state.lastObservedCameraFrames = 0;
        }
    }

    if (state.hasGpsPermission && state.showMap && now - state.lastGpsPoll > std::chrono::seconds(5)) {
        state.lastGpsPoll = now;
        const GpsFix candidate = readLastKnownLocation(state.app_->activity);
        if (candidate.available) state.gps = candidate;
    }
}

bool initEgl(ANativeWindow* window, EglState& egl) {
    const EGLint attributes[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_RED_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 0, EGL_STENCIL_SIZE, 0,
        EGL_NONE
    };
    egl.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (egl.display == EGL_NO_DISPLAY) return false;
    if (eglInitialize(egl.display, nullptr, nullptr) != EGL_TRUE) return false;
    EGLConfig config = nullptr;
    EGLint configCount = 0;
    if (eglChooseConfig(egl.display, attributes, &config, 1, &configCount) != EGL_TRUE || configCount < 1) return false;
    const EGLint contextAttributes[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    egl.context = eglCreateContext(egl.display, config, EGL_NO_CONTEXT, contextAttributes);
    if (egl.context == EGL_NO_CONTEXT) return false;
    egl.surface = eglCreateWindowSurface(egl.display, config, window, nullptr);
    if (egl.surface == EGL_NO_SURFACE) return false;
    if (eglMakeCurrent(egl.display, egl.surface, egl.surface, egl.context) != EGL_TRUE) return false;
    eglQuerySurface(egl.display, egl.surface, EGL_WIDTH, &egl.width);
    eglQuerySurface(egl.display, egl.surface, EGL_HEIGHT, &egl.height);
    return true;
}

void shutdownEgl(EglState& egl) {
    if (egl.display != EGL_NO_DISPLAY) {
        eglMakeCurrent(egl.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (egl.context != EGL_NO_CONTEXT) eglDestroyContext(egl.display, egl.context);
        if (egl.surface != EGL_NO_SURFACE) eglDestroySurface(egl.display, egl.surface);
        eglTerminate(egl.display);
    }
    egl = EglState{};
}

void updateTexture(AppState& state) {
    std::vector<uint8_t> pixels;
    int width = 0;
    int height = 0;
    uint64_t version = 0;
    {
        std::lock_guard<std::mutex> lock(state.frameMutex_);
        if (state.frameVersion_ == state.uploadedFrameVersion || state.latestRgba_.empty()) return;
        pixels = state.latestRgba_;
        width = state.frameWidth_;
        height = state.frameHeight_;
        version = state.frameVersion_;
    }
    if (!state.previewTexture) glGenTextures(1, &state.previewTexture);
    glBindTexture(GL_TEXTURE_2D, state.previewTexture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
    glBindTexture(GL_TEXTURE_2D, 0);
    state.previewTextureWidth = width;
    state.previewTextureHeight = height;
    state.uploadedFrameVersion = version;
}

std::string translateClass(const std::string& name) {
    return name;
}

void drawPoseOverlay(ImDrawList* draw, const PersonPose& pose, ImVec2 topLeft, ImVec2 imageSize, int frameW, int frameH) {
    static const int edges[][2] = {
        {5, 6}, {5, 7}, {7, 9}, {6, 8}, {8, 10}, {5, 11}, {6, 12}, {11, 12},
        {11, 13}, {13, 15}, {12, 14}, {14, 16}, {0, 1}, {0, 2}, {1, 3}, {2, 4}, {0, 5}, {0, 6}
    };
    const auto mapPoint = [&](const BodyPoint& point) {
        // Preview is rotated 90 degrees clockwise to match a portrait phone.
        const float x = 1.0f - point.y / static_cast<float>(frameH);
        const float y = point.x / static_cast<float>(frameW);
        return ImVec2(topLeft.x + x * imageSize.x, topLeft.y + y * imageSize.y);
    };
    for (const auto& edge : edges) {
        const BodyPoint& a = pose.keypoints[edge[0]];
        const BodyPoint& b = pose.keypoints[edge[1]];
        if (a.confidence < 0.35f || b.confidence < 0.35f) continue;
        draw->AddLine(mapPoint(a), mapPoint(b), IM_COL32(0, 230, 190, 230), 2.2f);
    }
    for (const auto& point : pose.keypoints) {
        if (point.confidence < 0.35f) continue;
        draw->AddCircleFilled(mapPoint(point), 3.2f, IM_COL32(255, 211, 80, 255));
    }
}

void drawCameraPreview(AppState& state, ImVec2 size) {
    ImGui::BeginChild("camera_preview", size, true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const ImVec2 avail = ImGui::GetContentRegionAvail();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    const ImVec2 imageSize(std::min(size.x - 12.0f, avail.x), std::min(size.y - 12.0f, avail.y));
    if (state.previewTexture && state.previewTextureWidth > 0 && state.previewTextureHeight > 0) {
        const ImVec2 p0(p.x, p.y);
        const ImVec2 p1(p.x + imageSize.x, p.y);
        const ImVec2 p2(p.x + imageSize.x, p.y + imageSize.y);
        const ImVec2 p3(p.x, p.y + imageSize.y);
        // Rotate the landscape camera stream 90 degrees clockwise.
        draw->AddImageQuad((ImTextureID)(intptr_t)state.previewTexture,
                           p0, p1, p2, p3,
                           ImVec2(0, 1), ImVec2(0, 0), ImVec2(1, 0), ImVec2(1, 1));

        VisionFrame vision;
        {
            std::lock_guard<std::mutex> lock(state.frameMutex_);
            vision = state.latestVision_;
        }
        const int frameW = vision.frameWidth > 0 ? vision.frameWidth : state.previewTextureWidth;
        const int frameH = vision.frameHeight > 0 ? vision.frameHeight : state.previewTextureHeight;
        for (const auto& detection : vision.detections) {
            const float x0 = 1.0f - detection.box.bottom / static_cast<float>(frameH);
            const float y0 = detection.box.left / static_cast<float>(frameW);
            const float x1 = 1.0f - detection.box.top / static_cast<float>(frameH);
            const float y1 = detection.box.right / static_cast<float>(frameW);
            ImVec2 a(p.x + x0 * imageSize.x, p.y + y0 * imageSize.y);
            ImVec2 b(p.x + x1 * imageSize.x, p.y + y1 * imageSize.y);
            draw->AddRect(a, b, IM_COL32(20, 235, 170, 255), 2.0f, 0, 2.0f);
            const std::string label = translateClass(detection.label) + " " + std::to_string(static_cast<int>(detection.confidence * 100.0f)) + "%";
            draw->AddText(ImVec2(a.x + 3, std::max(p.y + 2, a.y - 18)), IM_COL32(20, 235, 170, 255), label.c_str());
        }
        for (const auto& person : vision.people) drawPoseOverlay(draw, person, p, imageSize, frameW, frameH);
        draw->AddRect(p0, ImVec2(p.x + imageSize.x, p.y + imageSize.y), IM_COL32(88, 166, 255, 180), 5.0f);
    } else {
        draw->AddRectFilled(p, ImVec2(p.x + imageSize.x, p.y + imageSize.y), IM_COL32(18, 25, 34, 255), 6.0f);
        const char* message = state.cameraStatus.c_str();
        const ImVec2 textSize = ImGui::CalcTextSize(message);
        draw->AddText(ImVec2(p.x + (imageSize.x - textSize.x) * 0.5f, p.y + (imageSize.y - textSize.y) * 0.5f), IM_COL32(210, 220, 230, 255), message);
    }
    ImGui::Dummy(imageSize);
    ImGui::EndChild();
}

void drawLogPanel(AppState& state, float height) {
    if (!state.showLog) return;
    ImGui::BeginChild("log_panel", ImVec2(0, height), true, ImGuiWindowFlags_HorizontalScrollbar);
    ImGui::TextColored(ImVec4(0.46f, 0.77f, 0.96f, 1.0f), "ЖУРНАЛ СОБЫТИЙ");
    ImGui::SameLine();
    ImGui::TextDisabled("(кнопка LOG скрывает панель)");
    ImGui::Separator();
    const auto lines = state.getLogs();
    for (const auto& line : lines) ImGui::TextWrapped("• %s", line.c_str());
    ImGui::EndChild();
}

void actionButton(const char* id, const char* icon, const char* label, bool expanded,
                  bool active, ImVec2 size, const ImVec4& accent,
                  const std::function<void()>& onClick) {
    static std::unordered_map<std::string, double> pulseStart;
    ImGui::PushID(id);
    if (active) ImGui::PushStyleColor(ImGuiCol_Button, accent);
    const char* text = expanded ? label : icon;
    const bool clicked = ImGui::Button(text, size);
    const ImVec2 min = ImGui::GetItemRectMin();
    const ImVec2 max = ImGui::GetItemRectMax();
    if (active) ImGui::PopStyleColor();
    ImGui::PopID();

    const double now = ImGui::GetTime();
    if (clicked) {
        pulseStart[id] = now;
        onClick();
    }
    const auto it = pulseStart.find(id);
    if (it != pulseStart.end()) {
        const float progress = static_cast<float>((now - it->second) / 0.62);
        if (progress >= 0.0f && progress < 1.0f) {
            const float alpha = 1.0f - progress;
            const ImU32 glow = ImGui::ColorConvertFloat4ToU32(ImVec4(accent.x, accent.y, accent.z, 0.52f * alpha));
            ImDrawList* draw = ImGui::GetWindowDrawList();
            draw->AddRect(min, max, glow, 16.0f, ImDrawFlags_RoundCornersAll, 2.0f + 2.0f * alpha);
            const float x = min.x + (max.x - min.x) * progress;
            draw->AddLine(ImVec2(x, min.y + 7.0f), ImVec2(x, max.y - 7.0f), glow, 2.5f * alpha + 0.5f);
            for (int dot = 0; dot < 3; ++dot) {
                const float dx = min.x + std::fmod(progress * 1.7f + dot * 0.31f, 1.0f) * (max.x - min.x);
                draw->AddCircleFilled(ImVec2(dx, max.y - 4.0f), 1.8f * alpha + 0.3f, glow);
            }
        }
    }
}

void restartCamera(AppState& state) {
    state.cameraDesired = true;
    state.torchEnabled = false;
    state.camera_.stop();
    state.lastCameraFrameAt = {};
    state.lastObservedCameraFrames = 0;
    state.cameraAttemptAt = {};
    state.nextCameraRetryAt = std::chrono::steady_clock::now();
    if (!state.hasCameraPermission) {
        state.permissionDialogSent = false;
        state.cameraPermissionRequested = false;
        requestCameraPermission(state);
        state.cameraStatus = "Нужно разрешение камеры";
    } else {
        state.cameraStatus = "Перезапуск камеры…";
    }
    state.addLog("Пользователь запросил перезапуск камеры");
}

void drawToolbar(AppState& state) {
    ImGui::Separator();
    const float availableWidth = ImGui::GetContentRegionAvail().x;
    constexpr int buttonCount = 6;
    const float arrowWidth = 42.0f * state.uiScale;
    const float buttonHeight = 50.0f * state.uiScale;
    const float gap = ImGui::GetStyle().ItemSpacing.x;

    const auto drawCamera = [&](float width) {
        actionButton("camera", "C", "Камера", state.toolbarExpanded, state.cameraDesired,
                     ImVec2(width, buttonHeight), ImVec4(0.10f, 0.32f, 0.42f, 1.0f), [&]() {
            state.cameraDesired = !state.cameraDesired;
            if (!state.cameraDesired) {
                state.camera_.stop();
                state.cameraAttemptAt = {};
                state.cameraStatus = "Камера выключена";
                state.addLog("Камера остановлена пользователем");
            } else if (!state.hasCameraPermission) {
                state.permissionDialogSent = false;
                state.cameraPermissionRequested = false;
                requestCameraPermission(state);
            } else {
                state.nextCameraRetryAt = std::chrono::steady_clock::now();
                state.cameraStatus = "Запрос на запуск камеры…";
                state.addLog("Запрошен запуск камеры");
            }
        });
    };
    const auto drawLog = [&](float width) {
        actionButton("log", "L", "Лог", state.toolbarExpanded, state.showLog,
                     ImVec2(width, buttonHeight), ImVec4(0.12f, 0.34f, 0.25f, 1.0f), [&]() {
            state.showLog = !state.showLog;
        });
    };
    const auto drawAi = [&](float width) {
        actionButton("ai", "AI", "Нейросеть", state.toolbarExpanded, state.aiEnabled_.load(),
                     ImVec2(width, buttonHeight), ImVec4(0.18f, 0.30f, 0.48f, 1.0f), [&]() {
            state.aiEnabled_ = !state.aiEnabled_.load();
            if (!state.aiEnabled_.load()) {
                std::lock_guard<std::mutex> lock(state.frameMutex_);
                state.latestVision_ = VisionFrame{};
            }
            state.addLog(state.aiEnabled_.load() ? "Распознавание включено" : "Распознавание выключено");
        });
    };
    const auto drawMap = [&](float width) {
        actionButton("map", "GPS", "GPS / Карта", state.toolbarExpanded, state.showMap,
                     ImVec2(width, buttonHeight), ImVec4(0.12f, 0.34f, 0.25f, 1.0f), [&]() {
            state.showMap = !state.showMap;
            if (state.showMap && !state.hasGpsPermission) {
                state.locationPermissionRequested = false;
                requestLocationPermission(state);
            }
        });
    };
    const auto drawTorch = [&](float width) {
        actionButton("torch", "FLASH", "Фонарик", state.toolbarExpanded, state.torchEnabled,
                     ImVec2(width, buttonHeight), ImVec4(0.40f, 0.30f, 0.10f, 1.0f), [&]() {
            const bool requested = !state.torchEnabled;
            if (state.camera_.setTorch(requested)) {
                state.torchEnabled = requested;
                state.addLog(state.torchEnabled ? "Фонарик включён" : "Фонарик выключен");
            } else {
                state.torchEnabled = false;
                state.addLog("Фонарик недоступен: проверь вспышку и состояние камеры");
            }
        });
    };
    const auto drawRestart = [&](float width) {
        actionButton("restart", "↻", "Перезапуск", state.toolbarExpanded, false,
                     ImVec2(width, buttonHeight), ImVec4(0.48f, 0.24f, 0.30f, 1.0f), [&]() {
            restartCamera(state);
        });
    };
    const auto drawArrow = [&]() {
        ImGui::PushID("toolbar_expand");
        if (ImGui::Button(state.toolbarExpanded ? "‹" : "›", ImVec2(arrowWidth, buttonHeight))) {
            state.toolbarExpanded = !state.toolbarExpanded;
        }
        ImGui::PopID();
    };

    if (!state.toolbarExpanded) {
        const float buttonWidth = std::max(34.0f,
            (availableWidth - arrowWidth - gap * buttonCount) / buttonCount);
        drawCamera(buttonWidth); ImGui::SameLine();
        drawLog(buttonWidth); ImGui::SameLine();
        drawAi(buttonWidth); ImGui::SameLine();
        drawMap(buttonWidth); ImGui::SameLine();
        drawTorch(buttonWidth); ImGui::SameLine();
        drawRestart(buttonWidth); ImGui::SameLine();
        drawArrow();
        return;
    }

    // Expanded mode uses two rows so Russian action names remain readable on phones.
    const float buttonWidth = std::max(72.0f * state.uiScale,
        (availableWidth - arrowWidth - gap * 3.0f) / 3.0f);
    drawCamera(buttonWidth); ImGui::SameLine();
    drawLog(buttonWidth); ImGui::SameLine();
    drawAi(buttonWidth);
    ImGui::NewLine();
    drawMap(buttonWidth); ImGui::SameLine();
    drawTorch(buttonWidth); ImGui::SameLine();
    drawRestart(buttonWidth); ImGui::SameLine();
    drawArrow();
}

void drawMapPanel(AppState& state) {
    if (!state.showMap) return;
    ImGui::Spacing();
    ImGui::BeginChild("navigation_panel", ImVec2(0, 125.0f), true);
    ImGui::TextColored(ImVec4(0.50f, 0.80f, 1.0f, 1.0f), "НАВИГАЦИЯ / GPS");
    if (state.gps.available) {
        ImGui::Text("Широта: %.6f   Долгота: %.6f", state.gps.latitude, state.gps.longitude);
        ImGui::Text("Точность последней позиции: примерно %.0f м", state.gps.accuracyMeters);
        const int64_t age = state.gps.timestampMs > 0 ? (static_cast<int64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count()) - state.gps.timestampMs) / 1000 : -1;
        if (age >= 0) ImGui::Text("Возраст координат: %lld сек.", static_cast<long long>(age));
    } else {
        ImGui::TextWrapped("Последняя GPS-позиция недоступна. Проверь разрешение на геолокацию и включение служб местоположения.");
    }
    ImGui::TextDisabled("Карта, маршрут и непрерывное GPS-отслеживание пока не подключены.");
    ImGui::EndChild();
}

void drawUi(AppState& state, const EglState& egl) {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(static_cast<float>(egl.width), static_cast<float>(egl.height));
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(io.DisplaySize);
    ImGui::Begin("Diplomka Native UI", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoBackground);

    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 9.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10.0f, 8.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(5.0f, 5.0f));
    ImGui::TextColored(ImVec4(0.43f, 0.78f, 1.0f, 1.0f), "DIPLOMKA");
    ImGui::SameLine();
    ImGui::TextDisabled("NATIVE C++ · 2.2 CAMERA AUDIT");
    ImGui::SameLine(io.DisplaySize.x - 118.0f);
    const bool cameraHasFrames = state.camera_.isRunning() && state.camera_.frameCount() > 0;
    ImGui::TextColored(cameraHasFrames ? ImVec4(0.28f, 0.88f, 0.58f, 1.0f) : ImVec4(0.96f, 0.68f, 0.35f, 1.0f),
                       cameraHasFrames ? "● LIVE" : "● WAIT");

    ImGui::BeginChild("status_cards", ImVec2(0, 76.0f * state.uiScale), true);
    ImGui::Text("%s", state.cameraStatus.c_str());
    ImGui::SameLine();
    ImGui::TextDisabled("Кадры: %llu", static_cast<unsigned long long>(state.cameraFrameCount_.load()));
    ImGui::SameLine();
    ImGui::TextDisabled("Касания: %d", state.touchEvents);
    if (state.hasHeading) ImGui::Text("Компас  %.0f°", state.currentHeading);
    else ImGui::TextDisabled("Компас  калибровка / датчик недоступен");
    ImGui::SameLine();
    ImGui::Text("Объекты  %d", [&state]() { std::lock_guard<std::mutex> lock(state.frameMutex_); return static_cast<int>(state.latestVision_.detections.size()); }());
    ImGui::SameLine();
    ImGui::TextDisabled("ИИ %s", state.aiEnabled_.load() ? (state.vision_.isDetectorReady() ? "ON" : "модель?" ) : "OFF");
    ImGui::EndChild();

    const float bottomReserve = (state.toolbarExpanded ? 122.0f : 66.0f) * state.uiScale;
    const float logHeight = state.showLog ? 118.0f * state.uiScale : 0.0f;
    const float navHeight = state.showMap ? 136.0f * state.uiScale : 0.0f;
    const float remaining = ImGui::GetContentRegionAvail().y - bottomReserve - logHeight - navHeight - 13.0f * state.uiScale;
    const float previewHeight = std::max(160.0f * state.uiScale, std::min(remaining, ImGui::GetContentRegionAvail().x / 0.75f));
    drawCameraPreview(state, ImVec2(0, previewHeight));
    if (state.showMap) drawMapPanel(state);
    if (state.showLog) drawLogPanel(state, logHeight);
    drawToolbar(state);
    ImGui::PopStyleVar(3);
    ImGui::End();
}

void initializeImGui(ANativeWindow* window, float densityScale) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigInputTrickleEventQueue = false;
    ImFontConfig config;
    config.SizePixels = 16.5f * densityScale;
    ImFont* font = io.Fonts->AddFontFromFileTTF("/system/fonts/Roboto-Regular.ttf", config.SizePixels, &config, io.Fonts->GetGlyphRangesCyrillic());
    if (!font) io.Fonts->AddFontDefault();

    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.ScaleAllSizes(densityScale);
    style.WindowRounding = 22.0f * densityScale;
    style.ChildRounding = 20.0f * densityScale;
    style.FrameRounding = 17.0f * densityScale;
    style.PopupRounding = 18.0f * densityScale;
    style.ScrollbarRounding = 14.0f * densityScale;
    style.GrabRounding = 14.0f * densityScale;
    style.FramePadding = ImVec2(13.0f * densityScale, 12.0f * densityScale);
    style.ItemSpacing = ImVec2(8.0f * densityScale, 8.0f * densityScale);
    style.WindowPadding = ImVec2(14.0f * densityScale, 12.0f * densityScale);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.055f, 0.055f, 0.075f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.105f, 0.105f, 0.145f, 0.98f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.14f, 0.14f, 0.19f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.17f, 0.16f, 0.23f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.25f, 0.23f, 0.34f, 1.0f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.32f, 0.29f, 0.43f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.20f, 0.19f, 0.28f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.33f, 0.29f, 0.44f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.46f, 0.39f, 0.59f, 1.0f);
    style.Colors[ImGuiCol_Header] = ImVec4(0.26f, 0.23f, 0.37f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.82f, 0.74f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.76f, 0.68f, 0.96f, 1.0f);
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.91f, 0.85f, 1.0f, 1.0f);
    ImGui_ImplAndroid_Init(window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
}

void shutdownImGui() {
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
}

void handleAppCommand(android_app* app, int32_t command) {
    auto* state = static_cast<AppState*>(app->userData);
    if (!state) return;
    switch (command) {
        case APP_CMD_INIT_WINDOW: {
            if (app->window) {
                state->hasWindow = true;
                if (!state->visionInitialized) {
                    state->visionInitialized = state->vision_.initialize(app->activity->assetManager);
                    if (!state->visionInitialized) state->addLog("Не удалось загрузить модель обнаружения объектов");
                    else if (!state->vision_.isPoseReady()) state->addLog("Модель оценки позы не загрузилась");
                }
                state->sensors_.start(app->looper);
            }
            break;
        }
        case APP_CMD_TERM_WINDOW:
            state->camera_.stop();
            state->sensors_.stop();
            state->hasWindow = false;
            break;
        case APP_CMD_GAINED_FOCUS:
            break;
        case APP_CMD_LOST_FOCUS:
            break;
        case APP_CMD_LOW_MEMORY:
            state->addLog("Android сообщил о нехватке памяти");
            break;
        default:
            break;
    }
}

int32_t handleInput(android_app* app, AInputEvent* event) {
    auto* state = app ? static_cast<AppState*>(app->userData) : nullptr;
    if (!ImGui::GetCurrentContext()) return 0;

    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        const int32_t action = AMotionEvent_getAction(event) & AMOTION_EVENT_ACTION_MASK;
        if (action == AMOTION_EVENT_ACTION_DOWN && state) ++state->touchEvents;
        if (action == AMOTION_EVENT_ACTION_CANCEL) {
            ImGuiIO& io = ImGui::GetIO();
            io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen);
            io.AddMouseButtonEvent(0, false);
            io.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
            if (state) state->touchDown = false;
            return 1;
        }
        if (action == AMOTION_EVENT_ACTION_DOWN && state) state->touchDown = true;
        if (action == AMOTION_EVENT_ACTION_UP && state) state->touchDown = false;
    }

    // Use Dear ImGui's maintained Android backend for the actual pointer/key
    // event mapping; this avoids diverging from changes in Android input APIs.
    return ImGui_ImplAndroid_HandleInputEvent(event) ? 1 : 0;
}

void renderFrame(AppState& state, EglState& egl) {
    if (egl.display == EGL_NO_DISPLAY || egl.surface == EGL_NO_SURFACE) return;
    eglQuerySurface(egl.display, egl.surface, EGL_WIDTH, &egl.width);
    eglQuerySurface(egl.display, egl.surface, EGL_HEIGHT, &egl.height);
    glViewport(0, 0, egl.width, egl.height);
    glClearColor(0.025f, 0.040f, 0.060f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    updateTexture(state);
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
    drawUi(state, egl);
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(egl.display, egl.surface);
}
}

extern "C" void android_main(android_app* app) {
    app_dummy();
    AppState state(app);
    app->userData = &state;
    app->onAppCmd = &handleAppCommand;
    app->onInputEvent = &handleInput;

    EglState egl;
    bool eglReady = false;
    bool firstPermissionCheck = false;

    while (!app->destroyRequested) {
        int events = 0;
        android_poll_source* source = nullptr;
        const int ident = ALooper_pollAll(16, nullptr, &events, reinterpret_cast<void**>(&source));
        if (ident >= 0 && source) source->process(app, source);
        state.sensors_.poll();
        state.hasHeading = state.sensors_.hasHeading();
        state.currentHeading = state.sensors_.headingDegrees();

        if (!firstPermissionCheck && app->activity) {
            state.hasCameraPermission = checkPermission(app->activity, "android.permission.CAMERA");
            state.hasGpsPermission = checkPermission(app->activity, "android.permission.ACCESS_FINE_LOCATION") ||
                                     checkPermission(app->activity, "android.permission.ACCESS_COARSE_LOCATION");
            if (!state.hasCameraPermission) {
                requestCameraPermission(state);
                state.permissionDialogSent = true;
            }
            firstPermissionCheck = true;
        }
        updatePermissionsAndServices(state);

        if (app->window && state.hasWindow && !eglReady) {
            eglReady = initEgl(app->window, egl);
            if (eglReady) {
                LOGI("EGL initialized: %dx%d", egl.width, egl.height);
                const int densityDpi = app->config ? AConfiguration_getDensity(app->config) : ACONFIGURATION_DENSITY_DEFAULT;
                state.uiScale = densityDpi > 0 ? std::clamp(static_cast<float>(densityDpi) / 160.0f, 1.0f, 2.5f) : 1.0f;
                initializeImGui(app->window, state.uiScale);
            } else {
                LOGE("EGL initialization failed");
            }
        }
        if ((!app->window || !state.hasWindow) && eglReady) {
            if (ImGui::GetCurrentContext()) shutdownImGui();
            if (state.previewTexture) {
                glDeleteTextures(1, &state.previewTexture);
                state.previewTexture = 0;
            }
            shutdownEgl(egl);
            eglReady = false;
        }
        if (eglReady && ImGui::GetCurrentContext()) renderFrame(state, egl);
    }

    state.camera_.stop();
    state.sensors_.stop();
    if (eglReady) {
        if (ImGui::GetCurrentContext()) shutdownImGui();
        if (state.previewTexture) glDeleteTextures(1, &state.previewTexture);
        shutdownEgl(egl);
    }
}
