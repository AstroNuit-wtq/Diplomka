#include <android_native_app_glue.h>
#include <android/asset_manager.h>

#include <algorithm>
#include <array>
#include <unordered_map>
#include <atomic>
#include <chrono>
#include <cfloat>
#include <condition_variable>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <mutex>
#include <optional>
#include <pthread.h>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include <android/log.h>
#include "session_logger.h"
#include <android/native_activity.h>
#include <android/configuration.h>
#include <android/input.h>
#include <android/native_window.h>
#include <android/sensor.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <jni.h>

#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"

#include "camera_engine.h"
#include "sensor_engine.h"
#include "vision_engine.h"

#define LOG_TAG "DiplomkaNative"
#define LOGI(...) appLogWrite(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) appLogWrite(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) appLogWrite(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
constexpr float kPi = 3.14159265358979323846f;
constexpr int kCameraPermissionRequestCode = 714;
constexpr int kLocationPermissionRequestCode = 715;
constexpr int kMaxAutomaticCameraRetries = 1;
constexpr auto kCameraStartupTimeout = std::chrono::seconds(45);
constexpr auto kCameraFirstFrameTimeout = std::chrono::seconds(30);

struct GpsFix {
    bool available = false;
    double latitude = 0.0;
    double longitude = 0.0;
    float accuracyMeters = 0.0f;
    int64_t timestampMs = 0;
};

GpsFix readLastKnownLocation(ANativeActivity* activity);
bool saveSessionLogToDevice(ANativeActivity* activity, std::string& savedLocation);
void showAndroidToast(ANativeActivity* activity, const std::string& message);

struct EglState {
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    int width = 0;
    int height = 0;
};

class AppState {
public:
    explicit AppState(android_app* app) : app_(app) {
        LOGI("Application session started; version 2.7.0; ABI arm64-v8a");
        addLog("Приложение запущено: C++ / NDK · 2.7.0");
        inferenceThread_ = std::thread([this]() { inferenceLoop(); });
        gpsThread_ = std::thread([this]() { gpsLoop(); });
        logExportThread_ = std::thread([this]() { logExportLoop(); });
    }

    ~AppState() {
        // Join the dedicated Camera2 worker before any AppState members used by
        // its frame consumer are destroyed. A plain stop() is asynchronous.
        camera_.shutdown();
        sensors_.stop();
        {
            std::lock_guard<std::mutex> lock(logExportMutex_);
            logExportStop_ = true;
            logExportRequested_ = false;
        }
        logExportCv_.notify_all();
        if (logExportThread_.joinable()) logExportThread_.join();
        {
            std::lock_guard<std::mutex> lock(inferenceMutex_);
            stopInference_ = true;
            pendingInference_.reset();
        }
        inferenceCv_.notify_all();
        if (inferenceThread_.joinable()) inferenceThread_.join();
        {
            std::lock_guard<std::mutex> lock(gpsWorkerMutex_);
            gpsWorkerStop_ = true;
            gpsWorkRequested_ = false;
        }
        gpsWorkerCv_.notify_all();
        if (gpsThread_.joinable()) gpsThread_.join();
    }

    void requestVisionInitialization(AAssetManager* assets) {
        if (!assets || visionInitialized.load()) return;
        {
            std::lock_guard<std::mutex> lock(inferenceMutex_);
            if (visionLoadRequested_ || visionLoadAttempted_) return;
            assetManager_ = assets;
            visionLoadRequested_ = true;
        }
        addLog("Запуск локального классического анализа изображения");
        inferenceCv_.notify_one();
    }

    void requestGpsFix() {
        {
            std::lock_guard<std::mutex> lock(gpsWorkerMutex_);
            if (gpsWorkerStop_) return;
            gpsWorkRequested_ = true;
        }
        gpsWorkerCv_.notify_one();
    }

    std::optional<GpsFix> takeGpsFix() {
        std::lock_guard<std::mutex> lock(gpsWorkerMutex_);
        if (!pendingGpsFix_) return std::nullopt;
        auto fix = pendingGpsFix_;
        pendingGpsFix_.reset();
        return fix;
    }

    void onFrame(std::vector<uint8_t>&& rgba, int width, int height) {
        const uint64_t frameNumber = cameraFrameCount_.fetch_add(1) + 1;
        // Keep inference bounded on mid-range phones: detect every fifth frame,
        // and run pose estimation every twentieth frame.
        const bool runInference = visionEnabled_.load() && visionInitialized.load() && (frameNumber % 5 == 0);
        const bool runPose = (frameNumber % 20) == 0;

        std::vector<uint8_t> inferencePixels;
        if (runInference) inferencePixels = rgba;
        {
            std::lock_guard<std::mutex> lock(frameMutex_);
            latestRgba_ = std::move(rgba);
            frameWidth_ = width;
            frameHeight_ = height;
            ++frameVersion_;
        }

        if (runInference) {
            {
                std::lock_guard<std::mutex> lock(inferenceMutex_);
                // Keep only the newest pending frame; never build an unbounded queue.
                pendingInference_ = PendingInferenceFrame{
                    std::move(inferencePixels), width, height, runPose, frameNumber
                };
            }
            inferenceCv_.notify_one();
        }
    }

    void addLog(const std::string& message) {
        appLogWrite(ANDROID_LOG_INFO, "Diplomka-UI", "%s", message.c_str());
        std::lock_guard<std::mutex> lock(logMutex_);
        logs_.push_back(message);
        trimLogs();
    }

    void requestSessionLogExport() {
        {
            std::lock_guard<std::mutex> lock(logExportMutex_);
            if (logExportStop_) return;
            if (logExportRequested_ || logExportInProgress_) {
                addLog("Сбор полного лога уже выполняется");
                return;
            }
            logExportRequested_ = true;
        }
        addLog("Запрошен сбор полного журнала с момента запуска");
        logExportCv_.notify_one();
    }

    std::string takePendingToast() {
        std::lock_guard<std::mutex> lock(toastMutex_);
        std::string message = std::move(pendingToast_);
        pendingToast_.clear();
        return message;
    }

    std::vector<std::string> getLogs() {
        std::lock_guard<std::mutex> lock(logMutex_);
        return {logs_.begin(), logs_.end()};
    }

    void trimLogs() {
        while (logs_.size() > 80) logs_.pop_front();
    }

    bool cameraDesired = true;
    bool showLog = true;
    bool cameraAutoRetryExhausted = false;
    bool toolbarExpanded = false;
    std::atomic<bool> visionEnabled_{true};
    bool showMap = false;
    bool torchEnabled = false;
    bool cameraPermissionRequested = false;
    bool locationPermissionRequested = false;
    bool permissionDialogSent = false;
    bool locationDialogSent = false;
    bool touchDown = false;
    float uiScale = 1.0f;
    int touchEvents = 0;
    std::chrono::steady_clock::time_point cameraAttemptAt{};
    std::chrono::steady_clock::time_point nextCameraRetryAt{};
    std::chrono::steady_clock::time_point lastCameraFrameAt{};
    uint64_t lastObservedCameraFrames = 0;
    int cameraRetryCount = 0;
    int lastLoggedFlashState = -2;
    std::atomic<bool> visionInitialized{false};
    bool hasGpsPermission = false;
    bool hasCameraPermission = false;
    bool permissionStateLogged = false;
    bool lastLoggedCameraPermission = false;
    bool lastLoggedGpsPermission = false;
    bool hasWindow = false;
    bool hasCameraError = false;
    std::string cameraStatus = "Ожидание разрешения камеры";
    GpsFix gps;
    std::atomic<uint64_t> cameraFrameCount_{0};
    std::chrono::steady_clock::time_point lastGpsPoll{};
    std::chrono::steady_clock::time_point lastPermissionPoll{};
    std::chrono::steady_clock::time_point lastUiSecond{};
    int fps = 0;
    float currentHeading = 0.0f;
    bool hasHeading = false;
    std::atomic<float> inferenceMs{0.0f};
    int previewTextureWidth = 0;
    int previewTextureHeight = 0;
    uint64_t uploadedFrameVersion = 0;
    GLuint previewTexture = 0;

    android_app* app_ = nullptr;
    CameraEngine camera_;
    SensorEngine sensors_;
    VisionEngine vision_;
    std::mutex frameMutex_;
    std::vector<uint8_t> latestRgba_;
    int frameWidth_ = 0;
    int frameHeight_ = 0;
    uint64_t frameVersion_ = 0;
    VisionFrame latestVision_;
    std::mutex logMutex_;
    std::deque<std::string> logs_;

private:
    struct PendingInferenceFrame {
        std::vector<uint8_t> rgba;
        int width = 0;
        int height = 0;
        bool runPose = false;
        uint64_t frameNumber = 0;
    };

    void logExportLoop() {
        pthread_setname_np(pthread_self(), "diplomka-log-export");
        while (true) {
            {
                std::unique_lock<std::mutex> lock(logExportMutex_);
                logExportCv_.wait(lock, [this] { return logExportStop_ || logExportRequested_; });
                if (logExportStop_) return;
                logExportRequested_ = false;
                logExportInProgress_ = true;
            }

            appLogWrite(ANDROID_LOG_INFO, "Diplomka-Log", "Full session log export started");
            std::string savedLocation;
            const bool saved = app_ && app_->activity && saveSessionLogToDevice(app_->activity, savedLocation);
            if (saved) {
                appLogWrite(ANDROID_LOG_INFO, "Diplomka-Log", "Full session log exported to %s", savedLocation.c_str());
                addLog("Полный лог сохранён: " + savedLocation);
                std::lock_guard<std::mutex> lock(toastMutex_);
                pendingToast_ = "Лог сохранён: " + savedLocation;
            } else {
                appLogWrite(ANDROID_LOG_ERROR, "Diplomka-Log", "Full session log export failed");
                addLog("Не удалось сохранить лог · проверь свободное место и повтори попытку");
                std::lock_guard<std::mutex> lock(toastMutex_);
                pendingToast_ = "Не удалось сохранить лог";
            }

            {
                std::lock_guard<std::mutex> lock(logExportMutex_);
                logExportInProgress_ = false;
            }
        }
    }

    void inferenceLoop() {
        pthread_setname_np(pthread_self(), "diplomka-infer");
        bool visionInitAttempted = false;
        while (true) {
            PendingInferenceFrame frame;
            AAssetManager* assetsToLoad = nullptr;
            bool shouldInitializeVision = false;
            {
                std::unique_lock<std::mutex> lock(inferenceMutex_);
                inferenceCv_.wait(lock, [this]() {
                    return stopInference_ || visionLoadRequested_ || pendingInference_.has_value();
                });
                if (stopInference_) return;
                if (visionLoadRequested_ && !visionInitAttempted) {
                    assetsToLoad = assetManager_;
                    visionLoadRequested_ = false;
                    visionLoadAttempted_ = true;
                    shouldInitializeVision = assetsToLoad != nullptr;
                    visionInitAttempted = true;
                } else if (pendingInference_) {
                    frame = std::move(*pendingInference_);
                    pendingInference_.reset();
                }
            }

            // Vision initialization and frame processing must never block NativeActivity's
            // render/input thread. VisionEngine is owned exclusively by this worker.
            if (shouldInitializeVision) {
                const bool detectorReady = vision_.initialize(assetsToLoad);
                visionInitialized.store(detectorReady);
                if (!detectorReady) {
                    addLog("Не удалось запустить обработку изображения");
                } else if (!vision_.isPoseReady()) {
                    addLog("Классический анализ изображения запущен");
                } else {
                    addLog("Классический анализ изображения запущен");
                }
                continue;
            }

            if (frame.rgba.empty() || !visionEnabled_.load() || !visionInitialized.load()) continue;
            VisionFrame result = vision_.processRgba(
                frame.rgba.data(), frame.width, frame.height, true, frame.runPose);
            inferenceMs.store(result.inferenceMs);
            const size_t detectionCount = result.detections.size();
            {
                std::lock_guard<std::mutex> lock(frameMutex_);
                if (visionEnabled_.load()) latestVision_ = std::move(result);
            }
            if ((frame.frameNumber % 20 == 0) && detectionCount > 0) {
                addLog("Найдено объектов: " + std::to_string(detectionCount));
            }
        }
    }

    void gpsLoop() {
        while (true) {
            {
                std::unique_lock<std::mutex> lock(gpsWorkerMutex_);
                gpsWorkerCv_.wait(lock, [this] { return gpsWorkerStop_ || gpsWorkRequested_; });
                if (gpsWorkerStop_) return;
                gpsWorkRequested_ = false;
            }
            // Android LocationManager is queried off the render/UI thread.
            const GpsFix fix = app_ ? readLastKnownLocation(app_->activity) : GpsFix{};
            {
                std::lock_guard<std::mutex> lock(gpsWorkerMutex_);
                if (gpsWorkerStop_) return;
                pendingGpsFix_ = fix;
            }
        }
    }

    std::mutex inferenceMutex_;
    std::condition_variable inferenceCv_;
    std::optional<PendingInferenceFrame> pendingInference_;
    AAssetManager* assetManager_ = nullptr;
    bool visionLoadRequested_ = false;
    bool visionLoadAttempted_ = false;
    bool stopInference_ = false;
    std::thread inferenceThread_;
    std::mutex gpsWorkerMutex_;
    std::condition_variable gpsWorkerCv_;
    bool gpsWorkerStop_ = false;
    bool gpsWorkRequested_ = false;
    std::optional<GpsFix> pendingGpsFix_;
    std::thread gpsThread_;
    std::mutex logExportMutex_;
    std::condition_variable logExportCv_;
    bool logExportStop_ = false;
    bool logExportRequested_ = false;
    bool logExportInProgress_ = false;
    std::thread logExportThread_;
    std::mutex toastMutex_;
    std::string pendingToast_;
};

JNIEnv* attachJni(JavaVM* vm, bool* didAttach = nullptr) {
    if (didAttach) *didAttach = false;
    if (!vm) return nullptr;
    JNIEnv* env = nullptr;
    const jint status = vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (status == JNI_OK) return env;
    if (status == JNI_EDETACHED && vm->AttachCurrentThread(&env, nullptr) == JNI_OK) {
        if (didAttach) *didAttach = true;
        return env;
    }
    return nullptr;
}

void detachJni(JavaVM* vm, bool didAttach) {
    if (vm && didAttach) vm->DetachCurrentThread();
}

void logAndroidDeviceInfo(ANativeActivity* activity) {
    if (!activity || !activity->vm) return;
    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) {
        LOGE("Unable to attach JNI for device diagnostics");
        return;
    }

    auto readBuildString = [&](const char* fieldName) -> std::string {
        jclass buildClass = env->FindClass("android/os/Build");
        if (!buildClass || env->ExceptionCheck()) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            if (buildClass) env->DeleteLocalRef(buildClass);
            return "unknown";
        }
        const jfieldID field = env->GetStaticFieldID(buildClass, fieldName, "Ljava/lang/String;");
        jstring value = field ? static_cast<jstring>(env->GetStaticObjectField(buildClass, field)) : nullptr;
        std::string result = "unknown";
        if (value && !env->ExceptionCheck()) {
            const char* utf = env->GetStringUTFChars(value, nullptr);
            if (utf) {
                result = utf;
                env->ReleaseStringUTFChars(value, utf);
            }
            env->DeleteLocalRef(value);
        }
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(buildClass);
        return result;
    };

    jint sdk = activity->sdkVersion;
    jclass versionClass = env->FindClass("android/os/Build$VERSION");
    if (versionClass && !env->ExceptionCheck()) {
        const jfieldID sdkField = env->GetStaticFieldID(versionClass, "SDK_INT", "I");
        if (sdkField) sdk = env->GetStaticIntField(versionClass, sdkField);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (versionClass) env->DeleteLocalRef(versionClass);

    const std::string brand = readBuildString("BRAND");
    const std::string manufacturer = readBuildString("MANUFACTURER");
    const std::string model = readBuildString("MODEL");
    const std::string device = readBuildString("DEVICE");
    appLogWrite(ANDROID_LOG_INFO, "Diplomka-Device",
                "Device brand=%s manufacturer=%s model=%s device=%s AndroidSDK=%d NativeActivitySDK=%d",
                brand.c_str(), manufacturer.c_str(), model.c_str(), device.c_str(), sdk, activity->sdkVersion);
    detachJni(activity->vm, attached);
}

bool checkPermission(ANativeActivity* activity, const char* permission) {
    if (!activity || !activity->vm || !activity->clazz) return false;
    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) return false;
    jclass cls = env->GetObjectClass(activity->clazz);
    jmethodID method = env->GetMethodID(cls, "checkSelfPermission", "(Ljava/lang/String;)I");
    bool granted = false;
    if (method) {
        jstring name = env->NewStringUTF(permission);
        const jint result = env->CallIntMethod(activity->clazz, method, name);
        granted = (result == 0);
        env->DeleteLocalRef(name);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
    detachJni(activity->vm, attached);
    return granted;
}

void requestPermissions(ANativeActivity* activity, const std::vector<const char*>& permissionNames, int requestCode) {
    if (!activity || !activity->vm || !activity->clazz || permissionNames.empty()) return;
    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) return;
    jclass cls = env->GetObjectClass(activity->clazz);
    jmethodID method = env->GetMethodID(cls, "requestPermissions", "([Ljava/lang/String;I)V");
    if (method) {
        jclass stringClass = env->FindClass("java/lang/String");
        if (stringClass) {
            jobjectArray permissions = env->NewObjectArray(static_cast<jsize>(permissionNames.size()), stringClass, nullptr);
            if (permissions) {
                for (jsize i = 0; i < static_cast<jsize>(permissionNames.size()); ++i) {
                    jstring name = env->NewStringUTF(permissionNames[static_cast<size_t>(i)]);
                    env->SetObjectArrayElement(permissions, i, name);
                    env->DeleteLocalRef(name);
                }
                env->CallVoidMethod(activity->clazz, method, permissions, requestCode);
                env->DeleteLocalRef(permissions);
            }
            env->DeleteLocalRef(stringClass);
        }
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (cls) env->DeleteLocalRef(cls);
    detachJni(activity->vm, attached);
}

bool writeBytesToJavaOutputStream(JNIEnv* env, jobject stream, const std::string& text) {
    if (!env || !stream) return false;
    jclass outputClass = env->GetObjectClass(stream);
    if (!outputClass) return false;
    const jmethodID writeMethod = env->GetMethodID(outputClass, "write", "([B)V");
    const jmethodID flushMethod = env->GetMethodID(outputClass, "flush", "()V");
    const jmethodID closeMethod = env->GetMethodID(outputClass, "close", "()V");
    if (!writeMethod || !closeMethod) {
        env->DeleteLocalRef(outputClass);
        if (env->ExceptionCheck()) env->ExceptionClear();
        return false;
    }

    bool ok = true;
    constexpr size_t kChunkBytes = 32 * 1024;
    for (size_t offset = 0; offset < text.size() && ok; offset += kChunkBytes) {
        const size_t count = std::min(kChunkBytes, text.size() - offset);
        jbyteArray bytes = env->NewByteArray(static_cast<jsize>(count));
        if (!bytes) { ok = false; break; }
        env->SetByteArrayRegion(bytes, 0, static_cast<jsize>(count),
            reinterpret_cast<const jbyte*>(text.data() + offset));
        if (!env->ExceptionCheck()) env->CallVoidMethod(stream, writeMethod, bytes);
        env->DeleteLocalRef(bytes);
        if (env->ExceptionCheck()) { env->ExceptionClear(); ok = false; }
    }
    if (ok && flushMethod) {
        env->CallVoidMethod(stream, flushMethod);
        if (env->ExceptionCheck()) { env->ExceptionClear(); ok = false; }
    }
    env->CallVoidMethod(stream, closeMethod);
    if (env->ExceptionCheck()) { env->ExceptionClear(); ok = false; }
    env->DeleteLocalRef(stream);
    env->DeleteLocalRef(outputClass);
    return ok;
}

void showAndroidToast(ANativeActivity* activity, const std::string& message) {
    if (!activity || !activity->vm || !activity->clazz) return;
    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) return;
    jclass toastClass = env->FindClass("android/widget/Toast");
    jclass contextClass = env->FindClass("android/content/Context");
    jobject toast = nullptr;
    if (toastClass && contextClass) {
        const jmethodID makeText = env->GetStaticMethodID(toastClass, "makeText",
            "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
        const jmethodID show = env->GetMethodID(toastClass, "show", "()V");
        const jfieldID lengthLong = env->GetStaticFieldID(toastClass, "LENGTH_LONG", "I");
        if (makeText && show && lengthLong) {
            jstring text = env->NewStringUTF(message.c_str());
            const jint duration = env->GetStaticIntField(toastClass, lengthLong);
            toast = env->CallStaticObjectMethod(toastClass, makeText, activity->clazz, text, duration);
            if (toast && !env->ExceptionCheck()) env->CallVoidMethod(toast, show);
            if (text) env->DeleteLocalRef(text);
        }
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (toast) env->DeleteLocalRef(toast);
    if (toastClass) env->DeleteLocalRef(toastClass);
    if (contextClass) env->DeleteLocalRef(contextClass);
    detachJni(activity->vm, attached);
}

bool saveSessionLogToDevice(ANativeActivity* activity, std::string& savedLocation) {
    if (!activity || !activity->vm || !activity->clazz) return false;
    const std::string logText = appLogSnapshot();
    const auto epochMs = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    const std::string fileName = "diplomka-session-" + std::to_string(epochMs) + ".txt";

    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) return false;

    bool saved = false;
    // Android 10+: write to the public Downloads collection through MediaStore.
    // This does not require broad storage permissions and makes the file visible
    // in the system Files/Downloads app.
    jclass versionClass = env->FindClass("android/os/Build$VERSION");
    jint sdkInt = 0;
    if (versionClass && !env->ExceptionCheck()) {
        const jfieldID sdkField = env->GetStaticFieldID(versionClass, "SDK_INT", "I");
        if (sdkField) sdkInt = env->GetStaticIntField(versionClass, sdkField);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();

    if (sdkInt >= 29) {
        jclass activityClass = env->GetObjectClass(activity->clazz);
        jclass valuesClass = env->FindClass("android/content/ContentValues");
        jclass downloadsClass = env->FindClass("android/provider/MediaStore$Downloads");
        jobject resolver = nullptr;
        jobject values = nullptr;
        jobject collectionUri = nullptr;
        jobject documentUri = nullptr;
        jobject stream = nullptr;
        if (activityClass && valuesClass && downloadsClass) {
            const jmethodID getResolver = env->GetMethodID(activityClass, "getContentResolver",
                "()Landroid/content/ContentResolver;");
            const jmethodID valuesCtor = env->GetMethodID(valuesClass, "<init>", "()V");
            const jmethodID putString = env->GetMethodID(valuesClass, "put",
                "(Ljava/lang/String;Ljava/lang/String;)V");
            const jfieldID collectionField = env->GetStaticFieldID(downloadsClass,
                "EXTERNAL_CONTENT_URI", "Landroid/net/Uri;");
            if (getResolver && valuesCtor && putString && collectionField) {
                resolver = env->CallObjectMethod(activity->clazz, getResolver);
                values = env->NewObject(valuesClass, valuesCtor);
                collectionUri = env->GetStaticObjectField(downloadsClass, collectionField);
                auto put = [&](const char* key, const char* value) {
                    jstring jkey = env->NewStringUTF(key);
                    jstring jvalue = env->NewStringUTF(value);
                    env->CallVoidMethod(values, putString, jkey, jvalue);
                    env->DeleteLocalRef(jkey);
                    env->DeleteLocalRef(jvalue);
                };
                if (resolver && values && collectionUri && !env->ExceptionCheck()) {
                    put("display_name", fileName.c_str());
                    put("mime_type", "text/plain");
                    put("relative_path", "Download/Diplomka");
                    jclass resolverClass = env->GetObjectClass(resolver);
                    const jmethodID insert = env->GetMethodID(resolverClass, "insert",
                        "(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;");
                    const jmethodID openOutput = env->GetMethodID(resolverClass, "openOutputStream",
                        "(Landroid/net/Uri;)Ljava/io/OutputStream;");
                    if (insert && openOutput) {
                        documentUri = env->CallObjectMethod(resolver, insert, collectionUri, values);
                        if (documentUri && !env->ExceptionCheck()) {
                            stream = env->CallObjectMethod(resolver, openOutput, documentUri);
                            if (stream && !env->ExceptionCheck()) {
                                saved = writeBytesToJavaOutputStream(env, stream, logText);
                                stream = nullptr; // helper closes it
                            }
                        }
                    }
                    if (resolverClass) env->DeleteLocalRef(resolverClass);
                }
            }
        }
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (saved) savedLocation = "Загрузки/Diplomka/" + fileName;
        if (stream) env->DeleteLocalRef(stream);
        if (documentUri) env->DeleteLocalRef(documentUri);
        if (collectionUri) env->DeleteLocalRef(collectionUri);
        if (values) env->DeleteLocalRef(values);
        if (resolver) env->DeleteLocalRef(resolver);
        if (downloadsClass) env->DeleteLocalRef(downloadsClass);
        if (valuesClass) env->DeleteLocalRef(valuesClass);
        if (activityClass) env->DeleteLocalRef(activityClass);
    }

    // Android 8/9 fallback: app-specific external files directory. No storage
    // permission is needed; Android's Files app can browse Android/data when
    // the OS file manager permits it.
    if (!saved) {
        jclass activityClass = env->GetObjectClass(activity->clazz);
        jmethodID getExternalFilesDir = activityClass ? env->GetMethodID(activityClass,
            "getExternalFilesDir", "(Ljava/lang/String;)Ljava/io/File;") : nullptr;
        jobject directory = nullptr;
        jclass fileClass = env->FindClass("java/io/File");
        jobject file = nullptr;
        jobject stream = nullptr;
        if (getExternalFilesDir && fileClass) {
            jstring folder = env->NewStringUTF("logs");
            directory = env->CallObjectMethod(activity->clazz, getExternalFilesDir, folder);
            env->DeleteLocalRef(folder);
            const jmethodID mkdirs = env->GetMethodID(fileClass, "mkdirs", "()Z");
            const jmethodID fileCtor = env->GetMethodID(fileClass, "<init>", "(Ljava/io/File;Ljava/lang/String;)V");
            const jmethodID absolutePath = env->GetMethodID(fileClass, "getAbsolutePath", "()Ljava/lang/String;");
            if (directory && mkdirs && fileCtor && absolutePath) {
                env->CallBooleanMethod(directory, mkdirs);
                jstring name = env->NewStringUTF(fileName.c_str());
                file = env->NewObject(fileClass, fileCtor, directory, name);
                env->DeleteLocalRef(name);
                jclass fosClass = env->FindClass("java/io/FileOutputStream");
                const jmethodID fosCtor = fosClass ? env->GetMethodID(fosClass, "<init>", "(Ljava/io/File;)V") : nullptr;
                if (file && fosCtor) stream = env->NewObject(fosClass, fosCtor, file);
                if (stream && !env->ExceptionCheck()) {
                    saved = writeBytesToJavaOutputStream(env, stream, logText);
                    stream = nullptr;
                }
                if (saved) {
                    jstring path = static_cast<jstring>(env->CallObjectMethod(file, absolutePath));
                    if (path) {
                        const char* chars = env->GetStringUTFChars(path, nullptr);
                        if (chars) { savedLocation = chars; env->ReleaseStringUTFChars(path, chars); }
                        env->DeleteLocalRef(path);
                    }
                }
                if (fosClass) env->DeleteLocalRef(fosClass);
            }
        }
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (stream) env->DeleteLocalRef(stream);
        if (file) env->DeleteLocalRef(file);
        if (directory) env->DeleteLocalRef(directory);
        if (fileClass) env->DeleteLocalRef(fileClass);
        if (activityClass) env->DeleteLocalRef(activityClass);
    }

    if (env->ExceptionCheck()) env->ExceptionClear();
    if (versionClass) env->DeleteLocalRef(versionClass);
    detachJni(activity->vm, attached);
    return saved;
}

void requestCameraPermission(AppState& state) {
    if (state.hasCameraPermission || state.cameraPermissionRequested) return;
    state.cameraPermissionRequested = true;
    requestPermissions(state.app_->activity, {"android.permission.CAMERA"}, kCameraPermissionRequestCode);
    state.cameraStatus = "Ожидание разрешения камеры";
}

void requestLocationPermission(AppState& state) {
    if (state.hasGpsPermission || state.locationPermissionRequested) return;
    state.locationPermissionRequested = true;
    requestPermissions(state.app_->activity,
                       {"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"},
                       kLocationPermissionRequestCode);
    state.addLog("Запрошено разрешение геолокации");
}

GpsFix readLastKnownLocation(ANativeActivity* activity) {
    GpsFix fix;
    if (!activity || !activity->vm || !activity->clazz) return fix;
    bool attached = false;
    JNIEnv* env = attachJni(activity->vm, &attached);
    if (!env) return fix;

    jclass activityClass = env->GetObjectClass(activity->clazz);
    jmethodID getSystemService = env->GetMethodID(activityClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
    jobject locationManager = nullptr;
    if (getSystemService) {
        jstring serviceName = env->NewStringUTF("location");
        locationManager = env->CallObjectMethod(activity->clazz, getSystemService, serviceName);
        env->DeleteLocalRef(serviceName);
    }

    if (locationManager && !env->ExceptionCheck()) {
        jclass managerClass = env->GetObjectClass(locationManager);
        jmethodID getLastKnown = env->GetMethodID(managerClass, "getLastKnownLocation", "(Ljava/lang/String;)Landroid/location/Location;");
        jobject location = nullptr;
        const char* providers[] = {"gps", "network"};
        for (const char* provider : providers) {
            if (!getLastKnown) break;
            jstring providerName = env->NewStringUTF(provider);
            location = env->CallObjectMethod(locationManager, getLastKnown, providerName);
            env->DeleteLocalRef(providerName);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                location = nullptr;
            }
            if (location) break;
        }
        if (location) {
            jclass locationClass = env->GetObjectClass(location);
            jmethodID getLatitude = env->GetMethodID(locationClass, "getLatitude", "()D");
            jmethodID getLongitude = env->GetMethodID(locationClass, "getLongitude", "()D");
            jmethodID getAccuracy = env->GetMethodID(locationClass, "getAccuracy", "()F");
            jmethodID getTime = env->GetMethodID(locationClass, "getTime", "()J");
            if (getLatitude && getLongitude) {
                fix.latitude = env->CallDoubleMethod(location, getLatitude);
                fix.longitude = env->CallDoubleMethod(location, getLongitude);
                fix.accuracyMeters = getAccuracy ? env->CallFloatMethod(location, getAccuracy) : 0.0f;
                fix.timestampMs = getTime ? env->CallLongMethod(location, getTime) : 0;
                fix.available = !env->ExceptionCheck();
            }
            env->DeleteLocalRef(locationClass);
            env->DeleteLocalRef(location);
        }
        env->DeleteLocalRef(managerClass);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (locationManager) env->DeleteLocalRef(locationManager);
    env->DeleteLocalRef(activityClass);
    detachJni(activity->vm, attached);
    return fix;
}

void updatePermissionsAndServices(AppState& state) {
    const auto now = std::chrono::steady_clock::now();
    state.torchEnabled = state.camera_.isTorchEnabled();
    if (now - state.lastPermissionPoll > std::chrono::milliseconds(500)) {
        state.lastPermissionPoll = now;
        state.hasCameraPermission = checkPermission(state.app_->activity, "android.permission.CAMERA");
        state.hasGpsPermission = checkPermission(state.app_->activity, "android.permission.ACCESS_FINE_LOCATION") ||
                                 checkPermission(state.app_->activity, "android.permission.ACCESS_COARSE_LOCATION");
        if (!state.permissionStateLogged || state.lastLoggedCameraPermission != state.hasCameraPermission) {
            LOGI("Runtime camera permission state changed: %s", state.hasCameraPermission ? "GRANTED" : "DENIED");
            state.lastLoggedCameraPermission = state.hasCameraPermission;
        }
        if (!state.permissionStateLogged || state.lastLoggedGpsPermission != state.hasGpsPermission) {
            LOGI("Runtime location permission state changed: %s", state.hasGpsPermission ? "GRANTED" : "DENIED");
            state.lastLoggedGpsPermission = state.hasGpsPermission;
        }
        state.permissionStateLogged = true;
        if (!state.hasCameraPermission && !state.permissionDialogSent) {
            requestCameraPermission(state);
            state.permissionDialogSent = true;
        }
        if (state.hasCameraPermission) state.cameraPermissionRequested = false;
        if (state.hasGpsPermission) state.locationPermissionRequested = false;
    }

    if (state.hasCameraPermission && state.cameraDesired && state.hasWindow &&
        !state.camera_.isRunning() && !state.camera_.isStartPending() &&
        state.camera_.lastErrorCode() != 0 && now >= state.nextCameraRetryAt &&
        !state.cameraAutoRetryExhausted) {
        const std::string detail = state.camera_.lastErrorText().empty()
            ? state.camera_.stageText() : state.camera_.lastErrorText();
        state.addLog("Camera2 failure: " + detail +
            " · captureResults=" + std::to_string(state.camera_.captureResultCount()) +
            " captureFailed=" + std::to_string(state.camera_.captureFailureCount()) +
            " imageCallbacks=" + std::to_string(state.camera_.imageCallbackCount()) +
            " frames=" + std::to_string(state.camera_.frameCount()));
        if (state.cameraRetryCount < kMaxAutomaticCameraRetries) {
            ++state.cameraRetryCount;
            const int delaySeconds = 3 * state.cameraRetryCount;
            state.cameraStatus = "Ошибка Camera2 · повтор " + std::to_string(state.cameraRetryCount) +
                                 "/" + std::to_string(kMaxAutomaticCameraRetries) +
                                 " через " + std::to_string(delaySeconds) + " с";
            state.addLog(state.cameraStatus);
            state.nextCameraRetryAt = now + std::chrono::seconds(delaySeconds);
        } else {
            state.cameraAutoRetryExhausted = true;
            state.cameraStatus = "Камера не запустилась · автоматические попытки исчерпаны; нажми Перезапуск";
            state.addLog(state.cameraStatus);
        }
        state.cameraAttemptAt = {};
    }

    if (!state.hasCameraPermission) {
        if (state.camera_.isRunning()) state.camera_.stop();
        if (state.cameraDesired) state.cameraStatus = "Нет разрешения на камеру · нажми Камера";
    } else if (!state.cameraDesired) {
        if (state.camera_.isRunning()) state.camera_.stop();
        state.cameraStatus = "Камера выключена";
    } else if (state.hasWindow && !state.cameraAutoRetryExhausted &&
               !state.camera_.isRunning() && !state.camera_.isStartPending() &&
               now >= state.nextCameraRetryAt) {
        state.cameraStatus = "Подключение камеры…";
        LOGI("Camera start requested: permission=granted, window=ready, retry=%d", state.cameraRetryCount);
        const bool ok = state.camera_.start([&state](std::vector<uint8_t>&& rgba, int width, int height) {
            state.onFrame(std::move(rgba), width, height);
        });
        state.cameraAttemptAt = now;
        if (ok) {
            state.hasCameraError = false;
            state.lastCameraFrameAt = {};
            state.lastObservedCameraFrames = 0;
            state.cameraStatus = "Сессия запрошена · ожидание Camera2 callbacks";
            state.addLog("Запуск камеры поставлен в очередь Camera2 worker");
        } else {
            state.hasCameraError = true;
            state.cameraStatus = "Не удалось поставить запуск камеры в очередь · код " +
                                 std::to_string(state.camera_.lastErrorCode());
            state.nextCameraRetryAt = now + std::chrono::seconds(3);
            state.cameraAttemptAt = {};
            state.addLog(state.cameraStatus);
        }
    }

    // Camera open/configure may legitimately take longer on some vendor stacks.
    // Do not kill it after 10 seconds; log the exact stage and allow 45 seconds.
    if (state.camera_.isStartPending() && state.cameraAttemptAt.time_since_epoch().count() != 0 &&
        now - state.cameraAttemptAt > kCameraStartupTimeout) {
        const std::string detail = "stage=" + state.camera_.stageText() +
            " error=" + state.camera_.lastErrorText() +
            " captureResults=" + std::to_string(state.camera_.captureResultCount()) +
            " captureFailed=" + std::to_string(state.camera_.captureFailureCount()) +
            " imageCallbacks=" + std::to_string(state.camera_.imageCallbackCount()) +
            " lastImageAcquireStatus=" + std::to_string(state.camera_.lastImageAcquireStatus());
        LOGE("Camera startup timeout after 45 seconds: %s", detail.c_str());
        state.addLog("Тайм-аут запуска камеры · " + detail);
        state.camera_.stop();
        if (state.cameraRetryCount < kMaxAutomaticCameraRetries) {
            ++state.cameraRetryCount;
            state.nextCameraRetryAt = now + std::chrono::seconds(3 * state.cameraRetryCount);
            state.cameraStatus = "Camera2 не завершила запуск · повтор " +
                std::to_string(state.cameraRetryCount) + "/" + std::to_string(kMaxAutomaticCameraRetries);
        } else {
            state.cameraAutoRetryExhausted = true;
            state.cameraStatus = "Camera2 не завершила запуск · нажми Перезапуск";
        }
        state.cameraAttemptAt = {};
        state.lastCameraFrameAt = {};
        state.lastObservedCameraFrames = 0;
    }

    if (state.camera_.isRunning()) {
        const uint64_t frames = state.camera_.frameCount();
        if (frames > state.lastObservedCameraFrames) {
            state.lastObservedCameraFrames = frames;
            state.lastCameraFrameAt = now;
            state.cameraRetryCount = 0;
            state.cameraAutoRetryExhausted = false;
            state.hasCameraError = false;
            state.cameraStatus = "Камера активна · кадров " + std::to_string(frames);
        }
        const auto frameReference = state.lastCameraFrameAt.time_since_epoch().count() != 0
            ? state.lastCameraFrameAt : state.cameraAttemptAt;
        if (frameReference.time_since_epoch().count() != 0 && now - frameReference > kCameraFirstFrameTimeout) {
            const std::string detail = "stage=" + state.camera_.stageText() +
                " error=" + state.camera_.lastErrorText() +
                " captureResults=" + std::to_string(state.camera_.captureResultCount()) +
                " captureFailed=" + std::to_string(state.camera_.captureFailureCount()) +
                " imageCallbacks=" + std::to_string(state.camera_.imageCallbackCount()) +
                " lastImageAcquireStatus=" + std::to_string(state.camera_.lastImageAcquireStatus()) +
                " frames=" + std::to_string(frames);
            LOGE("Camera first-frame timeout after 30 seconds: %s", detail.c_str());
            state.addLog("Нет первого кадра · " + detail);
            state.camera_.stop();
            if (state.cameraRetryCount < kMaxAutomaticCameraRetries) {
                ++state.cameraRetryCount;
                const int delaySeconds = 3 * state.cameraRetryCount;
                state.nextCameraRetryAt = now + std::chrono::seconds(delaySeconds);
                state.cameraStatus = "Нет первого кадра · повтор " +
                    std::to_string(state.cameraRetryCount) + "/" + std::to_string(kMaxAutomaticCameraRetries);
            } else {
                state.cameraAutoRetryExhausted = true;
                state.cameraStatus = "Камера не выдаёт кадры · нажми Перезапуск";
            }
            state.cameraAttemptAt = {};
            state.lastCameraFrameAt = {};
            state.lastObservedCameraFrames = 0;
        }
    }

    state.torchEnabled = state.camera_.isTorchEnabled();
    const int flashState = state.camera_.lastFlashState();
    if (flashState != -1 && flashState != state.lastLoggedFlashState) {
        state.lastLoggedFlashState = flashState;
        state.addLog("Состояние вспышки Camera2: " + std::to_string(flashState));
    }

    if (state.hasGpsPermission && state.showMap && now - state.lastGpsPoll > std::chrono::seconds(5)) {
        state.lastGpsPoll = now;
        state.requestGpsFix();
    }
    if (const auto candidate = state.takeGpsFix(); candidate && candidate->available) {
        state.gps = *candidate;
    }
}

bool initEgl(ANativeWindow* window, EglState& egl) {
    const EGLint attributes[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_RED_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 0, EGL_STENCIL_SIZE, 0,
        EGL_NONE
    };
    egl.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (egl.display == EGL_NO_DISPLAY) return false;
    if (eglInitialize(egl.display, nullptr, nullptr) != EGL_TRUE) return false;
    EGLConfig config = nullptr;
    EGLint configCount = 0;
    if (eglChooseConfig(egl.display, attributes, &config, 1, &configCount) != EGL_TRUE || configCount < 1) return false;
    const EGLint contextAttributes[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    egl.context = eglCreateContext(egl.display, config, EGL_NO_CONTEXT, contextAttributes);
    if (egl.context == EGL_NO_CONTEXT) return false;
    egl.surface = eglCreateWindowSurface(egl.display, config, window, nullptr);
    if (egl.surface == EGL_NO_SURFACE) return false;
    if (eglMakeCurrent(egl.display, egl.surface, egl.surface, egl.context) != EGL_TRUE) return false;
    eglQuerySurface(egl.display, egl.surface, EGL_WIDTH, &egl.width);
    eglQuerySurface(egl.display, egl.surface, EGL_HEIGHT, &egl.height);
    return true;
}

void shutdownEgl(EglState& egl) {
    if (egl.display != EGL_NO_DISPLAY) {
        eglMakeCurrent(egl.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (egl.context != EGL_NO_CONTEXT) eglDestroyContext(egl.display, egl.context);
        if (egl.surface != EGL_NO_SURFACE) eglDestroySurface(egl.display, egl.surface);
        eglTerminate(egl.display);
    }
    egl = EglState{};
}

void updateTexture(AppState& state) {
    std::vector<uint8_t> pixels;
    int width = 0;
    int height = 0;
    uint64_t version = 0;
    {
        std::lock_guard<std::mutex> lock(state.frameMutex_);
        if (state.frameVersion_ == state.uploadedFrameVersion || state.latestRgba_.empty()) return;
        pixels = state.latestRgba_;
        width = state.frameWidth_;
        height = state.frameHeight_;
        version = state.frameVersion_;
    }
    if (!state.previewTexture) glGenTextures(1, &state.previewTexture);
    glBindTexture(GL_TEXTURE_2D, state.previewTexture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
    glBindTexture(GL_TEXTURE_2D, 0);
    state.previewTextureWidth = width;
    state.previewTextureHeight = height;
    state.uploadedFrameVersion = version;
}

std::string translateClass(const std::string& name) {
    return name;
}

void drawPoseOverlay(ImDrawList* draw, const PersonPose& pose, ImVec2 topLeft, ImVec2 imageSize, int frameW, int frameH) {
    static const int edges[][2] = {
        {5, 6}, {5, 7}, {7, 9}, {6, 8}, {8, 10}, {5, 11}, {6, 12}, {11, 12},
        {11, 13}, {13, 15}, {12, 14}, {14, 16}, {0, 1}, {0, 2}, {1, 3}, {2, 4}, {0, 5}, {0, 6}
    };
    const auto mapPoint = [&](const BodyPoint& point) {
        // Preview is rotated 90 degrees clockwise to match a portrait phone.
        const float x = 1.0f - point.y / static_cast<float>(frameH);
        const float y = point.x / static_cast<float>(frameW);
        return ImVec2(topLeft.x + x * imageSize.x, topLeft.y + y * imageSize.y);
    };
    for (const auto& edge : edges) {
        const BodyPoint& a = pose.keypoints[edge[0]];
        const BodyPoint& b = pose.keypoints[edge[1]];
        if (a.confidence < 0.35f || b.confidence < 0.35f) continue;
        draw->AddLine(mapPoint(a), mapPoint(b), IM_COL32(0, 230, 190, 230), 2.2f);
    }
    for (const auto& point : pose.keypoints) {
        if (point.confidence < 0.35f) continue;
        draw->AddCircleFilled(mapPoint(point), 3.2f, IM_COL32(255, 211, 80, 255));
    }
}

void drawGlyphIcon(ImDrawList* draw, const char* icon, ImVec2 c, float s, ImU32 color);

void drawCameraPreview(AppState& state, ImVec2 size) {
    ImGui::BeginChild("camera_preview", size, true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    const ImVec2 content = ImGui::GetCursorScreenPos();
    const ImVec2 avail = ImGui::GetContentRegionAvail();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    const ImVec2 area(std::max(1.0f, avail.x), std::max(1.0f, avail.y));
    const ImVec2 areaEnd(content.x + area.x, content.y + area.y);
    draw->AddRectFilled(content, areaEnd, IM_COL32(13, 23, 26, 255), 20.0f);

    if (state.previewTexture && state.previewTextureWidth > 0 && state.previewTextureHeight > 0) {
        // The sensor stream is landscape but the UI is portrait. Fit the
        // rotated image without stretching it; keep overlays in the same rect.
        const float rotatedAspect = static_cast<float>(state.previewTextureHeight) /
                                    static_cast<float>(state.previewTextureWidth);
        const float areaAspect = area.x / area.y;
        ImVec2 imageSize = area;
        if (areaAspect > rotatedAspect) imageSize.x = area.y * rotatedAspect;
        else imageSize.y = area.x / rotatedAspect;
        const ImVec2 p(content.x + (area.x - imageSize.x) * 0.5f,
                       content.y + (area.y - imageSize.y) * 0.5f);
        const ImVec2 p0(p.x, p.y);
        const ImVec2 p1(p.x + imageSize.x, p.y);
        const ImVec2 p2(p.x + imageSize.x, p.y + imageSize.y);
        const ImVec2 p3(p.x, p.y + imageSize.y);
        draw->AddImageQuad((ImTextureID)(intptr_t)state.previewTexture,
                           p0, p1, p2, p3,
                           ImVec2(0, 1), ImVec2(0, 0), ImVec2(1, 0), ImVec2(1, 1));

        VisionFrame vision;
        {
            std::lock_guard<std::mutex> lock(state.frameMutex_);
            vision = state.latestVision_;
        }
        const int frameW = vision.frameWidth > 0 ? vision.frameWidth : state.previewTextureWidth;
        const int frameH = vision.frameHeight > 0 ? vision.frameHeight : state.previewTextureHeight;
        for (const auto& detection : vision.detections) {
            const float x0 = 1.0f - detection.box.bottom / static_cast<float>(frameH);
            const float y0 = detection.box.left / static_cast<float>(frameW);
            const float x1 = 1.0f - detection.box.top / static_cast<float>(frameH);
            const float y1 = detection.box.right / static_cast<float>(frameW);
            const ImVec2 a(p.x + x0 * imageSize.x, p.y + y0 * imageSize.y);
            const ImVec2 b(p.x + x1 * imageSize.x, p.y + y1 * imageSize.y);
            draw->AddRect(a, b, IM_COL32(117, 244, 211, 245), 8.0f, 0, 2.0f);
            const std::string label = translateClass(detection.label) + "  " + std::to_string(static_cast<int>(detection.confidence * 100.0f)) + "%";
            const ImVec2 labelSize = ImGui::CalcTextSize(label.c_str());
            draw->AddRectFilled(ImVec2(a.x, std::max(p.y, a.y - labelSize.y - 9.0f)),
                                ImVec2(a.x + labelSize.x + 12.0f, std::max(p.y, a.y - labelSize.y - 9.0f) + labelSize.y + 7.0f),
                                IM_COL32(10, 28, 27, 225), 5.0f);
            draw->AddText(ImVec2(a.x + 6.0f, std::max(p.y + 3.0f, a.y - labelSize.y - 6.0f)), IM_COL32(169, 255, 232, 255), label.c_str());
        }
        for (const auto& person : vision.people) drawPoseOverlay(draw, person, p, imageSize, frameW, frameH);
        if (vision.hasTarget) {
            const ImVec2 target(p.x + (1.0f - vision.targetY / static_cast<float>(frameH)) * imageSize.x,
                                p.y + (vision.targetX / static_cast<float>(frameW)) * imageSize.y);
            const ImVec2 origin(p.x + imageSize.x * 0.5f, p.y + imageSize.y * 0.94f);
            const ImU32 routeColor = vision.stopSignal ? IM_COL32(255, 65, 55, 245) : IM_COL32(80, 245, 180, 235);
            draw->AddLine(origin, target, routeColor, 4.0f);
            draw->AddCircleFilled(target, 7.0f, routeColor);
        }
        if (vision.stopSignal) {
            const char* stopText = "СТОП · ПРЕПЯТСТВИЕ";
            const ImVec2 stopSize = ImGui::CalcTextSize(stopText);
            draw->AddRectFilled(ImVec2(p.x + 10.0f, p.y + 10.0f),
                                ImVec2(p.x + stopSize.x + 30.0f, p.y + stopSize.y + 24.0f),
                                IM_COL32(150, 18, 22, 225), 7.0f);
            draw->AddText(ImVec2(p.x + 20.0f, p.y + 17.0f), IM_COL32(255, 255, 255, 255), stopText);
        }

        // Thin cinematic corners and quiet center reticle.
        const ImU32 corner = IM_COL32(164, 248, 225, 190);
        const float length = 19.0f * state.uiScale;
        const float thickness = 2.0f * state.uiScale;
        draw->AddLine(p0, ImVec2(p0.x + length, p0.y), corner, thickness);
        draw->AddLine(p0, ImVec2(p0.x, p0.y + length), corner, thickness);
        draw->AddLine(ImVec2(p1.x - length, p1.y), p1, corner, thickness);
        draw->AddLine(p1, ImVec2(p1.x, p1.y + length), corner, thickness);
        draw->AddLine(ImVec2(p3.x, p3.y - length), p3, corner, thickness);
        draw->AddLine(p3, ImVec2(p3.x + length, p3.y), corner, thickness);
        draw->AddLine(ImVec2(p2.x - length, p2.y), p2, corner, thickness);
        draw->AddLine(ImVec2(p2.x, p2.y - length), p2, corner, thickness);
        const ImVec2 center((p.x + p.x + imageSize.x) * 0.5f, (p.y + p.y + imageSize.y) * 0.5f);
        const float pulse = 0.5f + 0.5f * std::sin(static_cast<float>(ImGui::GetTime()) * 1.6f);
        draw->AddCircle(center, 9.0f + pulse * 2.0f, IM_COL32(170, 244, 224, 55 + static_cast<int>(pulse * 45.0f)), 32, 1.2f);
    } else {
        const ImVec2 center(content.x + area.x * 0.5f, content.y + area.y * 0.5f);
        const float pulse = 0.5f + 0.5f * std::sin(static_cast<float>(ImGui::GetTime()) * 1.7f);
        draw->AddCircle(center, 34.0f + pulse * 5.0f, IM_COL32(91, 214, 188, 80), 48, 2.0f);
        draw->AddCircle(center, 22.0f, IM_COL32(91, 214, 188, 150), 48, 1.5f);
        drawGlyphIcon(draw, "camera", center, 26.0f, IM_COL32(180, 236, 224, 220));
        const char* message = state.cameraStatus.c_str();
        const ImVec2 textSize = ImGui::CalcTextSize(message);
        draw->AddText(ImVec2(center.x - textSize.x * 0.5f, center.y + 52.0f), IM_COL32(207, 220, 218, 255), message);
        const char* hint = state.hasCameraPermission ? "Ожидание видеопотока" : "Разреши доступ к камере";
        const ImVec2 hintSize = ImGui::CalcTextSize(hint);
        draw->AddText(ImVec2(center.x - hintSize.x * 0.5f, center.y + 76.0f), IM_COL32(126, 158, 158, 255), hint);
    }
    ImGui::Dummy(area);
    ImGui::EndChild();
}

void drawLogPanel(AppState& state, float height) {
    if (!state.showLog) return;
    ImGui::BeginChild("log_panel", ImVec2(0, height), true, ImGuiWindowFlags_HorizontalScrollbar);
    ImGui::TextColored(ImVec4(0.62f, 0.91f, 0.85f, 1.0f), "ЖУРНАЛ СОБЫТИЙ");
    ImGui::SameLine();
    ImGui::TextDisabled("последние события");
    ImGui::SameLine();
    ImGui::TextDisabled("полный лог: %llu", static_cast<unsigned long long>(appLogLineCount()));
    const auto lines = state.getLogs();
    const size_t first = lines.size() > 3 ? lines.size() - 3 : 0;
    for (size_t i = first; i < lines.size(); ++i) ImGui::TextWrapped("› %s", lines[i].c_str());
    ImGui::EndChild();
}

void drawGlyphIcon(ImDrawList* draw, const char* icon, ImVec2 c, float s, ImU32 color) {
    const float h = s * 0.5f;
    const float w = s * 0.5f;
    const float t = std::max(1.7f, s * 0.075f);
    if (std::strcmp(icon, "camera") == 0) {
        draw->AddRect(ImVec2(c.x - w, c.y - h * 0.58f), ImVec2(c.x + w, c.y + h * 0.58f), color, s * 0.13f, 0, t);
        draw->AddRectFilled(ImVec2(c.x - w * 0.42f, c.y - h * 0.88f), ImVec2(c.x - w * 0.02f, c.y - h * 0.58f), color, 2.0f);
        draw->AddCircle(c, s * 0.22f, color, 24, t);
        draw->AddCircleFilled(c, s * 0.07f, color, 16);
    } else if (std::strcmp(icon, "log") == 0) {
        for (int i = -1; i <= 1; ++i) {
            const float y = c.y + i * s * 0.27f;
            draw->AddCircleFilled(ImVec2(c.x - w * 0.68f, y), t * 0.62f, color, 10);
            draw->AddLine(ImVec2(c.x - w * 0.35f, y), ImVec2(c.x + w * 0.72f, y), color, t);
        }
    } else if (std::strcmp(icon, "export") == 0) {
        draw->AddLine(ImVec2(c.x, c.y - h * 0.88f), ImVec2(c.x, c.y + h * 0.12f), color, t * 1.25f);
        draw->AddLine(ImVec2(c.x - w * 0.34f, c.y - h * 0.18f), ImVec2(c.x, c.y + h * 0.18f), color, t * 1.25f);
        draw->AddLine(ImVec2(c.x + w * 0.34f, c.y - h * 0.18f), ImVec2(c.x, c.y + h * 0.18f), color, t * 1.25f);
        draw->AddLine(ImVec2(c.x - w * 0.68f, c.y + h * 0.52f), ImVec2(c.x + w * 0.68f, c.y + h * 0.52f), color, t * 1.25f);
        draw->AddLine(ImVec2(c.x - w * 0.68f, c.y + h * 0.52f), ImVec2(c.x - w * 0.68f, c.y + h * 0.20f), color, t * 1.25f);
        draw->AddLine(ImVec2(c.x + w * 0.68f, c.y + h * 0.52f), ImVec2(c.x + w * 0.68f, c.y + h * 0.20f), color, t * 1.25f);
    } else if (std::strcmp(icon, "ai") == 0) {
        draw->AddLine(ImVec2(c.x, c.y - h), ImVec2(c.x, c.y + h), color, t);
        draw->AddLine(ImVec2(c.x - w, c.y), ImVec2(c.x + w, c.y), color, t);
        draw->AddLine(ImVec2(c.x - w * 0.62f, c.y - h * 0.62f), ImVec2(c.x + w * 0.62f, c.y + h * 0.62f), color, t * 0.8f);
        draw->AddLine(ImVec2(c.x - w * 0.62f, c.y + h * 0.62f), ImVec2(c.x + w * 0.62f, c.y - h * 0.62f), color, t * 0.8f);
        draw->AddCircleFilled(ImVec2(c.x + w * 0.78f, c.y - h * 0.78f), t * 0.8f, color);
    } else if (std::strcmp(icon, "gps") == 0) {
        draw->AddCircle(c, s * 0.38f, color, 28, t);
        draw->AddCircle(c, s * 0.12f, color, 20, t);
        draw->AddLine(ImVec2(c.x, c.y - h), ImVec2(c.x, c.y - h * 0.58f), color, t);
        draw->AddLine(ImVec2(c.x, c.y + h * 0.58f), ImVec2(c.x, c.y + h), color, t);
        draw->AddLine(ImVec2(c.x - w, c.y), ImVec2(c.x - w * 0.58f, c.y), color, t);
        draw->AddLine(ImVec2(c.x + w * 0.58f, c.y), ImVec2(c.x + w, c.y), color, t);
    } else if (std::strcmp(icon, "flash") == 0) {
        draw->PathLineTo(ImVec2(c.x + w * 0.12f, c.y - h));
        draw->PathLineTo(ImVec2(c.x - w * 0.52f, c.y + h * 0.05f));
        draw->PathLineTo(ImVec2(c.x - w * 0.04f, c.y + h * 0.05f));
        draw->PathLineTo(ImVec2(c.x - w * 0.18f, c.y + h));
        draw->PathLineTo(ImVec2(c.x + w * 0.58f, c.y - h * 0.12f));
        draw->PathLineTo(ImVec2(c.x + w * 0.08f, c.y - h * 0.12f));
        draw->PathFillConvex(color);
    } else if (std::strcmp(icon, "restart") == 0) {
        draw->PathArcTo(c, s * 0.34f, -2.35f, 1.65f, 28);
        draw->PathStroke(color, 0, t);
        draw->AddLine(ImVec2(c.x + w * 0.56f, c.y - h * 0.78f), ImVec2(c.x + w * 0.62f, c.y - h * 0.20f), color, t);
        draw->AddLine(ImVec2(c.x + w * 0.62f, c.y - h * 0.20f), ImVec2(c.x + w * 0.10f, c.y - h * 0.34f), color, t);
    } else if (std::strcmp(icon, "chevron") == 0 || std::strcmp(icon, "chevron-left") == 0) {
        const bool left = std::strcmp(icon, "chevron-left") == 0;
        const float sign = left ? -1.0f : 1.0f;
        draw->AddLine(ImVec2(c.x + sign * s * 0.16f, c.y - s * 0.28f), ImVec2(c.x - sign * s * 0.16f, c.y), color, t);
        draw->AddLine(ImVec2(c.x - sign * s * 0.16f, c.y), ImVec2(c.x + sign * s * 0.16f, c.y + s * 0.28f), color, t);
    }
}

void actionButton(const char* id, const char* icon, const char* label, bool expanded,
                  bool active, ImVec2 size, const ImVec4& accent,
                  const std::function<void()>& onClick) {
    static std::unordered_map<std::string, double> pulseStart;
    ImGui::PushID(id);
    const bool clicked = ImGui::InvisibleButton("##button", size);
    const ImVec2 min = ImGui::GetItemRectMin();
    const ImVec2 max = ImGui::GetItemRectMax();
    const bool hovered = ImGui::IsItemHovered();
    const bool pressed = ImGui::IsItemActive();
    ImGui::PopID();

    const double now = ImGui::GetTime();
    if (clicked) {
        pulseStart[id] = now;
        onClick();
    }
    const float rounding = 18.0f;
    const ImVec4 base = active ? ImVec4(0.13f, 0.28f, 0.27f, 1.0f)
                              : (hovered ? ImVec4(0.17f, 0.22f, 0.25f, 1.0f) : ImVec4(0.105f, 0.135f, 0.155f, 1.0f));
    ImDrawList* draw = ImGui::GetWindowDrawList();
    draw->AddRectFilled(min, max, ImGui::ColorConvertFloat4ToU32(base), rounding);
    draw->AddRect(min, max, active ? IM_COL32(105, 229, 207, 135) : IM_COL32(95, 116, 124, hovered ? 150 : 78), rounding, 0, 1.0f);

    const ImVec2 center((min.x + max.x) * 0.5f, (min.y + max.y) * 0.5f);
    const ImU32 iconColor = active ? IM_COL32(151, 246, 224, 255) : IM_COL32(218, 228, 230, 245);
    const float iconSize = std::min(23.0f * ImGui::GetIO().FontGlobalScale, size.y * 0.46f);
    ImVec2 iconCenter = center;
    if (expanded) iconCenter.x = min.x + 29.0f * ImGui::GetIO().FontGlobalScale;
    drawGlyphIcon(draw, icon, iconCenter, iconSize, iconColor);
    if (expanded) {
        const ImVec2 textSize = ImGui::CalcTextSize(label);
        const float tx = iconCenter.x + iconSize * 0.78f;
        draw->AddText(ImVec2(tx, center.y - textSize.y * 0.5f), IM_COL32(232, 240, 240, 255), label);
    }
    if (active) {
        const float phase = static_cast<float>(std::fmod(now * 0.38, 1.0));
        const float breath = 0.55f + 0.45f * std::sin(static_cast<float>(now) * 2.0f);
        draw->AddCircleFilled(ImVec2(max.x - 10.0f, min.y + 10.0f), 3.2f, IM_COL32(116, 243, 211, 255), 16);
        // Slow rotating four-part Glyph halo remains visible while a feature is on.
        for (int segment = 0; segment < 4; ++segment) {
            const float start = -kPi * 0.5f + segment * (kPi * 0.5f) + phase * kPi * 2.0f;
            const ImU32 halo = ImGui::ColorConvertFloat4ToU32(
                ImVec4(accent.x, accent.y, accent.z, 0.22f + 0.18f * breath));
            draw->PathArcTo(center, std::min(size.x, size.y) * 0.43f,
                            start, start + kPi * 0.18f, 10);
            draw->PathStroke(halo, 0, 1.2f + breath * 0.7f);
        }
    }

    const auto it = pulseStart.find(id);
    if (it != pulseStart.end()) {
        const float progress = static_cast<float>((now - it->second) / 0.95);
        if (progress >= 0.0f && progress < 1.0f) {
            const float alpha = 1.0f - progress;
            const ImU32 glow = ImGui::ColorConvertFloat4ToU32(ImVec4(accent.x, accent.y, accent.z, 0.75f * alpha));
            // Glyph-like segmented halo around the pressed control.
            for (int segment = 0; segment < 4; ++segment) {
                const float start = -kPi * 0.5f + segment * (kPi * 0.5f) + progress * kPi * 0.8f;
                draw->PathArcTo(center, std::min(size.x, size.y) * (0.37f + progress * 0.10f), start, start + kPi * 0.27f, 12);
                draw->PathStroke(glow, 0, 2.0f + alpha * 2.0f);
            }
            const float sweepX = min.x + (max.x - min.x) * progress;
            draw->AddLine(ImVec2(sweepX, min.y + 5.0f), ImVec2(sweepX, max.y - 5.0f), glow, 1.5f + alpha * 2.0f);
            draw->AddRect(min, max, glow, rounding, 0, 1.0f + alpha * 1.6f);
        }
    }
    if (pressed) {
        draw->AddRectFilled(min, max, IM_COL32(150, 255, 231, 22), rounding);
    }
}

void restartCamera(AppState& state) {
    state.cameraDesired = true;
    state.cameraAutoRetryExhausted = false;
    state.cameraRetryCount = 0;
    state.torchEnabled = false;
    state.camera_.stop(); // queued; does not block the render thread
    state.lastCameraFrameAt = {};
    state.lastObservedCameraFrames = 0;
    state.cameraAttemptAt = {};
    state.nextCameraRetryAt = std::chrono::steady_clock::now();
    if (!state.hasCameraPermission) {
        state.permissionDialogSent = false;
        state.cameraPermissionRequested = false;
        requestCameraPermission(state);
        state.cameraStatus = "Нужно разрешение камеры";
    } else {
        state.cameraStatus = "Перезапуск камеры…";
    }
    state.addLog("Пользователь запросил перезапуск камеры");
}

void drawToolbar(AppState& state) {
    const float scale = state.uiScale;
    const float width = ImGui::GetContentRegionAvail().x;
    const float gap = 7.0f * scale;
    const float rowHeight = 48.0f * scale;
    const float dockHeight = (state.toolbarExpanded ? 154.0f : 70.0f) * scale;
    ImGui::BeginChild("action_dock", ImVec2(0, dockHeight), true,
                      ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);

    const ImVec4 teal(0.25f, 0.78f, 0.68f, 1.0f);
    const ImVec4 blue(0.40f, 0.67f, 0.88f, 1.0f);
    const ImVec4 amber(0.95f, 0.70f, 0.34f, 1.0f);
    const ImVec4 rose(0.88f, 0.43f, 0.48f, 1.0f);

    auto cameraAction = [&](float buttonWidth) {
        actionButton("camera", "camera", "Камера", state.toolbarExpanded, state.cameraDesired,
                     ImVec2(buttonWidth, rowHeight), teal, [&] {
            state.cameraDesired = !state.cameraDesired;
            if (!state.cameraDesired) {
                state.camera_.stop();
                state.torchEnabled = false;
                state.cameraStatus = "Камера выключена";
            } else if (!state.hasCameraPermission) {
                state.permissionDialogSent = false;
                state.cameraPermissionRequested = false;
                requestCameraPermission(state);
            } else {
                state.cameraAutoRetryExhausted = false;
                state.cameraRetryCount = 0;
                state.cameraAttemptAt = {};
                state.nextCameraRetryAt = std::chrono::steady_clock::now();
                state.cameraStatus = "Запрос запуска камеры…";
            }
        });
    };
    auto logAction = [&](float buttonWidth) {
        actionButton("log", "log", "Журнал", state.toolbarExpanded, state.showLog,
                     ImVec2(buttonWidth, rowHeight), blue, [&] { state.showLog = !state.showLog; });
    };
    auto visionAction = [&](float buttonWidth) {
        actionButton("vision", "gps", "Навигация", state.toolbarExpanded, state.visionEnabled_.load(),
                     ImVec2(buttonWidth, rowHeight), teal, [&] {
            const bool enabled = !state.visionEnabled_.load();
            state.visionEnabled_.store(enabled);
            if (!enabled) {
                std::lock_guard<std::mutex> lock(state.frameMutex_);
                state.latestVision_ = VisionFrame{};
            }
            state.addLog(enabled ? "Распознавание включено" : "Распознавание выключено");
        });
    };
    auto gpsAction = [&](float buttonWidth) {
        actionButton("map", "gps", "GPS / Карта", state.toolbarExpanded, state.showMap,
                     ImVec2(buttonWidth, rowHeight), blue, [&] {
            state.showMap = !state.showMap;
            if (state.showMap && !state.hasGpsPermission) {
                state.locationPermissionRequested = false;
                requestLocationPermission(state);
            }
        });
    };
    auto flashAction = [&](float buttonWidth) {
        actionButton("torch", "flash", "Фонарик", state.toolbarExpanded, state.torchEnabled,
                     ImVec2(buttonWidth, rowHeight), amber, [&] {
            const bool requested = !state.torchEnabled;
            if (state.camera_.setTorch(requested)) {
                state.addLog(requested ? "Команда включения фонарика поставлена в очередь" : "Команда выключения фонарика поставлена в очередь");
            } else {
                state.addLog("Фонарик недоступен: проверь Camera2 active, flashAvailable и предыдущую ошибку в полном логе");
            }
        });
    };
    auto restartAction = [&](float buttonWidth) {
        actionButton("restart", "restart", "Перезапуск", state.toolbarExpanded, false,
                     ImVec2(buttonWidth, rowHeight), rose, [&] { restartCamera(state); });
    };
    auto collectLogAction = [&](float buttonWidth) {
        actionButton("collect_log", "export", "Собрать лог", state.toolbarExpanded, false,
                     ImVec2(buttonWidth, rowHeight), amber, [&] {
            state.requestSessionLogExport(); // disk I/O and JNI run on a worker, never on the render thread
        });
    };

    if (!state.toolbarExpanded) {
        const float arrowWidth = 32.0f * scale;
        const float buttonWidth = std::max(34.0f * scale, (width - arrowWidth - gap * 7.0f) / 7.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(gap, 0));
        ImGui::PushItemWidth(buttonWidth);
        cameraAction(buttonWidth); ImGui::SameLine(0, gap);
        logAction(buttonWidth); ImGui::SameLine(0, gap);
        visionAction(buttonWidth); ImGui::SameLine(0, gap);
        gpsAction(buttonWidth); ImGui::SameLine(0, gap);
        flashAction(buttonWidth); ImGui::SameLine(0, gap);
        restartAction(buttonWidth); ImGui::SameLine(0, gap);
        collectLogAction(buttonWidth); ImGui::SameLine(0, gap);
        actionButton("toolbar_expand", "chevron", "", false, false, ImVec2(arrowWidth, rowHeight), teal, [&] { state.toolbarExpanded = true; });
        ImGui::PopItemWidth();
        ImGui::PopStyleVar();
    } else {
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(gap, gap));
        const float arrowWidth = 38.0f * scale;
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 1.0f * scale);
        ImGui::TextColored(ImVec4(0.63f, 0.75f, 0.76f, 1.0f), "УПРАВЛЕНИЕ");
        ImGui::SameLine(width - arrowWidth - 8.0f * scale);
        actionButton("toolbar_collapse", "chevron-left", "", false, false, ImVec2(arrowWidth, 30.0f * scale), teal, [&] { state.toolbarExpanded = false; });
        const float buttonWidth = (width - gap * 3.0f) / 4.0f;
        ImGui::PushItemWidth(buttonWidth);
        cameraAction(buttonWidth); ImGui::SameLine(0, gap); logAction(buttonWidth); ImGui::SameLine(0, gap);
        visionAction(buttonWidth); ImGui::SameLine(0, gap); gpsAction(buttonWidth);
        flashAction(buttonWidth); ImGui::SameLine(0, gap); restartAction(buttonWidth); ImGui::SameLine(0, gap);
        collectLogAction(buttonWidth);
        ImGui::PopItemWidth();
        ImGui::PopStyleVar();
    }
    ImGui::EndChild();
}

void drawMapPanel(AppState& state) {
    if (!state.showMap) return;
    ImGui::Spacing();
    ImGui::BeginChild("navigation_panel", ImVec2(0, 125.0f), true);
    ImGui::TextColored(ImVec4(0.50f, 0.80f, 1.0f, 1.0f), "НАВИГАЦИЯ / GPS");
    if (state.gps.available) {
        ImGui::Text("Широта: %.6f   Долгота: %.6f", state.gps.latitude, state.gps.longitude);
        ImGui::Text("Точность последней позиции: примерно %.0f м", state.gps.accuracyMeters);
        const int64_t age = state.gps.timestampMs > 0 ? (static_cast<int64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count()) - state.gps.timestampMs) / 1000 : -1;
        if (age >= 0) ImGui::Text("Возраст координат: %lld сек.", static_cast<long long>(age));
    } else {
        ImGui::TextWrapped("Последняя GPS-позиция недоступна. Проверь разрешение на геолокацию и включение служб местоположения.");
    }
    {
        std::lock_guard<std::mutex> lock(state.frameMutex_);
        const VisionFrame& vision = state.latestVision_;
        ImGui::TextWrapped("Визуальная привязка: %s", vision.mapStatus.c_str());
        if (vision.nearestWaypointId >= 0) {
            ImGui::Text("Следующая ближайшая точка маршрута: %d", vision.nearestWaypointId);
        } else {
            ImGui::TextDisabled("Следующая точка: нет подтверждённой привязки к карте");
        }
        ImGui::TextDisabled("Погода по камере: %s", vision.weather.c_str());
    }
    ImGui::TextDisabled("Для сопоставления карты добавь map.jpg в app/src/main/assets; маршрут задаётся в route.csv.");
    ImGui::EndChild();
}

void drawRoverMark(ImDrawList* draw, ImVec2 origin, float scale) {
    const ImU32 chassis = IM_COL32(202, 218, 215, 255);
    const ImU32 wheelOuter = IM_COL32(52, 73, 78, 255);
    const ImU32 wheelRing = IM_COL32(102, 151, 151, 255);
    const ImU32 glow = IM_COL32(104, 239, 211, 255);
    const float baseY = origin.y + 21.0f * scale;
    // Six wheels: a visible near-side and far-side rocker-bogie row.
    for (int i = 0; i < 3; ++i) {
        const float x = origin.x + (7.0f + i * 10.0f) * scale;
        const float farY = baseY - 5.2f * scale;
        const float nearY = baseY + 1.0f * scale;
        draw->AddCircleFilled(ImVec2(x, farY), 3.0f * scale, wheelOuter, 18);
        draw->AddCircle(ImVec2(x, farY), 3.0f * scale, wheelRing, 18, 0.9f * scale);
        draw->AddCircleFilled(ImVec2(x, nearY), 3.0f * scale, wheelOuter, 18);
        draw->AddCircle(ImVec2(x, nearY), 3.0f * scale, glow, 18, 0.9f * scale);
    }
    // Suspension links and main rover body.
    draw->AddLine(ImVec2(origin.x + 7.0f * scale, baseY - 2.0f * scale),
                  ImVec2(origin.x + 17.0f * scale, baseY - 9.0f * scale), chassis, 1.2f * scale);
    draw->AddLine(ImVec2(origin.x + 17.0f * scale, baseY - 9.0f * scale),
                  ImVec2(origin.x + 27.0f * scale, baseY - 2.0f * scale), chassis, 1.2f * scale);
    draw->AddRectFilled(ImVec2(origin.x + 8.5f * scale, baseY - 16.0f * scale),
                        ImVec2(origin.x + 26.0f * scale, baseY - 9.0f * scale), chassis, 2.5f * scale);
    draw->AddRectFilled(ImVec2(origin.x + 14.0f * scale, baseY - 14.2f * scale),
                        ImVec2(origin.x + 22.0f * scale, baseY - 12.0f * scale),
                        IM_COL32(48, 94, 91, 255), 1.0f * scale);
    draw->AddLine(ImVec2(origin.x + 22.5f * scale, baseY - 16.0f * scale),
                  ImVec2(origin.x + 24.0f * scale, baseY - 22.0f * scale), chassis, 1.1f * scale);
    draw->AddCircleFilled(ImVec2(origin.x + 24.0f * scale, baseY - 22.0f * scale), 2.0f * scale, glow, 14);
}

void drawUi(AppState& state, const EglState& egl) {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(static_cast<float>(egl.width), static_cast<float>(egl.height));
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(io.DisplaySize);
    ImGui::Begin("Diplomka Native UI", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoBackground);

    const float scale = state.uiScale;
    const float pad = 14.0f * scale;
    const ImVec2 screen = io.DisplaySize;
    ImDrawList* bg = ImGui::GetWindowDrawList();
    bg->AddRectFilled(ImVec2(0, 0), screen, IM_COL32(10, 15, 18, 255));

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(pad, 9.0f * scale));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(7.0f * scale, 7.0f * scale));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 17.0f * scale);

    // Header / brand identity.
    ImGui::BeginGroup();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    const ImVec2 logoPos = ImGui::GetCursorScreenPos();
    drawRoverMark(draw, ImVec2(logoPos.x, logoPos.y + 1.0f * scale), 1.0f * scale);
    ImGui::Dummy(ImVec2(40.0f * scale, 31.0f * scale));
    ImGui::SameLine(0, 5.0f * scale);
    ImGui::BeginGroup();
    ImGui::TextColored(ImVec4(0.91f, 0.96f, 0.94f, 1.0f), "DIPLOMKA");
    ImGui::TextDisabled("CLASSICAL VISION · 2.7.0");
    ImGui::EndGroup();
    ImGui::EndGroup();
    ImGui::SameLine(screen.x - 104.0f * scale);
    const bool live = state.camera_.isRunning() && state.camera_.frameCount() > 0;
    const bool opening = state.camera_.isStartPending();
    const ImU32 statusColor = live ? IM_COL32(107, 238, 199, 255) : (opening ? IM_COL32(250, 190, 100, 255) : IM_COL32(232, 125, 125, 255));
    const char* statusLabel = live ? "LIVE" : (opening ? "OPENING" : "OFFLINE");
    const ImVec2 badgeMin = ImGui::GetCursorScreenPos();
    const ImVec2 badgeSize(91.0f * scale, 29.0f * scale);
    draw->AddRectFilled(badgeMin, ImVec2(badgeMin.x + badgeSize.x, badgeMin.y + badgeSize.y), IM_COL32(25, 38, 40, 255), 15.0f * scale);
    const float statusPulse = 0.72f + 0.28f * std::sin(static_cast<float>(ImGui::GetTime()) * 3.0f);
    draw->AddCircleFilled(ImVec2(badgeMin.x + 13.0f * scale, badgeMin.y + 14.5f * scale),
                          (3.0f + (live ? 1.0f - statusPulse : 0.0f)) * scale, statusColor, 16);
    draw->AddText(ImVec2(badgeMin.x + 23.0f * scale, badgeMin.y + 7.0f * scale), IM_COL32(219, 232, 229, 255), statusLabel);
    ImGui::Dummy(badgeSize);

    // Compact status surface.
    ImGui::Spacing();
    const float statusHeight = 132.0f * scale;
    ImGui::BeginChild("status_surface", ImVec2(0, statusHeight), true, ImGuiWindowFlags_NoScrollbar);
    ImGui::TextWrapped("%s", state.cameraStatus.c_str());
    ImGui::SameLine(0, 10.0f * scale);
    ImGui::TextDisabled("%llu кадров", static_cast<unsigned long long>(state.cameraFrameCount_.load()));
    if (!state.camera_.isRunning() || state.camera_.isTorchPending()) {
        ImGui::TextDisabled("Camera2: %s", state.camera_.stageText().c_str());
    }
    if (state.camera_.isTorchPending()) ImGui::TextColored(ImVec4(0.95f, 0.72f, 0.34f, 1.0f), "Фонарик: запрос обрабатывается");
    ImGui::TextDisabled("Вспышка: %s · Camera2 results: %llu · failed: %llu",
        state.camera_.isTorchAvailable() ? (state.camera_.isTorchEnabled() ? "включена" : "доступна") : "не обнаружена",
        static_cast<unsigned long long>(state.camera_.captureResultCount()),
        static_cast<unsigned long long>(state.camera_.captureFailureCount()));
    ImGui::TextDisabled("Компас  %s", state.hasHeading ? (std::to_string(static_cast<int>(state.currentHeading)) + "°").c_str() : "калибровка");
    ImGui::SameLine(0, 14.0f * scale);
    const int detections = [&state]() { std::lock_guard<std::mutex> lock(state.frameMutex_); return static_cast<int>(state.latestVision_.detections.size()); }();
    ImGui::TextDisabled("Объекты  %d", detections);
    {
        std::lock_guard<std::mutex> lock(state.frameMutex_);
        const VisionFrame& v = state.latestVision_;
        if (v.stopSignal) ImGui::TextColored(ImVec4(1.0f, 0.28f, 0.22f, 1.0f), "СТОП · %s", v.stopReason.c_str());
        else ImGui::TextColored(ImVec4(0.35f, 0.90f, 0.65f, 1.0f), "Направление: %s", v.direction.c_str());
        ImGui::TextDisabled("Погода: %s", v.weather.c_str());
        ImGui::TextDisabled("Маршрут: %s", v.mapStatus.c_str());
    }
    ImGui::EndChild();

    const float dockHeight = (state.toolbarExpanded ? 154.0f : 70.0f) * scale;
    const float logHeight = state.showLog ? 92.0f * scale : 0.0f;
    const float navHeight = state.showMap ? 128.0f * scale : 0.0f;
    const float remaining = ImGui::GetContentRegionAvail().y - dockHeight - logHeight - navHeight - 22.0f * scale;
    const float previewHeight = std::max(170.0f * scale, remaining);
    drawCameraPreview(state, ImVec2(0, previewHeight));
    if (state.showMap) drawMapPanel(state);
    if (state.showLog) drawLogPanel(state, logHeight);
    drawToolbar(state);

    ImGui::PopStyleVar(3);
    ImGui::End();
}

void initializeImGui(ANativeWindow* window, float densityScale) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigInputTrickleEventQueue = false;
    ImFontConfig config;
    config.SizePixels = 16.5f * densityScale;
    ImFont* font = io.Fonts->AddFontFromFileTTF("/system/fonts/Roboto-Regular.ttf", config.SizePixels, &config, io.Fonts->GetGlyphRangesCyrillic());
    if (!font) io.Fonts->AddFontDefault();

    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.ScaleAllSizes(densityScale);
    style.WindowRounding = 22.0f * densityScale;
    style.ChildRounding = 20.0f * densityScale;
    style.FrameRounding = 17.0f * densityScale;
    style.PopupRounding = 18.0f * densityScale;
    style.ScrollbarRounding = 14.0f * densityScale;
    style.GrabRounding = 14.0f * densityScale;
    style.FramePadding = ImVec2(13.0f * densityScale, 12.0f * densityScale);
    style.ItemSpacing = ImVec2(8.0f * densityScale, 8.0f * densityScale);
    style.WindowPadding = ImVec2(14.0f * densityScale, 12.0f * densityScale);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.035f, 0.055f, 0.065f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.075f, 0.105f, 0.115f, 0.98f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.09f, 0.13f, 0.14f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.11f, 0.16f, 0.17f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.16f, 0.23f, 0.23f, 1.0f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.19f, 0.30f, 0.28f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.10f, 0.15f, 0.16f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.15f, 0.23f, 0.23f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.19f, 0.34f, 0.31f, 1.0f);
    style.Colors[ImGuiCol_Header] = ImVec4(0.13f, 0.24f, 0.22f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.59f, 0.94f, 0.84f, 1.0f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.45f, 0.82f, 0.73f, 1.0f);
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.68f, 0.98f, 0.89f, 1.0f);
    ImGui_ImplAndroid_Init(window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
}

void shutdownImGui() {
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
}

void handleAppCommand(android_app* app, int32_t command) {
    auto* state = static_cast<AppState*>(app->userData);
    if (!state) return;
    switch (command) {
        case APP_CMD_INIT_WINDOW: {
            LOGI("APP_CMD_INIT_WINDOW window=%p", static_cast<void*>(app->window));
            if (app->window) {
                state->hasWindow = true;
                state->requestVisionInitialization(app->activity ? app->activity->assetManager : nullptr);
                state->sensors_.start(app->looper);
            }
            break;
        }
        case APP_CMD_TERM_WINDOW:
            LOGI("APP_CMD_TERM_WINDOW received; stopping camera and sensors");
            state->camera_.stop();
            state->sensors_.stop();
            state->hasWindow = false;
            break;
        case APP_CMD_GAINED_FOCUS:
            break;
        case APP_CMD_LOST_FOCUS:
            break;
        case APP_CMD_LOW_MEMORY:
            LOGW("Android reported low memory");
            state->addLog("Android сообщил о нехватке памяти");
            break;
        default:
            break;
    }
}

int32_t handleInput(android_app* app, AInputEvent* event) {
    auto* state = app ? static_cast<AppState*>(app->userData) : nullptr;
    if (!ImGui::GetCurrentContext()) return 0;

    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        const int32_t action = AMotionEvent_getAction(event) & AMOTION_EVENT_ACTION_MASK;
        if (action == AMOTION_EVENT_ACTION_DOWN && state) ++state->touchEvents;
        if (action == AMOTION_EVENT_ACTION_CANCEL) {
            ImGuiIO& io = ImGui::GetIO();
            io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen);
            io.AddMouseButtonEvent(0, false);
            io.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
            if (state) state->touchDown = false;
            return 1;
        }
        if (action == AMOTION_EVENT_ACTION_DOWN && state) state->touchDown = true;
        if (action == AMOTION_EVENT_ACTION_UP && state) state->touchDown = false;
    }

    // Use Dear ImGui's maintained Android backend for the actual pointer/key
    // event mapping; this avoids diverging from changes in Android input APIs.
    return ImGui_ImplAndroid_HandleInputEvent(event) ? 1 : 0;
}

void renderFrame(AppState& state, EglState& egl) {
    if (egl.display == EGL_NO_DISPLAY || egl.surface == EGL_NO_SURFACE) return;
    eglQuerySurface(egl.display, egl.surface, EGL_WIDTH, &egl.width);
    eglQuerySurface(egl.display, egl.surface, EGL_HEIGHT, &egl.height);
    glViewport(0, 0, egl.width, egl.height);
    glClearColor(0.025f, 0.040f, 0.060f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    updateTexture(state);
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
    drawUi(state, egl);
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(egl.display, egl.surface);
}
}

extern "C" void android_main(android_app* app) {
    app_dummy();
    LOGI("android_main entered; starting Diplomka native process session");
    AppState state(app);
    logAndroidDeviceInfo(app ? app->activity : nullptr);
    app->userData = &state;
    app->onAppCmd = &handleAppCommand;
    app->onInputEvent = &handleInput;

    EglState egl;
    bool eglReady = false;
    bool firstPermissionCheck = false;

    while (!app->destroyRequested) {
        int events = 0;
        android_poll_source* source = nullptr;
        // Use the current NDK looper API and preserve timeout/event-source handling.
        // pollOnce also
        // reports callback/wake/timeout conditions through ALOOPER_POLL_*.
        const int ident = ALooper_pollOnce(16, nullptr, &events, reinterpret_cast<void**>(&source));
        if (ident >= 0) {
            if (source != nullptr) source->process(app, source);
        } else if (ident == ALOOPER_POLL_ERROR) {
            LOGE("ALooper_pollOnce returned ALOOPER_POLL_ERROR");
        }
        state.sensors_.poll();
        state.hasHeading = state.sensors_.hasHeading();
        state.currentHeading = state.sensors_.headingDegrees();

        if (!firstPermissionCheck && app->activity) {
            state.hasCameraPermission = checkPermission(app->activity, "android.permission.CAMERA");
            state.hasGpsPermission = checkPermission(app->activity, "android.permission.ACCESS_FINE_LOCATION") ||
                                     checkPermission(app->activity, "android.permission.ACCESS_COARSE_LOCATION");
            LOGI("Initial permissions: camera=%s location=%s", state.hasCameraPermission ? "granted" : "denied",
                 state.hasGpsPermission ? "granted" : "denied");
            if (!state.hasCameraPermission) {
                requestCameraPermission(state);
                state.permissionDialogSent = true;
            }
            firstPermissionCheck = true;
        }
        updatePermissionsAndServices(state);
        const std::string toastMessage = state.takePendingToast();
        if (!toastMessage.empty() && app->activity) showAndroidToast(app->activity, toastMessage);

        if (app->window && state.hasWindow && !eglReady) {
            eglReady = initEgl(app->window, egl);
            if (eglReady) {
                LOGI("EGL initialized: %dx%d", egl.width, egl.height);
                const int densityDpi = app->config ? AConfiguration_getDensity(app->config) : ACONFIGURATION_DENSITY_DEFAULT;
                state.uiScale = densityDpi > 0 ? std::clamp(static_cast<float>(densityDpi) / 160.0f, 1.0f, 2.5f) : 1.0f;
                initializeImGui(app->window, state.uiScale);
            } else {
                LOGE("EGL initialization failed");
            }
        }
        if ((!app->window || !state.hasWindow) && eglReady) {
            if (ImGui::GetCurrentContext()) shutdownImGui();
            if (state.previewTexture) {
                glDeleteTextures(1, &state.previewTexture);
                state.previewTexture = 0;
            }
            shutdownEgl(egl);
            eglReady = false;
        }
        if (eglReady && ImGui::GetCurrentContext()) renderFrame(state, egl);
    }

    state.camera_.stop();
    state.sensors_.stop();
    if (eglReady) {
        if (ImGui::GetCurrentContext()) shutdownImGui();
        if (state.previewTexture) glDeleteTextures(1, &state.previewTexture);
        shutdownEgl(egl);
    }
}
