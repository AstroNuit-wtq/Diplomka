#include "camera_engine.h"

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <limits>
#include <cstdint>
#include <cstring>
#include <string>
#include <utility>
#include <memory>
#include <vector>

#include <android/log.h>
#include "session_logger.h"
#include <camera/NdkCameraDevice.h>
#include <camera/NdkCameraMetadata.h>
#include <camera/NdkCameraMetadataTags.h>
#include <camera/NdkCaptureRequest.h>
#include <media/NdkImage.h>

#define LOG_TAG "DiplomkaNative-Camera"
#define LOGI(...) appLogWrite(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) appLogWrite(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) appLogWrite(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

struct CameraCallbackBridge {
    std::mutex mutex;
    std::condition_variable cv;
    CameraEngine* owner = nullptr;
    uint32_t callbacksInFlight = 0;
    ACameraCaptureSession* lastClosedSession = nullptr;
};

namespace {
const char* flashStateName(int state) {
    switch (state) {
        case ACAMERA_FLASH_STATE_UNAVAILABLE: return "UNAVAILABLE";
        case ACAMERA_FLASH_STATE_CHARGING: return "CHARGING";
        case ACAMERA_FLASH_STATE_READY: return "READY";
        case ACAMERA_FLASH_STATE_FIRED: return "FIRED";
        case ACAMERA_FLASH_STATE_PARTIAL: return "PARTIAL";
        default: return "UNKNOWN";
    }
}

// NDK callbacks can be posted by framework-owned loopers after close has
// started. Keep the tiny bridge alive for the process lifetime; shutdown sets
// owner=nullptr so late callbacks cannot dereference a destroyed CameraEngine.
std::mutex gBridgeMutex;
std::vector<std::shared_ptr<CameraCallbackBridge>> gCallbackBridges;

inline uint8_t clampByte(int value) {
    return static_cast<uint8_t>(std::max(0, std::min(255, value)));
}
}

CameraEngine::CameraEngine() {
    callbackBridge_ = std::make_shared<CameraCallbackBridge>();
    callbackBridge_->owner = this;
    {
        std::lock_guard<std::mutex> lock(gBridgeMutex);
        gCallbackBridges.push_back(callbackBridge_);
    }
    worker_ = std::thread(&CameraEngine::workerLoop, this);
    std::unique_lock<std::mutex> lock(startupMutex_);
    startupCv_.wait_for(lock, std::chrono::seconds(3), [this] { return workerReady_; });
    if (!workerReady_ || workerFailed_.load()) {
        LOGE("Camera worker failed to prepare ALooper");
    }
}

CameraEngine::~CameraEngine() {
    shutdown();
    if (callbackBridge_) {
        std::unique_lock<std::mutex> lock(callbackBridge_->mutex);
        callbackBridge_->owner = nullptr;
        callbackBridge_->cv.wait(lock, [this] { return callbackBridge_->callbacksInFlight == 0; });
    }
}

void CameraEngine::setError(int errorCode, const char* operation) {
    lastErrorCode_.store(errorCode);
    const std::string label = operation ? operation : "Camera operation";
    {
        std::lock_guard<std::mutex> lock(diagnosticMutex_);
        lastErrorText_ = label + " · код " + std::to_string(errorCode);
        stageText_ = lastErrorText_;
    }
    LOGE("%s failed with code %d", label.c_str(), errorCode);
}

void CameraEngine::setStage(const std::string& stage) {
    {
        std::lock_guard<std::mutex> lock(diagnosticMutex_);
        stageText_ = stage;
    }
    LOGI("Camera stage: %s", stage.c_str());
}

std::string CameraEngine::stageText() const {
    std::lock_guard<std::mutex> lock(diagnosticMutex_);
    return stageText_;
}

std::string CameraEngine::lastErrorText() const {
    std::lock_guard<std::mutex> lock(diagnosticMutex_);
    return lastErrorText_;
}

void CameraEngine::enqueue(Command command) {
    {
        std::lock_guard<std::mutex> lock(commandMutex_);
        commands_.push_back(std::move(command));
    }
    if (ALooper* looper = looper_.load()) ALooper_wake(looper);
}

bool CameraEngine::start(FrameConsumer consumer) {
    if (shutdownRequested_.load() || workerFailed_.load()) return false;
    if (running_.load() || startPending_.exchange(true)) return true;
    enqueue(Command{CommandType::Start, std::move(consumer), false});
    return true;
}

void CameraEngine::stop() {
    startPending_.store(false);
    running_.store(false);
    sessionActive_.store(false);
    repeatingStarted_.store(false);
    if (shutdownRequested_.load()) return;
    if (!stopPending_.exchange(true)) enqueue(Command{CommandType::Stop, {}, false});
}

bool CameraEngine::setTorch(bool enabled) {
    if (!running_.load() || !flashAvailable_.load() || shutdownRequested_.load()) return false;
    torchPending_.store(true);
    enqueue(Command{CommandType::Torch, {}, enabled});
    return true;
}

void CameraEngine::shutdown() {
    if (!worker_.joinable()) return;
    if (!shutdownRequested_.exchange(true)) {
        running_.store(false);
        startPending_.store(false);
        enqueue(Command{CommandType::Shutdown, {}, false});
    }
    if (ALooper* looper = looper_.load()) ALooper_wake(looper);
    worker_.join();
}

void CameraEngine::workerLoop() {
    ALooper* workerLooper = ALooper_prepare(ALOOPER_PREPARE_ALLOW_NON_CALLBACKS);
    {
        std::lock_guard<std::mutex> lock(startupMutex_);
        workerFailed_ = workerLooper == nullptr;
        workerReady_ = true;
        looper_.store(workerLooper);
    }
    startupCv_.notify_all();

    if (!workerLooper) {
        shutdownComplete_.store(true);
        return;
    }

    bool exit = false;
    while (!exit) {
        processCommands();
        // Start preview immediately after createCaptureSession returns. The NDK
        // onReady callback is an idle/queue-drained notification, not a reliable
        // initial-configured signal; waiting for it can deadlock the first frame.
        tryStartRepeatingRequest();
        if (shutdownRequested_.load()) {
            stopOnWorker();
            // Process queued camera callbacks while the reader listener is
            // detached and the owning object is still alive.
            int events = 0;
            void* data = nullptr;
            ALooper_pollOnce(0, nullptr, &events, &data);
            exit = true;
            break;
        }

        int events = 0;
        void* data = nullptr;
        const int ident = ALooper_pollOnce(100, nullptr, &events, &data);
        if (ident == ALOOPER_POLL_ERROR) {
            LOGE("Camera worker ALooper_pollOnce returned ALOOPER_POLL_ERROR");
        }
    }

    stopOnWorker();
    looper_.store(nullptr);
    ALooper_release(workerLooper);
    shutdownComplete_.store(true);
}

void CameraEngine::processCommands() {
    std::deque<Command> local;
    {
        std::lock_guard<std::mutex> lock(commandMutex_);
        local.swap(commands_);
    }

    for (auto& command : local) {
        switch (command.type) {
            case CommandType::Start:
                if (!startPending_.load()) break; // superseded by a Stop command
                if (!startOnWorker(std::move(command.consumer))) {
                    startPending_.store(false);
                    running_.store(false);
                }
                break;
            case CommandType::Stop:
                stopOnWorker();
                stopPending_.store(false);
                break;
            case CommandType::Torch:
                setTorchOnWorker(command.enabled);
                break;
            case CommandType::Shutdown:
                shutdownRequested_.store(true);
                break;
            case CommandType::SessionReady:
                // onReady means the previous capture work has drained. It is a
                // useful retry signal, but not the initial session-configured
                // event: the first repeating request is attempted independently.
                if (command.session && session_ == command.session && startPending_.load() && !repeatingRequestSubmitted_) {
                    nextRepeatingRequestAttempt_ = std::chrono::steady_clock::now();
                }
                break;
            case CommandType::SessionActive:
                if (command.session && session_ == command.session) {
                    sessionActive_.store(true);
                    setStage("Camera2 session активна · запросы выполняются");
                }
                break;
            case CommandType::SessionClosed:
                if (command.session &&
                    (session_ == command.session || pendingCloseSession_ == command.session)) {
                    // NDK invalidates the session pointer before delivering
                    // onClosed. Never invoke methods on it after this event.
                    session_ = nullptr;
                    pendingCloseSession_ = nullptr;
                    sessionCloseTimedOut_ = false;
                    setError(ACAMERA_ERROR_SESSION_CLOSED, "Camera capture session closed");
                    running_.store(false);
                    startPending_.store(false);
                    sessionActive_.store(false);
                    repeatingStarted_.store(false);
                    // onClosed is the safe point to release the ImageReader
                    // Surface and the remaining request/output/device objects.
                    stopOnWorker();
                }
                break;
            case CommandType::DeviceError:
            case CommandType::DeviceDisconnected:
                if (command.device && device_ == command.device) {
                    setError(command.errorCode, command.type == CommandType::DeviceDisconnected
                        ? "Camera device disconnected" : "Camera device callback error");
                    running_.store(false);
                    startPending_.store(false);
                    sessionActive_.store(false);
                    repeatingStarted_.store(false);
                    // Release all Camera2 objects on their owning worker. The
                    // UI watchdog will schedule a fresh start if desired.
                    stopOnWorker();
                }
                break;
        }
    }
}

bool CameraEngine::chooseBackCamera() {
    if (!manager_) return false;
    ACameraIdList* ids = nullptr;
    const camera_status_t status = ACameraManager_getCameraIdList(manager_, &ids);
    if (status != ACAMERA_OK || ids == nullptr) {
        setError(status, "ACameraManager_getCameraIdList");
        return false;
    }

    std::string selectedId;
    int selectedWidth = 0;
    int selectedHeight = 0;
    bool selectedHasFlash = false;
    uint8_t selectedAfMode = ACAMERA_CONTROL_AF_MODE_OFF;
    uint8_t selectedAeMode = ACAMERA_CONTROL_AE_MODE_ON;
    for (int i = 0; i < ids->numCameras; ++i) {
        ACameraMetadata* metadata = nullptr;
        if (ACameraManager_getCameraCharacteristics(manager_, ids->cameraIds[i], &metadata) != ACAMERA_OK || !metadata) continue;

        ACameraMetadata_const_entry facing{};
        const bool hasFacing = ACameraMetadata_getConstEntry(metadata, ACAMERA_LENS_FACING, &facing) == ACAMERA_OK;
        const bool isBack = hasFacing && facing.count > 0 && facing.data.u8[0] == ACAMERA_LENS_FACING_BACK;

        int candidateWidth = 0;
        int candidateHeight = 0;
        ACameraMetadata_const_entry streams{};
        if (ACameraMetadata_getConstEntry(metadata, ACAMERA_SCALER_AVAILABLE_STREAM_CONFIGURATIONS, &streams) == ACAMERA_OK && streams.count >= 4) {
            int bestScore = std::numeric_limits<int>::max();
            for (uint32_t j = 0; j + 3 < streams.count; j += 4) {
                const int32_t format = streams.data.i32[j];
                const int32_t width = streams.data.i32[j + 1];
                const int32_t height = streams.data.i32[j + 2];
                const int32_t input = streams.data.i32[j + 3];
                if (format != AIMAGE_FORMAT_YUV_420_888 ||
                    input != ACAMERA_SCALER_AVAILABLE_STREAM_CONFIGURATIONS_OUTPUT ||
                    width < 320 || height < 240) continue;
                const int oversizePenalty = std::max(0, width - 1280) * 3 + std::max(0, height - 720) * 3;
                const int score = std::abs(width - 640) + std::abs(height - 480) + oversizePenalty;
                if (score < bestScore) {
                    bestScore = score;
                    candidateWidth = width;
                    candidateHeight = height;
                }
            }
        }

        ACameraMetadata_const_entry flash{};
        const bool hasFlash = ACameraMetadata_getConstEntry(metadata, ACAMERA_FLASH_INFO_AVAILABLE, &flash) == ACAMERA_OK &&
                              flash.count > 0 && flash.data.u8[0] != 0;

        uint8_t candidateAf = ACAMERA_CONTROL_AF_MODE_OFF;
        ACameraMetadata_const_entry afModes{};
        if (ACameraMetadata_getConstEntry(metadata, ACAMERA_CONTROL_AF_AVAILABLE_MODES, &afModes) == ACAMERA_OK) {
            const uint8_t preference[] = { ACAMERA_CONTROL_AF_MODE_CONTINUOUS_PICTURE,
                                           ACAMERA_CONTROL_AF_MODE_CONTINUOUS_VIDEO,
                                           ACAMERA_CONTROL_AF_MODE_AUTO,
                                           ACAMERA_CONTROL_AF_MODE_OFF };
            for (uint8_t preferred : preference) {
                for (uint32_t m = 0; m < afModes.count; ++m) {
                    if (afModes.data.u8[m] == preferred) { candidateAf = preferred; break; }
                }
                if (candidateAf == preferred) break;
            }
        }
        uint8_t candidateAe = ACAMERA_CONTROL_AE_MODE_ON;
        ACameraMetadata_const_entry aeModes{};
        if (ACameraMetadata_getConstEntry(metadata, ACAMERA_CONTROL_AE_AVAILABLE_MODES, &aeModes) == ACAMERA_OK && aeModes.count > 0) {
            bool aeOnSupported = false;
            for (uint32_t m = 0; m < aeModes.count; ++m) if (aeModes.data.u8[m] == ACAMERA_CONTROL_AE_MODE_ON) aeOnSupported = true;
            if (!aeOnSupported) candidateAe = aeModes.data.u8[0];
        }
        LOGI("Camera candidate id=%s facing=%s YUV=%dx%d flash=%s AF=%u AE=%u",
             ids->cameraIds[i], isBack ? "back" : (hasFacing ? "front/external" : "unknown"),
             candidateWidth, candidateHeight, hasFlash ? "yes" : "no", candidateAf, candidateAe);
        if (candidateWidth > 0 && candidateHeight > 0 && (selectedId.empty() || isBack)) {
            selectedId = ids->cameraIds[i];
            selectedWidth = candidateWidth;
            selectedHeight = candidateHeight;
            // Torch mode requires AE_MODE_ON or AE_MODE_OFF. Do not advertise a
            // torch when the chosen stream/camera metadata cannot confirm it.
            selectedHasFlash = hasFlash && candidateAe == ACAMERA_CONTROL_AE_MODE_ON;
            selectedAfMode = candidateAf;
            selectedAeMode = candidateAe;
        }
        ACameraMetadata_free(metadata);
        if (isBack && !selectedId.empty() && selectedId == ids->cameraIds[i]) break;
    }
    ACameraManager_deleteCameraIdList(ids);

    cameraId_ = std::move(selectedId);
    if (cameraId_.empty()) {
        setError(ACAMERA_ERROR_INVALID_PARAMETER, "No camera with YUV_420_888 output stream");
        return false;
    }
    width_.store(selectedWidth);
    height_.store(selectedHeight);
    flashAvailable_.store(selectedHasFlash);
    selectedAfMode_ = selectedAfMode;
    selectedAeMode_ = selectedAeMode;
    LOGI("Selected camera id=%s stream=%dx%d flashAvailable=%s AF=%u AE=%u",
         cameraId_.c_str(), selectedWidth, selectedHeight, selectedHasFlash ? "yes" : "no", selectedAfMode_, selectedAeMode_);
    return true;
}

bool CameraEngine::startOnWorker(FrameConsumer consumer) {
    stopOnWorker();
    if (sessionCloseTimedOut_) {
        setError(ACAMERA_ERROR_SESSION_CLOSED, "Previous Camera2 session is still closing");
        return false;
    }
    consumer_ = std::move(consumer);
    lastErrorCode_.store(0);
    frameCount_.store(0);
    sessionActive_.store(false);
    repeatingStarted_.store(false);
    repeatingRequestSubmitted_ = false;
    repeatingRequestStartAttempts_ = 0;
    nextRepeatingRequestAttempt_ = {};
    flashAvailable_.store(false);
    torchEnabled_.store(false);
    torchPending_.store(false);
    captureResultCount_.store(0);
    captureFailureCount_.store(0);
    imageCallbackCount_.store(0);
    lastFlashState_.store(-1);
    firstCaptureResultLogged_.store(false);
    firstImageCallbackLogged_.store(false);
    lastImageAcquireStatus_.store(0);
    {
        std::lock_guard<std::mutex> lock(diagnosticMutex_);
        lastErrorText_.clear();
    }
    setStage("Создание CameraManager");

    manager_ = ACameraManager_create();
    if (!manager_ || !chooseBackCamera()) {
        if (!lastErrorCode_.load()) setError(ACAMERA_ERROR_CAMERA_DEVICE, "No camera available");
        stopOnWorker();
        return false;
    }

    setStage("Создание YUV ImageReader");
    LOGI("Starting camera id=%s output=%dx%d", cameraId_.c_str(), width_.load(), height_.load());
    const media_status_t mediaStatus = AImageReader_new(width_.load(), height_.load(), AIMAGE_FORMAT_YUV_420_888, 4, &reader_);
    if (mediaStatus != AMEDIA_OK || !reader_) {
        setError(mediaStatus, "AImageReader_new"); stopOnWorker(); return false;
    }
    {
        std::lock_guard<std::mutex> callbackLock(imageCallbackMutex_);
        acceptImageCallbacks_ = true;
    }
    AImageReader_ImageListener listener{};
    listener.context = callbackBridge_.get();
    listener.onImageAvailable = &CameraEngine::onImageAvailable;
    const media_status_t listenerStatus = AImageReader_setImageListener(reader_, &listener);
    if (listenerStatus != AMEDIA_OK) {
        setError(listenerStatus, "AImageReader_setImageListener"); stopOnWorker(); return false;
    }
    const media_status_t windowStatus = AImageReader_getWindow(reader_, &readerWindow_);
    if (windowStatus != AMEDIA_OK || !readerWindow_) {
        setError(windowStatus, "AImageReader_getWindow"); stopOnWorker(); return false;
    }

    setStage("Открытие камеры " + cameraId_);
    ACameraDevice_StateCallbacks deviceCallbacks{};
    deviceCallbacks.context = callbackBridge_.get();
    deviceCallbacks.onDisconnected = &CameraEngine::onCameraDisconnected;
    deviceCallbacks.onError = &CameraEngine::onCameraError;
    camera_status_t cameraStatus = ACameraManager_openCamera(manager_, cameraId_.c_str(), &deviceCallbacks, &device_);
    if (cameraStatus != ACAMERA_OK || !device_) {
        setError(cameraStatus, "ACameraManager_openCamera"); stopOnWorker(); return false;
    }

    LOGI("Camera device opened id=%s", cameraId_.c_str());
    setStage("Создание Camera2 request");
    cameraStatus = ACameraOutputTarget_create(readerWindow_, &target_);
    if (cameraStatus != ACAMERA_OK || !target_) {
        setError(cameraStatus, "ACameraOutputTarget_create"); stopOnWorker(); return false;
    }
    cameraStatus = ACameraDevice_createCaptureRequest(device_, TEMPLATE_PREVIEW, &request_);
    if (cameraStatus != ACAMERA_OK || !request_) {
        setError(cameraStatus, "ACameraDevice_createCaptureRequest"); stopOnWorker(); return false;
    }
    if (ACaptureRequest_addTarget(request_, target_) != ACAMERA_OK) {
        setError(ACAMERA_ERROR_INVALID_PARAMETER, "ACaptureRequest_addTarget"); stopOnWorker(); return false;
    }

    const uint8_t controlMode = ACAMERA_CONTROL_MODE_AUTO;
    cameraStatus = ACaptureRequest_setEntry_u8(request_, ACAMERA_CONTROL_MODE, 1, &controlMode);
    if (cameraStatus == ACAMERA_OK)
        cameraStatus = ACaptureRequest_setEntry_u8(request_, ACAMERA_CONTROL_AE_MODE, 1, &selectedAeMode_);
    if (cameraStatus == ACAMERA_OK)
        cameraStatus = ACaptureRequest_setEntry_u8(request_, ACAMERA_CONTROL_AF_MODE, 1, &selectedAfMode_);
    if (cameraStatus != ACAMERA_OK) {
        setError(cameraStatus, "Configure preview CONTROL_MODE/AE_MODE/AF_MODE");
        stopOnWorker();
        return false;
    }

    cameraStatus = ACaptureSessionOutputContainer_create(&outputContainer_);
    if (cameraStatus != ACAMERA_OK || !outputContainer_) {
        setError(cameraStatus, "ACaptureSessionOutputContainer_create"); stopOnWorker(); return false;
    }
    cameraStatus = ACaptureSessionOutput_create(readerWindow_, &sessionOutput_);
    if (cameraStatus != ACAMERA_OK || !sessionOutput_) {
        setError(cameraStatus, "ACaptureSessionOutput_create"); stopOnWorker(); return false;
    }
    cameraStatus = ACaptureSessionOutputContainer_add(outputContainer_, sessionOutput_);
    if (cameraStatus != ACAMERA_OK) {
        setError(cameraStatus, "ACaptureSessionOutputContainer_add"); stopOnWorker(); return false;
    }

    {
        std::lock_guard<std::mutex> bridgeLock(callbackBridge_->mutex);
        callbackBridge_->lastClosedSession = nullptr;
    }
    ACameraCaptureSession_stateCallbacks sessionCallbacks{};
    sessionCallbacks.context = callbackBridge_.get();
    sessionCallbacks.onClosed = &CameraEngine::onSessionClosed;
    sessionCallbacks.onReady = &CameraEngine::onSessionReady;
    sessionCallbacks.onActive = &CameraEngine::onSessionActive;
    setStage("Конфигурация Camera2 session");
    cameraStatus = ACameraDevice_createCaptureSession(device_, outputContainer_, &sessionCallbacks, &session_);
    if (cameraStatus != ACAMERA_OK || !session_) {
        setError(cameraStatus, "ACameraDevice_createCaptureSession"); stopOnWorker(); return false;
    }

    LOGI("Camera2 session created on dedicated worker: %s (%dx%d); submitting the first preview request now",
         cameraId_.c_str(), width_.load(), height_.load());
    repeatingRequestStartAttempts_ = 0;
    nextRepeatingRequestAttempt_ = std::chrono::steady_clock::now();
    setStage("Сессия создана · запуск первого видеозапроса");
    return true;
}

void CameraEngine::tryStartRepeatingRequest() {
    if (!startPending_.load() || repeatingRequestSubmitted_ || !session_ || !request_) return;
    const auto now = std::chrono::steady_clock::now();
    if (nextRepeatingRequestAttempt_.time_since_epoch().count() != 0 && now < nextRepeatingRequestAttempt_) return;

    if (repeatingRequestStartAttempts_ == 0) {
        captureCallbacks_ = {};
        captureCallbacks_.context = callbackBridge_.get();
        captureCallbacks_.onCaptureCompleted = &CameraEngine::onCaptureCompleted;
        captureCallbacks_.onCaptureFailed = &CameraEngine::onCaptureFailed;
    }

    int sequenceId = -1;
    const camera_status_t status = ACameraCaptureSession_setRepeatingRequest(
        session_, &captureCallbacks_, 1, &request_, &sequenceId);
    if (status == ACAMERA_OK) {
        repeatingRequestSubmitted_ = true;
        repeatingStarted_.store(true);
        running_.store(true);
        startPending_.store(false);
        setStage("Видеопоток запущен · ожидается первый кадр");
        LOGI("Initial Camera2 repeating request accepted; sequence=%d attempts=%d",
             sequenceId, repeatingRequestStartAttempts_ + 1);
        return;
    }

    ++repeatingRequestStartAttempts_;
    if (repeatingRequestStartAttempts_ <= 3 || repeatingRequestStartAttempts_ % 10 == 0) {
        LOGW("Initial repeating request attempt %d failed with Camera2 status=%d; retrying while session remains valid",
             repeatingRequestStartAttempts_, status);
    }
    if (repeatingRequestStartAttempts_ >= 30) {
        setError(status, "ACameraCaptureSession_setRepeatingRequest after 30 attempts");
        running_.store(false);
        startPending_.store(false);
        return;
    }
    nextRepeatingRequestAttempt_ = now + std::chrono::milliseconds(200);
    setStage("Camera2 готовит видеопоток · попытка " + std::to_string(repeatingRequestStartAttempts_));
}

void CameraEngine::stopOnWorker() {
    const bool hadRepeatingRequest = repeatingRequestSubmitted_;
    repeatingRequestSubmitted_ = false;
    repeatingRequestStartAttempts_ = 0;
    nextRepeatingRequestAttempt_ = {};
    running_.store(false);
    sessionActive_.store(false);
    repeatingStarted_.store(false);

    if (sessionCloseTimedOut_) {
        bool closeArrived = false;
        {
            std::lock_guard<std::mutex> bridgeLock(callbackBridge_->mutex);
            closeArrived = callbackBridge_->lastClosedSession == pendingCloseSession_;
        }
        if (!closeArrived) return; // Keep Surface/resources alive until onClosed arrives.
        pendingCloseSession_ = nullptr;
        sessionCloseTimedOut_ = false;
    }

    // ImageReader callbacks run on a dedicated thread, not the Camera2 looper.
    // Stop accepting callbacks first, unregister the listener, and drain every
    // callback already in flight before destroying ImageReader or consumer_.
    if (reader_) {
        {
            std::lock_guard<std::mutex> callbackLock(imageCallbackMutex_);
            acceptImageCallbacks_ = false;
        }
        AImageReader_setImageListener(reader_, nullptr);
    }

    if (session_) {
        ACameraCaptureSession* closingSession = session_;
        bool closeAlreadyReported = false;
        {
            std::lock_guard<std::mutex> bridgeLock(callbackBridge_->mutex);
            closeAlreadyReported = callbackBridge_->lastClosedSession == closingSession;
        }
        // Do not keep owning a pointer after requesting close. The NDK declares
        // it invalid as soon as onClosed is delivered.
        session_ = nullptr;
        if (!closeAlreadyReported) {
            // Do not call stopRepeating/abortCaptures on an idle session which
            // never accepted a request. Besides being unnecessary, that can
            // produce a late onReady callback during a manual restart.
            if (hadRepeatingRequest) {
                const camera_status_t stopStatus = ACameraCaptureSession_stopRepeating(closingSession);
                if (stopStatus != ACAMERA_OK && stopStatus != ACAMERA_ERROR_SESSION_CLOSED) {
                    setError(stopStatus, "ACameraCaptureSession_stopRepeating");
                }
                const camera_status_t abortStatus = ACameraCaptureSession_abortCaptures(closingSession);
                if (abortStatus != ACAMERA_OK && abortStatus != ACAMERA_ERROR_SESSION_CLOSED) {
                    setError(abortStatus, "ACameraCaptureSession_abortCaptures");
                }
            }
            ACameraCaptureSession_close(closingSession);

            // Wait for onClosed before releasing the ImageReader Surface and
            // request/output resources. Polling also dispatches callbacks if
            // Android associated them with this worker's ALooper.
            const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
            bool closed = false;
            while (std::chrono::steady_clock::now() < deadline) {
                {
                    std::lock_guard<std::mutex> bridgeLock(callbackBridge_->mutex);
                    closed = callbackBridge_->lastClosedSession == closingSession;
                }
                if (closed) break;
                int events = 0;
                void* data = nullptr;
                ALooper_pollOnce(20, nullptr, &events, &data);
                std::unique_lock<std::mutex> bridgeLock(callbackBridge_->mutex);
                callbackBridge_->cv.wait_for(bridgeLock, std::chrono::milliseconds(10), [&] {
                    return callbackBridge_->lastClosedSession == closingSession || callbackBridge_->owner == nullptr;
                });
            }
            if (!closed) {
                std::lock_guard<std::mutex> bridgeLock(callbackBridge_->mutex);
                closed = callbackBridge_->lastClosedSession == closingSession;
            }
            if (!closed) {
                LOGE("Timed out waiting for Camera2 onClosed; retaining Surface/resources until callback arrives");
                pendingCloseSession_ = closingSession;
                sessionCloseTimedOut_ = true;
                return;
            }
        }
    }
    if (request_) { ACaptureRequest_free(request_); request_ = nullptr; }
    if (outputContainer_) {
        if (sessionOutput_) ACaptureSessionOutputContainer_remove(outputContainer_, sessionOutput_);
        ACaptureSessionOutputContainer_free(outputContainer_);
        outputContainer_ = nullptr;
    }
    if (sessionOutput_) { ACaptureSessionOutput_free(sessionOutput_); sessionOutput_ = nullptr; }
    if (target_) { ACameraOutputTarget_free(target_); target_ = nullptr; }
    if (device_) { ACameraDevice_close(device_); device_ = nullptr; }

    if (reader_) {
        {
            std::unique_lock<std::mutex> callbackLock(imageCallbackMutex_);
            imageCallbackCv_.wait(callbackLock, [this] { return activeImageCallbacks_ == 0; });
        }
        AImageReader_delete(reader_);
        reader_ = nullptr;
        readerWindow_ = nullptr;
    }
    if (manager_) { ACameraManager_delete(manager_); manager_ = nullptr; }
    cameraId_.clear();
    consumer_ = nullptr;
    torchEnabled_.store(false);
    torchPending_.store(false);
    flashAvailable_.store(false);
    setStage("Камера остановлена");
}

void CameraEngine::setTorchOnWorker(bool enabled) {
    if (!running_.load() || !repeatingStarted_.load() || !request_ || !session_ || !flashAvailable_.load()) {
        torchPending_.store(false);
        setError(ACAMERA_ERROR_INVALID_OPERATION, "Torch command rejected: preview/flash is not ready");
        return;
    }
    const uint8_t controlMode = ACAMERA_CONTROL_MODE_AUTO;
    const uint8_t aeMode = ACAMERA_CONTROL_AE_MODE_ON;
    const uint8_t flashMode = enabled ? ACAMERA_FLASH_MODE_TORCH : ACAMERA_FLASH_MODE_OFF;
    camera_status_t status = ACaptureRequest_setEntry_u8(request_, ACAMERA_CONTROL_MODE, 1, &controlMode);
    if (status == ACAMERA_OK) status = ACaptureRequest_setEntry_u8(request_, ACAMERA_CONTROL_AE_MODE, 1, &aeMode);
    if (status == ACAMERA_OK) status = ACaptureRequest_setEntry_u8(request_, ACAMERA_FLASH_MODE, 1, &flashMode);
    int sequenceId = -1;
    if (status == ACAMERA_OK) {
        status = ACameraCaptureSession_setRepeatingRequest(
            session_, &captureCallbacks_, 1, &request_, &sequenceId);
    }
    torchPending_.store(false);
    if (status == ACAMERA_OK) {
        torchEnabled_.store(enabled);
        setStage(enabled ? "Команда фонарика принята · проверка по capture metadata" : "Команда выключения фонарика принята");
        LOGI("Torch %s accepted by Camera2 repeating request, sequence=%d; AE_MODE_ON + FLASH_MODE_TORCH/OFF",
             enabled ? "ON" : "OFF", sequenceId);
    } else {
        torchEnabled_.store(false);
        setError(status, enabled ? "Enable camera torch" : "Disable camera torch");
    }
}

void CameraEngine::onImageAvailable(void* context, AImageReader* reader) {
    auto* bridge = static_cast<CameraCallbackBridge*>(context);
    if (!bridge || !reader) return;
    CameraEngine* self = nullptr;
    {
        std::lock_guard<std::mutex> bridgeLock(bridge->mutex);
        self = bridge->owner;
        if (!self) return;
        ++bridge->callbacksInFlight;
    }

    bool accepted = false;
    {
        std::lock_guard<std::mutex> callbackLock(self->imageCallbackMutex_);
        if (self->acceptImageCallbacks_) {
            ++self->activeImageCallbacks_;
            accepted = true;
        }
    }
    if (accepted) {
        const uint64_t callbackNumber = self->imageCallbackCount_.fetch_add(1) + 1;
        if (callbackNumber == 1) LOGI("AImageReader first onImageAvailable callback received");
        self->consumeLatestImage(reader);
        std::lock_guard<std::mutex> callbackLock(self->imageCallbackMutex_);
        if (self->activeImageCallbacks_ > 0) --self->activeImageCallbacks_;
        if (self->activeImageCallbacks_ == 0) self->imageCallbackCv_.notify_all();
    }

    {
        std::lock_guard<std::mutex> bridgeLock(bridge->mutex);
        if (bridge->callbacksInFlight > 0) --bridge->callbacksInFlight;
        if (bridge->callbacksInFlight == 0) bridge->cv.notify_all();
    }
}

void CameraEngine::consumeLatestImage(AImageReader* reader) {
    // Camera2 state callbacks only enqueue worker commands. Image callbacks run
    // on AImageReader's dedicated thread and use the callback gate above. UI
    // operations never hold a camera lifecycle lock.
    if (!running_.load() || !reader) return;

    AImage* image = nullptr;
    const media_status_t acquireStatus = AImageReader_acquireLatestImage(reader, &image);
    if (acquireStatus != AMEDIA_OK || !image) {
        const int previous = lastImageAcquireStatus_.exchange(acquireStatus);
        if (previous != acquireStatus) LOGE("AImageReader_acquireLatestImage failed: media status=%d", acquireStatus);
        return;
    }
    lastImageAcquireStatus_.store(AMEDIA_OK);

    int32_t width = 0, height = 0;
    AImage_getWidth(image, &width);
    AImage_getHeight(image, &height);
    uint8_t *planeY = nullptr, *planeU = nullptr, *planeV = nullptr;
    int lenY = 0, lenU = 0, lenV = 0;
    int rowY = 0, rowU = 0, rowV = 0;
    int pixelY = 0, pixelU = 0, pixelV = 0;
    const bool ok =
        AImage_getPlaneData(image, 0, &planeY, &lenY) == AMEDIA_OK &&
        AImage_getPlaneData(image, 1, &planeU, &lenU) == AMEDIA_OK &&
        AImage_getPlaneData(image, 2, &planeV, &lenV) == AMEDIA_OK &&
        AImage_getPlaneRowStride(image, 0, &rowY) == AMEDIA_OK &&
        AImage_getPlaneRowStride(image, 1, &rowU) == AMEDIA_OK &&
        AImage_getPlaneRowStride(image, 2, &rowV) == AMEDIA_OK &&
        AImage_getPlanePixelStride(image, 0, &pixelY) == AMEDIA_OK &&
        AImage_getPlanePixelStride(image, 1, &pixelU) == AMEDIA_OK &&
        AImage_getPlanePixelStride(image, 2, &pixelV) == AMEDIA_OK &&
        planeY && planeU && planeV && lenY > 0 && lenU > 0 && lenV > 0 &&
        rowY > 0 && rowU > 0 && rowV > 0 && pixelY > 0 && pixelU > 0 && pixelV > 0;

    if (ok && width > 0 && height > 0) {
        std::vector<uint8_t> rgba(static_cast<size_t>(width) * static_cast<size_t>(height) * 4U, 0);
        bool boundsValid = true;
        for (int y = 0; y < height && boundsValid; ++y) {
            const int uvY = y / 2;
            for (int x = 0; x < width; ++x) {
                const int yIndex = y * rowY + x * pixelY;
                const int uIndex = uvY * rowU + (x / 2) * pixelU;
                const int vIndex = uvY * rowV + (x / 2) * pixelV;
                if (yIndex < 0 || uIndex < 0 || vIndex < 0 || yIndex >= lenY || uIndex >= lenU || vIndex >= lenV) {
                    boundsValid = false; break;
                }
                const int yy = std::max(0, static_cast<int>(planeY[yIndex]) - 16);
                const int uu = static_cast<int>(planeU[uIndex]) - 128;
                const int vv = static_cast<int>(planeV[vIndex]) - 128;
                const int c = 298 * yy;
                const size_t index = (static_cast<size_t>(y) * static_cast<size_t>(width) + static_cast<size_t>(x)) * 4U;
                rgba[index + 0] = clampByte((c + 409 * vv + 128) >> 8);
                rgba[index + 1] = clampByte((c - 100 * uu - 208 * vv + 128) >> 8);
                rgba[index + 2] = clampByte((c + 516 * uu + 128) >> 8);
                rgba[index + 3] = 255;
            }
        }
        if (boundsValid && consumer_) {
            const uint64_t currentFrame = frameCount_.fetch_add(1) + 1;
            if (currentFrame == 1) LOGI("First YUV frame converted successfully: %dx%d (Y row=%d pixel=%d, U row=%d pixel=%d, V row=%d pixel=%d)",
                width, height, rowY, pixelY, rowU, pixelU, rowV, pixelV);
            consumer_(std::move(rgba), width, height);
        } else if (!boundsValid) {
            LOGE("AImage plane bounds mismatch; frame skipped. size=%dx%d lengths=%d/%d/%d rows=%d/%d/%d pixels=%d/%d/%d",
                 width, height, lenY, lenU, lenV, rowY, rowU, rowV, pixelY, pixelU, pixelV);
        }
    }
    AImage_delete(image);
}

void CameraEngine::onCameraDisconnected(void* context, ACameraDevice* device) {
    LOGE("Camera2 device disconnected callback received");
    auto* bridge = static_cast<CameraCallbackBridge*>(context);
    if (!bridge) return;
    std::lock_guard<std::mutex> lock(bridge->mutex);
    if (!bridge->owner) return;
    Command command{};
    command.type = CommandType::DeviceDisconnected;
    command.device = device;
    command.errorCode = ACAMERA_ERROR_CAMERA_DISCONNECTED;
    bridge->owner->enqueue(std::move(command));
}

void CameraEngine::onCameraError(void* context, ACameraDevice* device, int error) {
    LOGE("Camera2 device error callback: code=%d", error);
    auto* bridge = static_cast<CameraCallbackBridge*>(context);
    if (!bridge) return;
    std::lock_guard<std::mutex> lock(bridge->mutex);
    if (!bridge->owner) return;
    Command command{};
    command.type = CommandType::DeviceError;
    command.device = device;
    command.errorCode = error;
    bridge->owner->enqueue(std::move(command));
}

void CameraEngine::onSessionClosed(void* context, ACameraCaptureSession* session) {
    auto* bridge = static_cast<CameraCallbackBridge*>(context);
    if (!bridge) return;
    std::lock_guard<std::mutex> lock(bridge->mutex);
    if (!bridge->owner) return;
    bridge->lastClosedSession = session;
    bridge->cv.notify_all();
    Command command{};
    command.type = CommandType::SessionClosed;
    command.session = session;
    bridge->owner->enqueue(std::move(command));
}

void CameraEngine::onSessionReady(void* context, ACameraCaptureSession* session) {
    LOGI("Camera2 onReady callback received");
    auto* bridge = static_cast<CameraCallbackBridge*>(context);
    if (!bridge) return;
    std::lock_guard<std::mutex> lock(bridge->mutex);
    if (!bridge->owner) return;
    Command command{};
    command.type = CommandType::SessionReady;
    command.session = session;
    bridge->owner->enqueue(std::move(command));
}


void CameraEngine::onCaptureCompleted(void* context, ACameraCaptureSession*,
                                      ACaptureRequest*, const ACameraMetadata* result) {
    auto* bridge = static_cast<CameraCallbackBridge*>(context);
    if (!bridge || !result) return;
    CameraEngine* self = nullptr;
    {
        std::lock_guard<std::mutex> lock(bridge->mutex);
        self = bridge->owner;
        if (!self) return;
        ++bridge->callbacksInFlight;
    }
    const uint64_t resultNumber = self->captureResultCount_.fetch_add(1) + 1;
    ACameraMetadata_const_entry flash{};
    if (ACameraMetadata_getConstEntry(result, ACAMERA_FLASH_STATE, &flash) == ACAMERA_OK && flash.count > 0) {
        const int flashState = static_cast<int>(flash.data.u8[0]);
        const int previous = self->lastFlashState_.exchange(flashState);
        if (previous != flashState) {
            LOGI("Capture metadata flash state changed: %s (%d) -> %s (%d), result #%llu",
                 flashStateName(previous), previous, flashStateName(flashState), flashState,
                 static_cast<unsigned long long>(resultNumber));
        }
    } else if (!self->firstCaptureResultLogged_.exchange(true)) {
        LOGW("Capture result arrived but ACAMERA_FLASH_STATE metadata is absent (common on some LEGACY camera devices)");
    }
    if (resultNumber == 1) LOGI("First Camera2 capture result received; repeating stream is producing frames");
    {
        std::lock_guard<std::mutex> lock(bridge->mutex);
        if (bridge->callbacksInFlight > 0) --bridge->callbacksInFlight;
        if (bridge->callbacksInFlight == 0) bridge->cv.notify_all();
    }
}

void CameraEngine::onCaptureFailed(void* context, ACameraCaptureSession*,
                                   ACaptureRequest*, ACameraCaptureFailure*) {
    auto* bridge = static_cast<CameraCallbackBridge*>(context);
    if (!bridge) return;
    CameraEngine* self = nullptr;
    {
        std::lock_guard<std::mutex> lock(bridge->mutex);
        self = bridge->owner;
        if (!self) return;
        ++bridge->callbacksInFlight;
    }
    const uint64_t failures = self->captureFailureCount_.fetch_add(1) + 1;
    if (failures <= 5 || failures % 30 == 0) {
        LOGE("Camera2 capture failed (failure #%llu); capture stream may not deliver a frame",
             static_cast<unsigned long long>(failures));
    }
    {
        std::lock_guard<std::mutex> lock(bridge->mutex);
        if (bridge->callbacksInFlight > 0) --bridge->callbacksInFlight;
        if (bridge->callbacksInFlight == 0) bridge->cv.notify_all();
    }
}

void CameraEngine::onSessionActive(void* context, ACameraCaptureSession* session) {
    LOGI("Camera2 onActive callback received");
    auto* bridge = static_cast<CameraCallbackBridge*>(context);
    if (!bridge) return;
    std::lock_guard<std::mutex> lock(bridge->mutex);
    if (!bridge->owner) return;
    Command command{};
    command.type = CommandType::SessionActive;
    command.session = session;
    bridge->owner->enqueue(std::move(command));
}
