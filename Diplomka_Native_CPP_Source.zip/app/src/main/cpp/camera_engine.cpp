#include "camera_engine.h"

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <limits>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

#include <android/log.h>
#include <camera/NdkCameraDevice.h>
#include <camera/NdkCameraMetadata.h>
#include <camera/NdkCameraMetadataTags.h>
#include <camera/NdkCaptureRequest.h>
#include <media/NdkImage.h>

#define LOG_TAG "DiplomkaNative-Camera"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
inline uint8_t clampByte(int value) {
    return static_cast<uint8_t>(std::max(0, std::min(255, value)));
}
}

CameraEngine::~CameraEngine() {
    stop();
}

void CameraEngine::setError(int errorCode, const char* operation) {
    lastErrorCode_.store(errorCode);
    LOGE("%s failed with code %d", operation ? operation : "Camera operation", errorCode);
}

bool CameraEngine::chooseBackCamera() {
    if (!manager_) return false;
    ACameraIdList* ids = nullptr;
    const camera_status_t status = ACameraManager_getCameraIdList(manager_, &ids);
    if (status != ACAMERA_OK || ids == nullptr) {
        setError(status, "ACameraManager_getCameraIdList");
        return false;
    }

    std::string selectedId;
    int selectedWidth = 0;
    int selectedHeight = 0;
    bool selectedHasFlash = false;
    for (int i = 0; i < ids->numCameras; ++i) {
        ACameraMetadata* metadata = nullptr;
        if (ACameraManager_getCameraCharacteristics(manager_, ids->cameraIds[i], &metadata) != ACAMERA_OK || !metadata) {
            continue;
        }

        ACameraMetadata_const_entry facing{};
        const bool hasFacing = ACameraMetadata_getConstEntry(metadata, ACAMERA_LENS_FACING, &facing) == ACAMERA_OK;
        const bool isBack = hasFacing && facing.count > 0 && facing.data.u8[0] == ACAMERA_LENS_FACING_BACK;

        // Do not assume every camera supports 640x480 YUV. Select a size the
        // device explicitly advertises for AImageReader before creating a session.
        int candidateWidth = 0;
        int candidateHeight = 0;
        ACameraMetadata_const_entry streams{};
        if (ACameraMetadata_getConstEntry(metadata, ACAMERA_SCALER_AVAILABLE_STREAM_CONFIGURATIONS, &streams) == ACAMERA_OK &&
            streams.count >= 4) {
            int bestScore = std::numeric_limits<int>::max();
            for (uint32_t j = 0; j + 3 < streams.count; j += 4) {
                const int32_t format = streams.data.i32[j + 0];
                const int32_t width = streams.data.i32[j + 1];
                const int32_t height = streams.data.i32[j + 2];
                const int32_t input = streams.data.i32[j + 3];
                if (format != AIMAGE_FORMAT_YUV_420_888 ||
                    input != ACAMERA_SCALER_AVAILABLE_STREAM_CONFIGURATIONS_OUTPUT ||
                    width < 320 || height < 240) {
                    continue;
                }
                const int oversizePenalty = std::max(0, width - 1280) * 3 + std::max(0, height - 720) * 3;
                const int score = std::abs(width - 640) + std::abs(height - 480) + oversizePenalty;
                if (score < bestScore) {
                    bestScore = score;
                    candidateWidth = width;
                    candidateHeight = height;
                }
            }
        }

        ACameraMetadata_const_entry flash{};
        const bool hasFlash = ACameraMetadata_getConstEntry(metadata, ACAMERA_FLASH_INFO_AVAILABLE, &flash) == ACAMERA_OK &&
                              flash.count > 0 && flash.data.u8[0] != 0;

        if (candidateWidth > 0 && candidateHeight > 0 && (selectedId.empty() || isBack)) {
            selectedId = ids->cameraIds[i];
            selectedWidth = candidateWidth;
            selectedHeight = candidateHeight;
            selectedHasFlash = hasFlash;
        }
        ACameraMetadata_free(metadata);
        if (isBack && !selectedId.empty() && selectedId == ids->cameraIds[i]) break;
    }
    ACameraManager_deleteCameraIdList(ids);

    cameraId_ = std::move(selectedId);
    if (cameraId_.empty()) {
        setError(ACAMERA_ERROR_INVALID_PARAMETER, "No camera with YUV_420_888 output stream");
        return false;
    }
    width_ = selectedWidth;
    height_ = selectedHeight;
    flashAvailable_.store(selectedHasFlash);
    LOGI("Selected camera id: %s, stream: %dx%d, flash: %s", cameraId_.c_str(), width_, height_, selectedHasFlash ? "yes" : "no");
    return true;
}

bool CameraEngine::start(FrameConsumer consumer) {
    if (running_.load()) return true;
    if (manager_ || device_ || session_ || reader_ || request_ || outputContainer_ || sessionOutput_ || target_) stop();

    {
        std::lock_guard<std::mutex> lock(consumerMutex_);
        consumer_ = std::move(consumer);
    }
    lastErrorCode_.store(0);
    frameCount_.store(0);
    sessionActive_.store(false);
    repeatingStarted_.store(false);
    flashAvailable_.store(false);
    torchEnabled_ = false;

    manager_ = ACameraManager_create();
    if (!manager_ || !chooseBackCamera()) {
        if (!lastErrorCode_.load()) setError(ACAMERA_ERROR_CAMERA_DEVICE, "No camera available");
        stop();
        return false;
    }

    const media_status_t mediaStatus = AImageReader_new(width_, height_, AIMAGE_FORMAT_YUV_420_888, 4, &reader_);
    if (mediaStatus != AMEDIA_OK || !reader_) {
        setError(mediaStatus, "AImageReader_new");
        stop();
        return false;
    }

    AImageReader_ImageListener listener{};
    listener.context = this;
    listener.onImageAvailable = &CameraEngine::onImageAvailable;
    AImageReader_setImageListener(reader_, &listener);
    const media_status_t windowStatus = AImageReader_getWindow(reader_, &readerWindow_);
    if (windowStatus != AMEDIA_OK || !readerWindow_) {
        setError(windowStatus, "AImageReader_getWindow");
        stop();
        return false;
    }

    ACameraDevice_StateCallbacks deviceCallbacks{};
    deviceCallbacks.context = this;
    deviceCallbacks.onDisconnected = &CameraEngine::onCameraDisconnected;
    deviceCallbacks.onError = &CameraEngine::onCameraError;

    camera_status_t cameraStatus = ACameraManager_openCamera(manager_, cameraId_.c_str(), &deviceCallbacks, &device_);
    if (cameraStatus != ACAMERA_OK || !device_) {
        setError(cameraStatus, "ACameraManager_openCamera");
        stop();
        return false;
    }

    cameraStatus = ACameraOutputTarget_create(readerWindow_, &target_);
    if (cameraStatus != ACAMERA_OK || !target_) {
        setError(cameraStatus, "ACameraOutputTarget_create");
        stop();
        return false;
    }

    cameraStatus = ACameraDevice_createCaptureRequest(device_, TEMPLATE_PREVIEW, &request_);
    if (cameraStatus != ACAMERA_OK || !request_) {
        setError(cameraStatus, "ACameraDevice_createCaptureRequest");
        stop();
        return false;
    }

    if (ACaptureRequest_addTarget(request_, target_) != ACAMERA_OK) {
        setError(ACAMERA_ERROR_INVALID_PARAMETER, "ACaptureRequest_addTarget");
        stop();
        return false;
    }

    // Ask Camera2 for continuous autofocus and auto exposure when supported.
    const uint8_t aeMode = ACAMERA_CONTROL_AE_MODE_ON;
    ACaptureRequest_setEntry_u8(request_, ACAMERA_CONTROL_AE_MODE, 1, &aeMode);
    const uint8_t afMode = ACAMERA_CONTROL_AF_MODE_CONTINUOUS_PICTURE;
    ACaptureRequest_setEntry_u8(request_, ACAMERA_CONTROL_AF_MODE, 1, &afMode);

    cameraStatus = ACaptureSessionOutputContainer_create(&outputContainer_);
    if (cameraStatus != ACAMERA_OK || !outputContainer_) {
        setError(cameraStatus, "ACaptureSessionOutputContainer_create");
        stop();
        return false;
    }
    cameraStatus = ACaptureSessionOutput_create(readerWindow_, &sessionOutput_);
    if (cameraStatus != ACAMERA_OK || !sessionOutput_) {
        setError(cameraStatus, "ACaptureSessionOutput_create");
        stop();
        return false;
    }
    cameraStatus = ACaptureSessionOutputContainer_add(outputContainer_, sessionOutput_);
    if (cameraStatus != ACAMERA_OK) {
        setError(cameraStatus, "ACaptureSessionOutputContainer_add");
        stop();
        return false;
    }

    ACameraCaptureSession_stateCallbacks sessionCallbacks{};
    sessionCallbacks.context = this;
    sessionCallbacks.onClosed = &CameraEngine::onSessionClosed;
    sessionCallbacks.onReady = &CameraEngine::onSessionReady;
    sessionCallbacks.onActive = &CameraEngine::onSessionActive;

    cameraStatus = ACameraDevice_createCaptureSession(device_, outputContainer_, &sessionCallbacks, &session_);
    if (cameraStatus != ACAMERA_OK || !session_) {
        setError(cameraStatus, "ACameraDevice_createCaptureSession");
        stop();
        return false;
    }

    // ACameraDevice_createCaptureSession is asynchronous. Do not submit a
    // repeating request until onReady confirms that the session is configured.
    // Starting too early can return an error on some vendor camera HALs.
    running_.store(true); // lifecycle is active; frames are confirmed separately.
    LOGI("Camera session requested: %s (%dx%d); waiting for onReady", cameraId_.c_str(), width_, height_);
    return true;
}

void CameraEngine::stop() {
    std::lock_guard<std::mutex> lifecycleLock(lifecycleMutex_);
    running_.store(false);
    sessionActive_.store(false);
    repeatingStarted_.store(false);
    if (session_) {
        if (request_) ACameraCaptureSession_stopRepeating(session_);
        ACameraCaptureSession_abortCaptures(session_);
        ACameraCaptureSession_close(session_);
        session_ = nullptr;
    }
    if (request_) {
        ACaptureRequest_free(request_);
        request_ = nullptr;
    }
    if (outputContainer_) {
        if (sessionOutput_) ACaptureSessionOutputContainer_remove(outputContainer_, sessionOutput_);
        ACaptureSessionOutputContainer_free(outputContainer_);
        outputContainer_ = nullptr;
    }
    if (sessionOutput_) {
        ACaptureSessionOutput_free(sessionOutput_);
        sessionOutput_ = nullptr;
    }
    if (target_) {
        ACameraOutputTarget_free(target_);
        target_ = nullptr;
    }
    if (device_) {
        ACameraDevice_close(device_);
        device_ = nullptr;
    }
    if (reader_) {
        AImageReader_setImageListener(reader_, nullptr);
        AImageReader_delete(reader_);
        reader_ = nullptr;
        readerWindow_ = nullptr;
    }
    if (manager_) {
        ACameraManager_delete(manager_);
        manager_ = nullptr;
    }
    cameraId_.clear();
    torchEnabled_ = false;
    flashAvailable_.store(false);
    std::lock_guard<std::mutex> lock(consumerMutex_);
    consumer_ = nullptr;
}

bool CameraEngine::setTorch(bool enabled) {
    if (!running_.load() || !repeatingStarted_.load() || !request_ || !session_ || !flashAvailable_.load()) return false;
    const uint8_t mode = enabled ? ACAMERA_FLASH_MODE_TORCH : ACAMERA_FLASH_MODE_OFF;
    const camera_status_t status = ACaptureRequest_setEntry_u8(request_, ACAMERA_FLASH_MODE, 1, &mode);
    if (status != ACAMERA_OK) {
        setError(status, "ACaptureRequest_setEntry_u8(FLASH_MODE)");
        return false;
    }
    const camera_status_t requestStatus = ACameraCaptureSession_setRepeatingRequest(session_, nullptr, 1, &request_, nullptr);
    if (requestStatus == ACAMERA_OK) torchEnabled_ = enabled;
    else setError(requestStatus, "ACameraCaptureSession_setRepeatingRequest(torch)");
    return requestStatus == ACAMERA_OK;
}

void CameraEngine::onImageAvailable(void* context, AImageReader* reader) {
    auto* self = static_cast<CameraEngine*>(context);
    if (self) self->consumeLatestImage(reader);
}

void CameraEngine::consumeLatestImage(AImageReader* reader) {
    std::lock_guard<std::mutex> lifecycleLock(lifecycleMutex_);
    if (!running_.load() || !reader || reader != reader_) return;

    AImage* image = nullptr;
    const media_status_t acquireStatus = AImageReader_acquireLatestImage(reader, &image);
    if (acquireStatus != AMEDIA_OK || !image) return;

    int32_t width = 0;
    int32_t height = 0;
    AImage_getWidth(image, &width);
    AImage_getHeight(image, &height);

    uint8_t* planeY = nullptr;
    uint8_t* planeU = nullptr;
    uint8_t* planeV = nullptr;
    int lenY = 0, lenU = 0, lenV = 0;
    int rowY = 0, rowU = 0, rowV = 0;
    int pixelY = 0, pixelU = 0, pixelV = 0;
    const bool ok =
        AImage_getPlaneData(image, 0, &planeY, &lenY) == AMEDIA_OK &&
        AImage_getPlaneData(image, 1, &planeU, &lenU) == AMEDIA_OK &&
        AImage_getPlaneData(image, 2, &planeV, &lenV) == AMEDIA_OK &&
        AImage_getPlaneRowStride(image, 0, &rowY) == AMEDIA_OK &&
        AImage_getPlaneRowStride(image, 1, &rowU) == AMEDIA_OK &&
        AImage_getPlaneRowStride(image, 2, &rowV) == AMEDIA_OK &&
        AImage_getPlanePixelStride(image, 0, &pixelY) == AMEDIA_OK &&
        AImage_getPlanePixelStride(image, 1, &pixelU) == AMEDIA_OK &&
        AImage_getPlanePixelStride(image, 2, &pixelV) == AMEDIA_OK &&
        planeY && planeU && planeV && lenY > 0 && lenU > 0 && lenV > 0 &&
        rowY > 0 && rowU > 0 && rowV > 0 && pixelY > 0 && pixelU > 0 && pixelV > 0;

    if (ok && width > 0 && height > 0) {
        std::vector<uint8_t> rgba(static_cast<size_t>(width) * static_cast<size_t>(height) * 4U, 0);
        bool boundsValid = true;
        for (int y = 0; y < height && boundsValid; ++y) {
            const int uvY = y / 2;
            for (int x = 0; x < width; ++x) {
                const int yIndex = y * rowY + x * pixelY;
                const int uIndex = uvY * rowU + (x / 2) * pixelU;
                const int vIndex = uvY * rowV + (x / 2) * pixelV;
                if (yIndex < 0 || uIndex < 0 || vIndex < 0 || yIndex >= lenY || uIndex >= lenU || vIndex >= lenV) {
                    boundsValid = false;
                    break;
                }
                const int yy = std::max(0, static_cast<int>(planeY[yIndex]) - 16);
                const int uu = static_cast<int>(planeU[uIndex]) - 128;
                const int vv = static_cast<int>(planeV[vIndex]) - 128;
                const int c = 298 * yy;
                const size_t index = (static_cast<size_t>(y) * static_cast<size_t>(width) + static_cast<size_t>(x)) * 4U;
                rgba[index + 0] = clampByte((c + 409 * vv + 128) >> 8);
                rgba[index + 1] = clampByte((c - 100 * uu - 208 * vv + 128) >> 8);
                rgba[index + 2] = clampByte((c + 516 * uu + 128) >> 8);
                rgba[index + 3] = 255;
            }
        }

        if (boundsValid) {
            FrameConsumer callback;
            {
                std::lock_guard<std::mutex> lock(consumerMutex_);
                callback = consumer_;
            }
            if (callback) {
                frameCount_.fetch_add(1);
                callback(std::move(rgba), width, height);
            }
        } else {
            LOGE("AImage plane length/stride mismatch; frame skipped");
        }
    }
    AImage_delete(image);
}

void CameraEngine::onCameraDisconnected(void* context, ACameraDevice*) {
    auto* self = static_cast<CameraEngine*>(context);
    if (!self) return;
    self->setError(ACAMERA_ERROR_CAMERA_DISCONNECTED, "Camera disconnected");
    self->running_.store(false);
    self->sessionActive_.store(false);
}

void CameraEngine::onCameraError(void* context, ACameraDevice*, int error) {
    auto* self = static_cast<CameraEngine*>(context);
    if (!self) return;
    self->setError(error, "Camera device callback");
    self->running_.store(false);
    self->sessionActive_.store(false);
}

void CameraEngine::onSessionClosed(void* context, ACameraCaptureSession* session) {
    auto* self = static_cast<CameraEngine*>(context);
    if (self && self->session_ == session && self->running_.load()) {
        self->running_.store(false);
        self->sessionActive_.store(false);
    }
}

void CameraEngine::onSessionReady(void* context, ACameraCaptureSession* session) {
    auto* self = static_cast<CameraEngine*>(context);
    if (!self) return;
    std::lock_guard<std::mutex> lock(self->lifecycleMutex_);
    if (self->session_ != session || !self->request_ || self->repeatingStarted_.load()) return;
    const camera_status_t status = ACameraCaptureSession_setRepeatingRequest(session, nullptr, 1, &self->request_, nullptr);
    if (status == ACAMERA_OK) {
        self->repeatingStarted_.store(true);
        self->running_.store(true);
        LOGI("Camera repeating request started from onReady");
    } else {
        self->setError(status, "ACameraCaptureSession_setRepeatingRequest");
        self->running_.store(false);
    }
}

void CameraEngine::onSessionActive(void* context, ACameraCaptureSession* session) {
    auto* self = static_cast<CameraEngine*>(context);
    if (!self) return;
    std::lock_guard<std::mutex> lock(self->lifecycleMutex_);
    if (self->session_ == session) self->sessionActive_.store(true);
}
