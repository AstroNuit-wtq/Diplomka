#include "vision_engine.h"
#include <chrono>
#include <utility>
#include <cstring>
#if defined(__ANDROID__)
#include <android/asset_manager.h>
#include <android/log.h>
#include "session_logger.h"
#define LOG_TAG "Diplomka-ClassicalVision"
#define LOGI(...) appLogWrite(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) appLogWrite(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) do { std::fprintf(stdout, __VA_ARGS__); std::fputc('\n', stdout); } while (0)
#define LOGW(...) do { std::fprintf(stderr, __VA_ARGS__); std::fputc('\n', stderr); } while (0)
#endif

namespace {
#if defined(__ANDROID__)
std::vector<uint8_t> readAsset(AAssetManager* manager, const char* name) {
    std::vector<uint8_t> bytes;
    if (!manager) return bytes;
    AAsset* asset = AAssetManager_open(manager, name, AASSET_MODE_BUFFER);
    if (!asset) return bytes;
    const off_t length = AAsset_getLength(asset);
    if (length > 0) {
        bytes.resize(static_cast<size_t>(length));
        const int read = AAsset_read(asset, bytes.data(), bytes.size());
        if (read < 0) bytes.clear(); else bytes.resize(static_cast<size_t>(read));
    }
    AAsset_close(asset);
    return bytes;
}
#endif
}

bool VisionEngine::initialize(AAssetManager* assets) {
#if defined(__ANDROID__)
    const auto mapBytes = readAsset(assets, "map.jpg");
    const auto routeBytes = readAsset(assets, "route.csv");
    const std::string routeText(routeBytes.begin(), routeBytes.end());
    std::string error;
    const bool mapReady = engine_.loadMapBytes(mapBytes, routeText, error);
    if (!mapReady) LOGW("Map/route not loaded: %s", error.c_str());
    else LOGI("Classical route/map loaded from APK assets");
    initialized_ = true; // vision works even when no optional route asset is supplied
    return initialized_;
#else
    (void)assets;
    initialized_ = true;
    return true;
#endif
}

VisionFrame VisionEngine::processRgba(const uint8_t* rgba, int width, int height,
                                      bool enabled, bool runPoseThisFrame) {
    (void)runPoseThisFrame;
    VisionFrame out;
    out.frameWidth = width;
    out.frameHeight = height;
    out.detectorReady = initialized_;
    out.poseReady = false;
    if (!initialized_ || !enabled || !rgba || width <= 0 || height <= 0) return out;
    const auto start = std::chrono::steady_clock::now();
    std::vector<uint8_t> pixels(rgba, rgba + static_cast<size_t>(width) * height * 4);
    const PiVisionResult result = engine_.processRgba(pixels, width, height);
    const float scaleX = width > 800 ? static_cast<float>(width) / 800.0f : 1.0f;
    const float scaleY = width > 800 ? static_cast<float>(height) / 600.0f : 1.0f;
    out.detections.reserve(result.detections.size());
    for (const auto& item : result.detections) {
        Detection detection;
        detection.label = item.label;
        detection.confidence = item.confidence;
        detection.classId = item.isPerson ? 0 : (item.isVehicleCandidate ? 2 : -1);
        detection.possibleStatue = item.isVehicleCandidate;
        detection.box = {static_cast<float>(item.box.x) * scaleX, static_cast<float>(item.box.y) * scaleY,
                         static_cast<float>(item.box.x + item.box.width) * scaleX,
                         static_cast<float>(item.box.y + item.box.height) * scaleY};
        out.detections.push_back(std::move(detection));
    }
    out.stopSignal = result.stopSignal;
    out.hasTarget = result.hasTarget;
    out.targetX = static_cast<float>(result.target.x) * scaleX;
    out.targetY = static_cast<float>(result.target.y) * scaleY;
    out.bypassSelected = result.bypassSelected;
    out.direction = result.direction;
    out.stopReason = result.stopReason;
    out.weather = result.weather;
    out.mapStatus = result.mapStatus;
    out.nearestWaypointId = result.nearestWaypointId;
    out.mapLocalized = result.mapLocalized;
    out.opticalFlowPixelsPerSecond = result.opticalFlowPixelsPerSecond;
    out.travelledPixels = result.travelledPixels;
    out.inferenceMs = std::chrono::duration<float, std::milli>(
        std::chrono::steady_clock::now() - start).count();
    return out;
}
