#include "vision_engine.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstring>
#include <limits>
#include <utility>
#include <thread>

#if defined(__ANDROID__)
#include <android/log.h>
#include "session_logger.h"
#define LOG_TAG "DiplomkaNative-Vision"
#define LOGI(...) appLogWrite(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) appLogWrite(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) do { std::fprintf(stdout, __VA_ARGS__); std::fputc('\n', stdout); } while (0)
#define LOGW(...) do { std::fprintf(stderr, __VA_ARGS__); std::fputc('\n', stderr); } while (0)
#endif

namespace {
constexpr int kInputSize = 640;
constexpr float kObjectThreshold = 0.34f;
constexpr float kPoseThreshold = 0.38f;
constexpr float kNmsThreshold = 0.50f;
constexpr int kRegMax = 16;
constexpr int kClassCount = 80;
constexpr int kPosePointCount = 17;
const int kStrides[3] = {8, 16, 32};

const char* kCocoLabels[kClassCount] = {
    "Человек", "Велосипед", "Автомобиль", "Мотоцикл", "Самолёт", "Автобус", "Поезд", "Грузовик", "Лодка", "Светофор", "Пожарный гидрант", "Знак STOP", "Паркомат", "Скамейка", "Птица", "Кошка", "Собака", "Лошадь", "Овца", "Корова", "Слон", "Медведь", "Зебра", "Жираф", "Рюкзак", "Зонт", "Сумка", "Галстук", "Чемодан", "Фрисби", "Лыжи", "Сноуборд", "Спортивный мяч", "Воздушный змей", "Бейсбольная бита", "Бейсбольная перчатка", "Скейтборд", "Доска для сёрфинга", "Теннисная ракетка", "Бутылка", "Бокал", "Чашка", "Вилка", "Нож", "Ложка", "Миска", "Банан", "Яблоко", "Бутерброд", "Апельсин", "Брокколи", "Морковь", "Хот-дог", "Пицца", "Пончик", "Торт", "Стул", "Диван", "Комнатное растение", "Кровать", "Обеденный стол", "Унитаз", "Телевизор", "Ноутбук", "Компьютерная мышь", "Пульт", "Клавиатура", "Мобильный телефон", "Микроволновка", "Духовка", "Тостер", "Раковина", "Холодильник", "Книга", "Часы", "Ваза", "Ножницы", "Плюшевый медведь", "Фен", "Зубная щётка"
};

float clampFloat(float value, float low, float high) {
    return std::max(low, std::min(high, value));
}
float intersectionOverUnion(const RectF& a, const RectF& b) {
    const float x0 = std::max(a.left, b.left);
    const float y0 = std::max(a.top, b.top);
    const float x1 = std::min(a.right, b.right);
    const float y1 = std::min(a.bottom, b.bottom);
    const float intersection = std::max(0.0f, x1 - x0) * std::max(0.0f, y1 - y0);
    const float areaA = std::max(0.0f, a.right - a.left) * std::max(0.0f, a.bottom - a.top);
    const float areaB = std::max(0.0f, b.right - b.left) * std::max(0.0f, b.bottom - b.top);
    const float denominator = areaA + areaB - intersection;
    return denominator > 0.0f ? intersection / denominator : 0.0f;
}

float decodeDfl(const float* values) {
    float maximum = values[0];
    for (int i = 1; i < kRegMax; ++i) maximum = std::max(maximum, values[i]);
    float denominator = 0.0f;
    float numerator = 0.0f;
    for (int i = 0; i < kRegMax; ++i) {
        const float e = std::exp(values[i] - maximum);
        denominator += e;
        numerator += e * static_cast<float>(i);
    }
    return denominator > 0.0f ? numerator / denominator : 0.0f;
}

struct LetterboxInfo {
    int resizedWidth = 0;
    int resizedHeight = 0;
    int padLeft = 0;
    int padTop = 0;
    float scale = 1.0f;
};

bool makeInput(const uint8_t* rgba, int width, int height, ncnn::Mat& input, LetterboxInfo& info) {
    if (!rgba || width <= 0 || height <= 0) return false;
    info.scale = std::min(static_cast<float>(kInputSize) / width, static_cast<float>(kInputSize) / height);
    info.resizedWidth = std::max(1, static_cast<int>(std::round(width * info.scale)));
    info.resizedHeight = std::max(1, static_cast<int>(std::round(height * info.scale)));
    info.padLeft = (kInputSize - info.resizedWidth) / 2;
    info.padTop = (kInputSize - info.resizedHeight) / 2;

    ncnn::Mat resized = ncnn::Mat::from_pixels_resize(
        rgba, ncnn::Mat::PIXEL_RGBA2RGB, width, height, info.resizedWidth, info.resizedHeight);
    if (resized.empty()) return false;
    ncnn::copy_make_border(resized, input,
                           info.padTop, kInputSize - info.resizedHeight - info.padTop,
                           info.padLeft, kInputSize - info.resizedWidth - info.padLeft,
                           ncnn::BORDER_CONSTANT, 114.0f);
    const float mean[3] = {0.0f, 0.0f, 0.0f};
    const float norm[3] = {1.0f / 255.0f, 1.0f / 255.0f, 1.0f / 255.0f};
    input.substract_mean_normalize(mean, norm);
    return !input.empty();
}

RectF mapBoxToFrame(float x0, float y0, float x1, float y1,
                    const LetterboxInfo& info, int width, int height) {
    RectF box;
    box.left = clampFloat((x0 - info.padLeft) / info.scale, 0.0f, static_cast<float>(width));
    box.top = clampFloat((y0 - info.padTop) / info.scale, 0.0f, static_cast<float>(height));
    box.right = clampFloat((x1 - info.padLeft) / info.scale, 0.0f, static_cast<float>(width));
    box.bottom = clampFloat((y1 - info.padTop) / info.scale, 0.0f, static_cast<float>(height));
    return box;
}

void decodeBox(const float* row, int gridX, int gridY, int stride, float& x0, float& y0, float& x1, float& y1) {
    const float centerX = (static_cast<float>(gridX) + 0.5f) * stride;
    const float centerY = (static_cast<float>(gridY) + 0.5f) * stride;
    const float left = decodeDfl(row + 0) * stride;
    const float top = decodeDfl(row + 16) * stride;
    const float right = decodeDfl(row + 32) * stride;
    const float bottom = decodeDfl(row + 48) * stride;
    x0 = centerX - left;
    y0 = centerY - top;
    x1 = centerX + right;
    y1 = centerY + bottom;
}

std::vector<Detection> suppress(std::vector<Detection> values) {
    std::sort(values.begin(), values.end(), [](const Detection& a, const Detection& b) {
        return a.confidence > b.confidence;
    });
    std::vector<Detection> result;
    for (const auto& candidate : values) {
        bool keep = true;
        for (const auto& selected : result) {
            if (candidate.classId == selected.classId && intersectionOverUnion(candidate.box, selected.box) > kNmsThreshold) {
                keep = false;
                break;
            }
        }
        if (keep) result.push_back(candidate);
        if (result.size() >= 40) break;
    }
    return result;
}
}

bool VisionEngine::loadModel(ncnn::Net& net, AAssetManager* assets, const char* paramName, const char* binName) {
#if defined(__ANDROID__)
    if (!assets) return false;
    net.opt.num_threads = 2;
    net.opt.use_vulkan_compute = false;
    net.opt.use_fp16_storage = false;
    net.opt.use_fp16_arithmetic = false;
    const int paramStatus = net.load_param(assets, paramName);
    const int modelStatus = net.load_model(assets, binName);
    if (paramStatus != 0 || modelStatus != 0) {
        LOGW("Unable to load model %s / %s (param=%d model=%d)", paramName, binName, paramStatus, modelStatus);
        return false;
    }
    LOGI("Model loaded: %s", paramName);
    return true;
#else
    (void)net; (void)assets; (void)paramName; (void)binName;
    return false;
#endif
}

bool VisionEngine::loadModelFiles(ncnn::Net& net, const std::string& paramPath, const std::string& binPath) {
    net.opt.num_threads = std::max(1, static_cast<int>(std::thread::hardware_concurrency()) / 2);
    net.opt.use_vulkan_compute = false;
    net.opt.use_fp16_storage = false;
    net.opt.use_fp16_arithmetic = false;
    const int paramStatus = net.load_param(paramPath.c_str());
    const int modelStatus = net.load_model(binPath.c_str());
    if (paramStatus != 0 || modelStatus != 0) {
        LOGW("Unable to load model %s / %s (param=%d model=%d)", paramPath.c_str(), binPath.c_str(), paramStatus, modelStatus);
        return false;
    }
    LOGI("Model loaded: %s", paramPath.c_str());
    return true;
}

bool VisionEngine::initialize(AAssetManager* assets) {
    detectorReady_ = loadModel(detector_, assets, "yolov8n.ncnn.param", "yolov8n.ncnn.bin");
    poseReady_ = loadModel(pose_, assets, "yolov8n_pose.ncnn.param", "yolov8n_pose.ncnn.bin");
    return detectorReady_;
}

bool VisionEngine::initializeFromDirectory(const std::string& modelDirectory) {
    const std::string slash = !modelDirectory.empty() && modelDirectory.back() == '/' ? "" : "/";
    return initializeFromFiles(modelDirectory + slash + "yolov8n.ncnn.param",
                               modelDirectory + slash + "yolov8n.ncnn.bin",
                               modelDirectory + slash + "yolov8n_pose.ncnn.param",
                               modelDirectory + slash + "yolov8n_pose.ncnn.bin");
}

bool VisionEngine::initializeFromFiles(const std::string& detectorParam, const std::string& detectorBin,
                                       const std::string& poseParam, const std::string& poseBin) {
    detectorReady_ = loadModelFiles(detector_, detectorParam, detectorBin);
    poseReady_ = loadModelFiles(pose_, poseParam, poseBin);
    return detectorReady_;
}

VisionFrame VisionEngine::processRgba(const uint8_t* rgba, int width, int height, bool enabled, bool runPoseThisFrame) {
    VisionFrame frame;
    frame.frameWidth = width;
    frame.frameHeight = height;
    frame.detectorReady = detectorReady_;
    frame.poseReady = poseReady_;
    ++frameNumber_;
    if (!enabled || !rgba || width <= 0 || height <= 0) return frame;

    const auto start = std::chrono::steady_clock::now();
    if (detectorReady_) frame.detections = stabilize(runDetector(rgba, width, height));
    if (poseReady_) {
        if (runPoseThisFrame) previousPeople_ = this->runPose(rgba, width, height);
        frame.people = previousPeople_;
    }
    const auto stop = std::chrono::steady_clock::now();
    frame.inferenceMs = std::chrono::duration<float, std::milli>(stop - start).count();
    return frame;
}

std::vector<Detection> VisionEngine::runDetector(const uint8_t* rgba, int width, int height) {
    ncnn::Mat input;
    LetterboxInfo info;
    if (!makeInput(rgba, width, height, input, info)) return {};

    ncnn::Extractor extractor = detector_.create_extractor();
    extractor.set_light_mode(true);
    extractor.input("in0", input);
    ncnn::Mat output;
    if (extractor.extract("out0", output) != 0 || output.empty() || output.dims != 2 || output.w < 64 + kClassCount) {
        LOGW("Unexpected YOLOv8 detection output shape");
        return {};
    }

    std::vector<Detection> candidates;
    int rowOffset = 0;
    for (int level = 0; level < 3; ++level) {
        const int stride = kStrides[level];
        const int gridSize = kInputSize / stride;
        const int count = gridSize * gridSize;
        for (int index = 0; index < count && rowOffset + index < output.h; ++index) {
            const float* row = output.row(rowOffset + index);
            int bestClass = -1;
            float bestScore = 0.0f;
            for (int c = 0; c < kClassCount; ++c) {
                const float score = row[64 + c];
                if (score > bestScore) {
                    bestScore = score;
                    bestClass = c;
                }
            }
            if (bestClass < 0 || bestScore < kObjectThreshold) continue;
            const int gx = index % gridSize;
            const int gy = index / gridSize;
            float x0, y0, x1, y1;
            decodeBox(row, gx, gy, stride, x0, y0, x1, y1);
            Detection detection;
            detection.classId = bestClass;
            detection.label = kCocoLabels[bestClass];
            detection.confidence = bestScore;
            detection.box = mapBoxToFrame(x0, y0, x1, y1, info, width, height);
            if (detection.box.right - detection.box.left >= 3.0f && detection.box.bottom - detection.box.top >= 3.0f) {
                candidates.push_back(std::move(detection));
            }
        }
        rowOffset += count;
    }
    return suppress(std::move(candidates));
}

std::vector<PersonPose> VisionEngine::runPose(const uint8_t* rgba, int width, int height) {
    ncnn::Mat input;
    LetterboxInfo info;
    if (!makeInput(rgba, width, height, input, info)) return {};

    ncnn::Extractor extractor = pose_.create_extractor();
    extractor.set_light_mode(true);
    extractor.input("in0", input);
    ncnn::Mat boxes;
    ncnn::Mat keypoints;
    if (extractor.extract("out0", boxes) != 0 || extractor.extract("out1", keypoints) != 0 ||
        boxes.empty() || keypoints.empty() || boxes.dims != 2 || keypoints.dims != 2 ||
        boxes.w < 65 || keypoints.w < 51) {
        LOGW("Unexpected YOLOv8 pose output shape");
        return {};
    }

    struct PoseCandidate { PersonPose pose; };
    std::vector<PoseCandidate> candidates;
    int rowOffset = 0;
    for (int level = 0; level < 3; ++level) {
        const int stride = kStrides[level];
        const int gridSize = kInputSize / stride;
        const int count = gridSize * gridSize;
        for (int index = 0; index < count && rowOffset + index < boxes.h && rowOffset + index < keypoints.h; ++index) {
            const float* row = boxes.row(rowOffset + index);
            const float score = row[64];
            if (score < kPoseThreshold) continue;
            const int gx = index % gridSize;
            const int gy = index / gridSize;
            float x0, y0, x1, y1;
            decodeBox(row, gx, gy, stride, x0, y0, x1, y1);
            PersonPose pose;
            pose.confidence = score;
            pose.box = mapBoxToFrame(x0, y0, x1, y1, info, width, height);
            const float* kp = keypoints.row(rowOffset + index);
            for (int point = 0; point < kPosePointCount; ++point) {
                const float inputX = (kp[point * 3] * 2.0f + gx + 0.5f) * stride;
                const float inputY = (kp[point * 3 + 1] * 2.0f + gy + 0.5f) * stride;
                pose.keypoints[point].x = clampFloat((inputX - info.padLeft) / info.scale, 0.0f, static_cast<float>(width));
                pose.keypoints[point].y = clampFloat((inputY - info.padTop) / info.scale, 0.0f, static_cast<float>(height));
                pose.keypoints[point].confidence = kp[point * 3 + 2];
            }
            candidates.push_back({pose});
        }
        rowOffset += count;
    }

    std::sort(candidates.begin(), candidates.end(), [](const PoseCandidate& a, const PoseCandidate& b) {
        return a.pose.confidence > b.pose.confidence;
    });
    std::vector<PersonPose> result;
    for (const auto& candidate : candidates) {
        bool overlap = false;
        for (const auto& selected : result) {
            if (intersectionOverUnion(candidate.pose.box, selected.box) > kNmsThreshold) {
                overlap = true;
                break;
            }
        }
        if (!overlap) result.push_back(candidate.pose);
        if (result.size() >= 8) break;
    }
    return result;
}

std::vector<Detection> VisionEngine::stabilize(std::vector<Detection> detections) {
    // A short temporal filter damps frame-to-frame box jitter and suppresses label flicker.
    // It deliberately does not turn a static person into a confirmed statue.
    for (auto& current : detections) {
        for (const auto& previous : previousDetections_) {
            if (current.classId != previous.classId) continue;
            if (intersectionOverUnion(current.box, previous.box) < 0.35f) continue;
            constexpr float oldWeight = 0.58f;
            current.box.left = oldWeight * previous.box.left + (1.0f - oldWeight) * current.box.left;
            current.box.top = oldWeight * previous.box.top + (1.0f - oldWeight) * current.box.top;
            current.box.right = oldWeight * previous.box.right + (1.0f - oldWeight) * current.box.right;
            current.box.bottom = oldWeight * previous.box.bottom + (1.0f - oldWeight) * current.box.bottom;
            break;
        }
    }
    previousDetections_ = detections;
    return detections;
}
