#include "session_logger.h"

#include <android/log.h>

#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <ctime>
#include <iomanip>
#include <mutex>
#include <sstream>
#include <string>

namespace {
class SessionLogger {
public:
    void append(int priority, const char* tag, const char* message) {
        // Serialize timestamp creation and append so concurrent worker events
        // cannot be stored out of chronological order.
        std::lock_guard<std::mutex> lock(mutex_);
        const auto nowSystem = std::chrono::system_clock::now();
        const auto nowSteady = std::chrono::steady_clock::now();
        const auto wall = std::chrono::system_clock::to_time_t(nowSystem);
        const auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(
            nowSystem.time_since_epoch()).count() % 1000;
        const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            nowSteady - started_).count();
        std::tm utc{};
        gmtime_r(&wall, &utc);

        std::ostringstream line;
        line << std::put_time(&utc, "%Y-%m-%dT%H:%M:%S")
             << '.' << std::setw(3) << std::setfill('0') << millis
             << "Z +" << elapsed << "ms "
             << levelName(priority) << '/' << (tag ? tag : "Diplomka")
             << ": " << (message ? message : "") << '\n';

        if (lines_ == 0) {
            data_ += "DIPLOMKA APPLICATION SESSION LOG\n";
            data_ += "Format: UTC timestamp + elapsed monotonic time, level/tag, message\n";
            data_ += "Scope: Diplomka process events (not the Android system-wide logcat)\n\n";
        }
        data_ += line.str();
        ++lines_;
    }

    std::string snapshot() const {
        std::lock_guard<std::mutex> lock(mutex_);
        std::ostringstream header;
        header << "\n--- LOG SUMMARY ---\n"
               << "Application log lines: " << lines_ << "\n"
               << "--- BEGIN FULL SESSION LOG ---\n";
        return header.str() + data_ + "\n--- END FULL SESSION LOG ---\n";
    }

    uint64_t count() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return lines_;
    }

private:
    static const char* levelName(int priority) {
        switch (priority) {
            case ANDROID_LOG_VERBOSE: return "V";
            case ANDROID_LOG_DEBUG: return "D";
            case ANDROID_LOG_INFO: return "I";
            case ANDROID_LOG_WARN: return "W";
            case ANDROID_LOG_ERROR: return "E";
            case ANDROID_LOG_FATAL: return "F";
            default: return "?";
        }
    }

    const std::chrono::steady_clock::time_point started_ = std::chrono::steady_clock::now();
    mutable std::mutex mutex_;
    std::string data_;
    uint64_t lines_ = 0;
};

SessionLogger& logger() {
    static SessionLogger instance;
    return instance;
}
}

void appLogWrite(int priority, const char* tag, const char* format, ...) {
    char message[4096];
    va_list args;
    va_start(args, format);
    vsnprintf(message, sizeof(message), format ? format : "", args);
    va_end(args);
    __android_log_write(priority, tag ? tag : "Diplomka", message);
    logger().append(priority, tag, message);
}

std::string appLogSnapshot() {
    return logger().snapshot();
}

uint64_t appLogLineCount() {
    return logger().count();
}
