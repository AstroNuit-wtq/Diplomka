#pragma once

#include <android/native_window.h>
#include <android/looper.h>
#include <camera/NdkCameraManager.h>
#include <camera/NdkCameraDevice.h>
#include <camera/NdkCaptureRequest.h>
#include <camera/NdkCameraCaptureSession.h>
#include <media/NdkImageReader.h>

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

// Camera2 objects are owned by one dedicated worker thread. Android Camera2
// callbacks may arrive on framework-managed threads; they only enqueue events.
// UI actions are non-blocking and never call Camera2 directly.
class CameraEngine {
public:
    using FrameConsumer = std::function<void(std::vector<uint8_t>&&, int, int)>;

    CameraEngine();
    ~CameraEngine();
    CameraEngine(const CameraEngine&) = delete;
    CameraEngine& operator=(const CameraEngine&) = delete;

    // Non-blocking commands. true means the command was accepted for processing.
    bool start(FrameConsumer consumer);
    void stop();
    bool setTorch(bool enabled);
    void shutdown();

    bool isRunning() const { return running_.load(); }
    bool isStartPending() const { return startPending_.load(); }
    bool isSessionActive() const { return sessionActive_.load(); }
    bool isTorchAvailable() const { return flashAvailable_.load(); }
    bool isTorchEnabled() const { return torchEnabled_.load(); }
    uint64_t frameCount() const { return frameCount_.load(); }
    int lastErrorCode() const { return lastErrorCode_.load(); }
    int frameWidth() const { return width_.load(); }
    int frameHeight() const { return height_.load(); }

private:
    enum class CommandType {
        Start, Stop, Torch, Shutdown,
        SessionReady, SessionActive, SessionClosed,
        DeviceError, DeviceDisconnected
    };
    struct Command {
        CommandType type = CommandType::Stop;
        FrameConsumer consumer;
        bool enabled = false;
        ACameraCaptureSession* session = nullptr;
        ACameraDevice* device = nullptr;
        int errorCode = 0;
    };

    void workerLoop();
    void enqueue(Command command);
    void processCommands();
    bool startOnWorker(FrameConsumer consumer);
    void stopOnWorker();
    void setTorchOnWorker(bool enabled);
    bool chooseBackCamera();
    void consumeLatestImage(AImageReader* reader);
    void setError(int errorCode, const char* operation);

    static void onImageAvailable(void* context, AImageReader* reader);
    static void onCameraDisconnected(void* context, ACameraDevice* device);
    static void onCameraError(void* context, ACameraDevice* device, int error);
    static void onSessionClosed(void* context, ACameraCaptureSession* session);
    static void onSessionReady(void* context, ACameraCaptureSession* session);
    static void onSessionActive(void* context, ACameraCaptureSession* session);

    // Worker-thread-only Camera2 state.
    ACameraManager* manager_ = nullptr;
    ACameraDevice* device_ = nullptr;
    ACameraCaptureSession* session_ = nullptr;
    AImageReader* reader_ = nullptr;
    ANativeWindow* readerWindow_ = nullptr;
    ACameraOutputTarget* target_ = nullptr;
    ACaptureRequest* request_ = nullptr;
    ACaptureSessionOutputContainer* outputContainer_ = nullptr;
    ACaptureSessionOutput* sessionOutput_ = nullptr;
    ACameraCaptureSession* pendingCloseSession_ = nullptr;
    bool sessionCloseTimedOut_ = false;
    std::string cameraId_;
    uint8_t selectedAfMode_ = ACAMERA_CONTROL_AF_MODE_OFF;
    uint8_t selectedAeMode_ = ACAMERA_CONTROL_AE_MODE_ON;
    FrameConsumer consumer_;

    // AImageReader dispatches image callbacks on its own dedicated thread.
    // Gate and drain that callback thread before freeing reader/consumer state.
    std::mutex imageCallbackMutex_;
    std::condition_variable imageCallbackCv_;
    uint32_t activeImageCallbacks_ = 0;
    bool acceptImageCallbacks_ = false;

    std::shared_ptr<struct CameraCallbackBridge> callbackBridge_;

    std::thread worker_;
    std::atomic<ALooper*> looper_{nullptr};
    std::mutex commandMutex_;
    std::deque<Command> commands_;
    std::mutex startupMutex_;
    std::condition_variable startupCv_;
    bool workerReady_ = false;
    std::atomic<bool> workerFailed_{false};
    std::atomic<bool> shutdownRequested_{false};
    std::atomic<bool> shutdownComplete_{false};

    std::atomic<bool> startPending_{false};
    std::atomic<bool> stopPending_{false};
    std::atomic<bool> running_{false};
    std::atomic<bool> sessionActive_{false};
    std::atomic<bool> repeatingStarted_{false};
    std::atomic<bool> flashAvailable_{false};
    std::atomic<bool> torchEnabled_{false};
    std::atomic<uint64_t> frameCount_{0};
    std::atomic<int> lastErrorCode_{0};
    std::atomic<int> width_{640};
    std::atomic<int> height_{480};
};
