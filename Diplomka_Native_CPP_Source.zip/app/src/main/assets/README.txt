Android map assets

Place your compatible map/reference image here as map.jpg before building the APK.
Edit route.csv to define waypoints: id,x,y,neighbors.
The camera view and map image need overlapping visual landmarks for ORB matching.
