# Паспорт проекта Diplomka

## Цель

Локальное приложение для отображения видеопотока, обработки кадра классическими алгоритмами OpenCV, вывода направления к следующей точке маршрутного графа и предупреждения об обнаруженных препятствиях. Предусмотрены две платформы: Android смартфон и Raspberry Pi 4B.

## Платформы и структура

| Платформа | Реализация | Точка входа | Результат |
|---|---|---|---|
| Android | C++20, NDK, NativeActivity, Camera2 NDK, ImGui/OpenGL ES, OpenCV 4.10 | `app/src/main/cpp/main.cpp` | arm64-v8a APK через GitHub Actions |
| Raspberry Pi 4B | C++17/20, SDL2/OpenGL ES, rpicam-vid, OpenCV system package | `raspberry_pi/main.cpp` | локальное Linux-приложение |
| Общая логика зрения | C++ и OpenCV, общая PiVision/ClassicalVision engine | `app/src/main/cpp/pi_vision_engine.cpp` | CPU-only обработка изображений |

## Основные алгоритмы

- Люди: HOG + SVM proposals.
- Крупные/движущиеся объекты: контурная геометрия и разность кадров.
- Дорога: HSV-маска жёлтой разметки, Hough, Canny, контуры бордюров.
- Движение камеры: Lucas–Kanade optical flow; величины в пикселях, без точной метрической калибровки.
- Маршрут: ORB/BFMatcher matching карты, граф соседей и выбор следующей точки.
- Погода: визуальные эвристики цвета/яркости/облачности.
- STOP/обход: проверка нескольких локальных коридоров и консервативная остановка, если коридоры считаются перекрытыми.

## Файлы для сборки Android

`Diplomka_Native_CPP_Source.zip` — Gradle/NDK проект. `build-astro-cpp.yml` — workflow, который скачивает OpenCV Android SDK и собирает ARM64 APK. В GitHub репозиторий нужно загрузить ZIP в корень и workflow в `.github/workflows/build-astro-cpp.yml`.

## Устройство

Последнее предоставленное устройство для проверки: Xiaomi Redmi 9 (device `lancelot`, Android SDK 34). Последний предоставленный session log всё ещё относился к приложению 2.7.0 и показывал открытие камеры, создание сессии, но 0 capture results и 0 image callbacks до тайм-аута. Он не подтверждает работу новой версии.

## Обязательные последующие проверки

1. Собрать APK 2.7.4 в Actions и проверить, что в логах написано version 2.7.4.
2. На Redmi 9 убедиться, что `captureResults` и `imageCallbacks` растут и камера выводит живой кадр.
3. Проверить включение/выключение вспышки только при работающей камере.
4. Проверить сворачивание верхней панели, увеличение окна камеры, переход журнала, splash 2 секунды, STOP и цвета переключателей.
5. Проверить Pi сборку/CSI camera на самой Raspberry Pi 4B.
6. Для аппаратной навигации отдельно добавить motor-controller interface и physical emergency stop; не считать UI STOP электрическим отключением приводов.
