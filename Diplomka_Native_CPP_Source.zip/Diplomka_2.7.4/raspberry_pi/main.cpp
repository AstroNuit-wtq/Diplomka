#include <SDL.h>
#include <GLES3/gl3.h>

#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_opengl3.h"

#include "camera_pipe.h"
#include "pi_vision_engine.h"

#include <opencv2/imgproc.hpp>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <utility>
#include <vector>

namespace {
constexpr int kFrameWidth = 640;
constexpr int kFrameHeight = 480;
constexpr int kCameraFps = 10;

struct FrameData {
    std::vector<uint8_t> rgba;
    int width = 0;
    int height = 0;
    uint64_t version = 0;
};

struct LogState {
    std::vector<std::string> lines;
    std::mutex mutex;
    std::string sessionPath;
};

std::string timestampNow() {
    const std::time_t now = std::time(nullptr);
    std::tm local{};
    localtime_r(&now, &local);
    char buffer[32]{};
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d_%H-%M-%S", &local);
    return buffer;
}

void initializeLog(LogState& log) {
    const char* home = std::getenv("HOME");
    const std::filesystem::path base = home ? home : ".";
    const std::filesystem::path directory = base / ".local" / "share" / "diplomka" / "logs";
    std::error_code error;
    std::filesystem::create_directories(directory, error);
    if (!error) log.sessionPath = (directory / ("diplomka-session-" + timestampNow() + ".txt")).string();
}

void addLog(LogState& log, const std::string& message) {
    const std::string line = timestampNow() + " | " + message;
    std::lock_guard<std::mutex> lock(log.mutex);
    log.lines.push_back(line);
    if (log.lines.size() > 80) log.lines.erase(log.lines.begin(), log.lines.begin() + static_cast<std::ptrdiff_t>(log.lines.size() - 80));
    if (!log.sessionPath.empty()) {
        std::ofstream output(log.sessionPath, std::ios::app);
        if (output) output << line << '\n';
    }
}

bool exportSessionLog(LogState& log, std::string& destination) {
    std::lock_guard<std::mutex> lock(log.mutex);
    if (log.sessionPath.empty() || !std::filesystem::exists(log.sessionPath)) return false;
    const char* home = std::getenv("HOME");
    const std::filesystem::path base = home ? home : ".";
    const std::filesystem::path directory = base / "Downloads" / "Diplomka";
    std::error_code error;
    std::filesystem::create_directories(directory, error);
    if (error) return false;
    const std::filesystem::path target = directory / ("diplomka-session-export-" + timestampNow() + ".txt");
    std::filesystem::copy_file(log.sessionPath, target, std::filesystem::copy_options::overwrite_existing, error);
    if (error) return false;
    destination = target.string();
    return true;
}

void setupMaterialYouStyle() {
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 22.0f;
    style.ChildRounding = 18.0f;
    style.FrameRounding = 16.0f;
    style.PopupRounding = 18.0f;
    style.ScrollbarRounding = 14.0f;
    style.GrabRounding = 14.0f;
    style.WindowPadding = ImVec2(16, 14);
    style.FramePadding = ImVec2(14, 11);
    style.ItemSpacing = ImVec2(9, 9);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.035f, 0.055f, 0.065f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.075f, 0.105f, 0.115f, 0.98f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.11f, 0.16f, 0.17f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.10f, 0.15f, 0.16f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.15f, 0.23f, 0.23f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.19f, 0.34f, 0.31f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.59f, 0.94f, 0.84f, 1.0f);
}

void drawRoverBrand(ImDrawList* draw, ImVec2 origin) {
    const ImU32 chassis = IM_COL32(202, 218, 215, 255);
    const ImU32 wheel = IM_COL32(54, 76, 80, 255);
    const ImU32 mint = IM_COL32(111, 240, 211, 255);
    // Three-wheel silhouette, matching the Android launcher icon.
    for (int i = 0; i < 3; ++i) {
        const float x = origin.x + 8.0f + i * 11.0f;
        draw->AddCircleFilled(ImVec2(x, origin.y + 23.0f), 3.5f, wheel, 18);
        draw->AddCircle(ImVec2(x, origin.y + 23.0f), 3.5f, mint, 18, 1.0f);
        draw->AddCircle(ImVec2(x, origin.y + 23.0f), 1.45f, chassis, 14, 0.8f);
    }
    draw->AddLine(ImVec2(origin.x + 8.0f, origin.y + 20.0f), ImVec2(origin.x + 30.0f, origin.y + 10.0f), chassis, 1.4f);
    draw->AddRectFilled(ImVec2(origin.x + 10.0f, origin.y + 6.0f), ImVec2(origin.x + 27.0f, origin.y + 16.0f), chassis, 3.0f);
    draw->AddLine(ImVec2(origin.x + 23.0f, origin.y + 6.0f), ImVec2(origin.x + 25.0f, origin.y + 1.0f), chassis, 1.4f);
    draw->AddCircleFilled(ImVec2(origin.x + 25.0f, origin.y + 1.0f), 2.0f, mint, 16);
}

void drawCameraOverlay(const FrameData& frame, const PiVisionResult& vision, ImVec2 origin, ImVec2 size) {
    if (frame.rgba.empty() || frame.width <= 0 || frame.height <= 0) return;
    ImDrawList* draw = ImGui::GetWindowDrawList();
    const float sx = size.x / static_cast<float>(frame.width);
    const float sy = size.y / static_cast<float>(frame.height);
    auto rect = [&](const cv::Rect& box, ImU32 color, float thickness) {
        const ImVec2 a(origin.x + box.x * sx, origin.y + box.y * sy);
        const ImVec2 b(origin.x + (box.x + box.width) * sx, origin.y + (box.y + box.height) * sy);
        draw->AddRect(a, b, color, 3.0f, 0, thickness);
    };
    for (const auto& box : vision.staticObjects) rect(box, IM_COL32(80, 145, 255, 190), 1.2f);
    for (const auto& box : vision.movingObjects) rect(box, IM_COL32(255, 205, 85, 220), 1.4f);
    for (const auto& detection : vision.detections) {
        const ImU32 color = detection.isPerson ? IM_COL32(255, 85, 95, 255) : IM_COL32(255, 160, 70, 255);
        rect(detection.box, color, 2.0f);
        const ImVec2 labelPos(origin.x + detection.box.x * sx + 3.0f,
                              std::max(origin.y, origin.y + detection.box.y * sy - 19.0f));
        draw->AddText(labelPos, color, detection.label.c_str());
    }
    for (const auto& line : vision.yellowLines) {
        draw->AddLine(ImVec2(origin.x + line[0] * sx, origin.y + line[1] * sy),
                      ImVec2(origin.x + line[2] * sx, origin.y + line[3] * sy),
                      IM_COL32(255, 230, 75, 235), 2.0f);
    }
    for (const auto& curb : vision.curbs) rect(curb, IM_COL32(220, 100, 230, 150), 1.0f);
    if (vision.hasTarget) {
        const ImVec2 start(origin.x + frame.width * 0.5f * sx, origin.y + (frame.height - 2) * sy);
        const ImVec2 target(origin.x + vision.target.x * sx, origin.y + vision.target.y * sy);
        draw->AddLine(start, target, vision.stopSignal ? IM_COL32(255, 65, 65, 240) : IM_COL32(90, 245, 180, 240), 3.0f);
        draw->AddCircleFilled(target, 6.0f, IM_COL32(90, 245, 180, 255), 20);
    }
    if (vision.hasMapTarget) {
        const ImVec2 mapGoal(origin.x + vision.mapTarget.x * sx, origin.y + vision.mapTarget.y * sy);
        draw->AddCircle(mapGoal, 9.0f, IM_COL32(100, 175, 255, 255), 24, 2.0f);
    }
    if (vision.stopSignal) {
        draw->AddRect(origin, ImVec2(origin.x + size.x, origin.y + size.y), IM_COL32(255, 55, 55, 220), 2.0f);
        draw->AddText(ImVec2(origin.x + 10, origin.y + 8), IM_COL32(255, 80, 80, 255), "STOP");
    }
}

cv::Point2f waypointToPixels(const MapWaypoint& point, const cv::Size& imageSize) {
    if (point.position.x >= 0.0f && point.position.x <= 1.0f &&
        point.position.y >= 0.0f && point.position.y <= 1.0f) {
        return cv::Point2f(point.position.x * imageSize.width, point.position.y * imageSize.height);
    }
    return point.position;
}

void drawMapOverlay(const RouteMap& routeMap, const PiVisionResult& vision,
                    ImVec2 origin, ImVec2 size) {
    if (!routeMap.hasImage()) return;
    const cv::Size mapSize = routeMap.imageBgr().size();
    const float sx = size.x / static_cast<float>(mapSize.width);
    const float sy = size.y / static_cast<float>(mapSize.height);
    ImDrawList* draw = ImGui::GetWindowDrawList();
    const auto& waypoints = routeMap.waypoints();
    const int nextWaypoint = vision.nearestWaypointId >= 0
        ? vision.nearestWaypointId : routeMap.nextWaypoint().value_or(-1);
    for (const auto& point : waypoints) {
        const cv::Point2f p = waypointToPixels(point, mapSize);
        for (const int neighborId : point.neighbors) {
            const auto found = std::find_if(waypoints.begin(), waypoints.end(),
                                            [neighborId](const MapWaypoint& candidate) { return candidate.id == neighborId; });
            if (found == waypoints.end()) continue;
            const cv::Point2f q = waypointToPixels(*found, mapSize);
            draw->AddLine(ImVec2(origin.x + p.x * sx, origin.y + p.y * sy),
                          ImVec2(origin.x + q.x * sx, origin.y + q.y * sy), IM_COL32(100, 210, 190, 210), 2.0f);
        }
        const bool reached = routeMap.isReached(point.id);
        const ImU32 color = reached ? IM_COL32(95, 220, 160, 255) :
            (point.id == nextWaypoint ? IM_COL32(255, 190, 70, 255) : IM_COL32(235, 235, 235, 220));
        draw->AddCircleFilled(ImVec2(origin.x + p.x * sx, origin.y + p.y * sy), point.id == nextWaypoint ? 6.0f : 4.0f, color, 18);
        draw->AddText(ImVec2(origin.x + p.x * sx + 6.0f, origin.y + p.y * sy - 6.0f), IM_COL32(245, 245, 245, 240), std::to_string(point.id).c_str());
    }
    if (vision.mapLocalized) {
        const ImVec2 p(origin.x + vision.mapPosition.x * sx, origin.y + vision.mapPosition.y * sy);
        draw->AddCircle(p, 9.0f, IM_COL32(255, 90, 85, 255), 24, 2.5f);
        draw->AddCircleFilled(p, 3.0f, IM_COL32(255, 90, 85, 255), 16);
    }
}

struct Options {
    std::string mapPath;
    std::string routePath;
};

bool parseOptions(int argc, char** argv, Options& options) {
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") {
            std::cout << "Usage: diplomka-pi [--map image.jpg] [--route route.csv]\n"
                      << "CSV: id,x,y,neighbors ; x/y are map pixels or normalized 0..1 coordinates.\n";
            return false;
        }
        if ((arg == "--map" || arg == "--route") && i + 1 < argc) {
            if (arg == "--map") options.mapPath = argv[++i];
            else options.routePath = argv[++i];
        } else {
            std::cerr << "Unknown or incomplete argument: " << arg << "\n";
            return false;
        }
    }
    return true;
}

} // namespace

int main(int argc, char** argv) {
    LogState logState;
    initializeLog(logState);
    addLog(logState, "Процесс запущен");
    Options options;
    if (!parseOptions(argc, argv, options)) return 0;

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) != 0) {
        SDL_Log("SDL_Init failed: %s", SDL_GetError());
        return 2;
    }
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_Window* window = SDL_CreateWindow("Diplomka · Vision Navigation", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                           1280, 800, SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
    if (!window) {
        SDL_Log("SDL_CreateWindow failed: %s", SDL_GetError());
        SDL_Quit();
        return 2;
    }
    SDL_GLContext glContext = SDL_GL_CreateContext(window);
    if (!glContext) {
        SDL_Log("SDL_GL_CreateContext failed: %s", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 2;
    }
    SDL_GL_MakeCurrent(window, glContext);
    SDL_GL_SetSwapInterval(1);
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.Fonts->AddFontFromFileTTF("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 17.0f, nullptr, io.Fonts->GetGlyphRangesCyrillic());
    setupMaterialYouStyle();
    ImGui_ImplSDL2_InitForOpenGL(window, glContext);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    ClassicalVisionEngine vision;
    std::string mapError;
    if (!options.mapPath.empty() || !options.routePath.empty()) {
        if (!vision.loadMap(options.mapPath, options.routePath, mapError)) {
            std::cerr << "Map/route warning: " << mapError << "\n";
        }
    }

    RaspberryPiCamera camera;
    std::mutex frameMutex;
    FrameData latestFrame;
    std::mutex resultMutex;
    PiVisionResult latestVision;
    RouteMap routeMapUi = vision.routeMap();
    std::atomic<bool> navigationEnabled{true};
    std::atomic<bool> stopWorker{false};
    std::atomic<bool> confirmWaypointRequested{false};
    std::mutex inferenceMutex;
    std::condition_variable inferenceCv;
    std::optional<FrameData> pendingInference;
    addLog(logState, "Инициализация камеры и классического CV · Raspberry Pi 4B");
    if (!mapError.empty()) addLog(logState, mapError);
    if (!logState.sessionPath.empty()) addLog(logState, "Файл полного журнала: " + logState.sessionPath);

    std::thread inferenceThread([&]() {
        bool previousStop = false;
        bool previousBypass = false;
        while (!stopWorker.load()) {
            FrameData frame;
            {
                std::unique_lock<std::mutex> lock(inferenceMutex);
                inferenceCv.wait(lock, [&]() { return stopWorker.load() || pendingInference.has_value(); });
                if (stopWorker.load()) return;
                frame = std::move(*pendingInference);
                pendingInference.reset();
            }
            if (!navigationEnabled.load() || frame.rgba.empty()) continue;
            if (confirmWaypointRequested.exchange(false)) {
                if (vision.confirmNextWaypoint()) addLog(logState, "Маршрут: подтверждено прохождение точки");
            }
            PiVisionResult result = vision.processRgba(frame.rgba, frame.width, frame.height);
            if (result.stopSignal != previousStop) {
                addLog(logState, result.stopSignal ? "Команда STOP: траектория перекрыта" : "STOP снят после проверки свободной траектории");
                previousStop = result.stopSignal;
            }
            if (result.bypassSelected != previousBypass && result.bypassSelected) {
                addLog(logState, "Обнаружен свободный соседний коридор: " + result.direction);
            }
            previousBypass = result.bypassSelected;
            RouteMap mapSnapshot = vision.routeMap();
            {
                std::lock_guard<std::mutex> lock(resultMutex);
                latestVision = std::move(result);
                routeMapUi = std::move(mapSnapshot);
            }
        }
    });

    bool cameraWanted = true;
    bool showLog = true;
    bool expanded = true;
    bool running = false;
    bool quit = false;
    GLuint cameraTexture = 0;
    GLuint mapTexture = 0;
    uint64_t uploadedVersion = 0;
    bool mapTextureUploaded = false;
    uint64_t frameNumber = 0;
    std::string status = "Запускается камера rpicam-vid";
    FrameData displayFrame;

    auto startCamera = [&]() {
        cameraWanted = true;
        running = camera.start([&](std::vector<uint8_t>&& rgba, int width, int height) {
            FrameData copy;
            copy.width = width;
            copy.height = height;
            copy.version = ++frameNumber;
            copy.rgba = std::move(rgba);
            {
                std::lock_guard<std::mutex> lock(frameMutex);
                latestFrame = copy;
            }
            if (navigationEnabled.load() && copy.version % 2 == 0) {
                std::lock_guard<std::mutex> lock(inferenceMutex);
                pendingInference = std::move(copy); // latest-frame queue: old pending frame is discarded
                inferenceCv.notify_one();
            }
        }, kFrameWidth, kFrameHeight, kCameraFps);
        status = running ? "Камера запущена · ожидаю первый кадр" : "Не удалось запустить камеру: " + camera.lastError();
        addLog(logState, status);
    };
    startCamera();

    while (!quit) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            ImGui_ImplSDL2_ProcessEvent(&event);
            if (event.type == SDL_QUIT) quit = true;
            if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) quit = true;
        }
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();

        int displayW = 0, displayH = 0;
        SDL_GL_GetDrawableSize(window, &displayW, &displayH);
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(ImVec2(static_cast<float>(displayW), static_cast<float>(displayH)));
        ImGui::Begin("Diplomka Main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
        running = camera.isRunning();
        {
            std::lock_guard<std::mutex> lock(frameMutex);
            if (latestFrame.version > displayFrame.version) displayFrame = latestFrame;
        }
        PiVisionResult visionFrame;
        RouteMap mapSnapshot;
        {
            std::lock_guard<std::mutex> lock(resultMutex);
            visionFrame = latestVision;
            mapSnapshot = routeMapUi;
        }

        const ImVec2 brandPos = ImGui::GetCursorScreenPos();
        drawRoverBrand(ImGui::GetWindowDrawList(), brandPos);
        ImGui::Dummy(ImVec2(44.0f, 34.0f));
        ImGui::SameLine(0, 6.0f);
        ImGui::BeginGroup();
        ImGui::TextColored(ImVec4(0.72f, 0.96f, 0.89f, 1.0f), "DIPLOMKA");
        ImGui::TextDisabled("RASPBERRY PI 4B · C++ · OFFLINE VISION");
        ImGui::EndGroup();
        ImGui::SameLine();
        const bool hasFrames = camera.frameCount() > 0;
        ImGui::TextColored(hasFrames ? ImVec4(0.55f, 0.88f, 0.74f, 1) : ImVec4(1, 0.63f, 0.55f, 1), hasFrames ? "● LIVE" : "● WAIT");

        ImGui::BeginChild("status", ImVec2(0, 88), true);
        ImGui::TextWrapped("%s", status.c_str());
        ImGui::SameLine(); ImGui::TextDisabled("Кадры: %llu", static_cast<unsigned long long>(camera.frameCount()));
        const ImVec4 directiveColor = visionFrame.stopSignal ? ImVec4(1.0f, 0.34f, 0.34f, 1.0f) : ImVec4(0.45f, 0.95f, 0.73f, 1.0f);
        ImGui::TextColored(directiveColor, "НАВИГАЦИЯ: %s", visionFrame.direction.c_str());
        if (!visionFrame.stopReason.empty()) ImGui::SameLine(), ImGui::TextWrapped("· %s", visionFrame.stopReason.c_str());
        ImGui::TextDisabled("Погода по кадру: %s", visionFrame.weather.c_str());
        ImGui::EndChild();

        const float footerHeight = (showLog ? 142.0f : 72.0f) + (expanded ? 60.0f : 0.0f);
        const float workHeight = std::max(240.0f, ImGui::GetContentRegionAvail().y - footerHeight - 8.0f);
        ImGui::BeginChild("work_area", ImVec2(0, workHeight), false);
        const ImVec2 workAvail = ImGui::GetContentRegionAvail();
        const bool showMap = mapSnapshot.hasImage();
        const float mapWidth = showMap ? std::max(210.0f, workAvail.x * 0.27f) : 0.0f;
        const float cameraWidth = showMap ? workAvail.x - mapWidth - 8.0f : workAvail.x;

        ImGui::BeginChild("camera_panel", ImVec2(cameraWidth, 0), true);
        const ImVec2 cameraPos = ImGui::GetCursorScreenPos();
        const ImVec2 cameraAvail = ImGui::GetContentRegionAvail();
        if (!displayFrame.rgba.empty()) {
            if (!cameraTexture) glGenTextures(1, &cameraTexture);
            glBindTexture(GL_TEXTURE_2D, cameraTexture);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            if (displayFrame.version != uploadedVersion) {
                glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, displayFrame.width, displayFrame.height, 0,
                             GL_RGBA, GL_UNSIGNED_BYTE, displayFrame.rgba.data());
                uploadedVersion = displayFrame.version;
            }
            const float aspect = static_cast<float>(displayFrame.width) / static_cast<float>(displayFrame.height);
            ImVec2 imageSize(cameraAvail.x, cameraAvail.x / aspect);
            if (imageSize.y > cameraAvail.y) imageSize = ImVec2(cameraAvail.y * aspect, cameraAvail.y);
            ImGui::Image((ImTextureID)(intptr_t)cameraTexture, imageSize);
            drawCameraOverlay(displayFrame, visionFrame, cameraPos, imageSize);
            glBindTexture(GL_TEXTURE_2D, 0);
            if (running) status = "Камера передаёт изображение";
        } else {
            ImGui::TextWrapped("Ожидание изображения. Проверь CSI-камеру командой rpicam-hello -t 5000.");
            const std::string cameraError = camera.lastError();
            if (!cameraError.empty()) ImGui::TextWrapped("%s", cameraError.c_str());
        }
        ImGui::EndChild();

        if (showMap) {
            ImGui::SameLine();
            ImGui::BeginChild("map_panel", ImVec2(mapWidth, 0), true);
            ImGui::TextColored(ImVec4(0.72f, 0.96f, 0.89f, 1.0f), "КАРТА / МАРШРУТ");
            const ImVec2 mapPos = ImGui::GetCursorScreenPos();
            const ImVec2 mapAvail = ImGui::GetContentRegionAvail();
            if (!mapTexture) glGenTextures(1, &mapTexture);
            if (!mapTextureUploaded) {
                cv::Mat rgbaMap;
                cv::cvtColor(mapSnapshot.imageBgr(), rgbaMap, cv::COLOR_BGR2RGBA);
                glBindTexture(GL_TEXTURE_2D, mapTexture);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
                glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, rgbaMap.cols, rgbaMap.rows, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgbaMap.data);
                glBindTexture(GL_TEXTURE_2D, 0);
                mapTextureUploaded = true;
            }
            const float aspect = static_cast<float>(mapSnapshot.imageBgr().cols) / std::max(1, mapSnapshot.imageBgr().rows);
            ImVec2 mapSize(mapAvail.x, mapAvail.x / aspect);
            if (mapSize.y > mapAvail.y * 0.72f) mapSize = ImVec2(mapAvail.y * 0.72f * aspect, mapAvail.y * 0.72f);
            ImGui::Image((ImTextureID)(intptr_t)mapTexture, mapSize);
            drawMapOverlay(mapSnapshot, visionFrame, mapPos, mapSize);
            glBindTexture(GL_TEXTURE_2D, 0);
            ImGui::TextWrapped("%s", visionFrame.mapStatus.c_str());
            const int nextMapPoint = visionFrame.nearestWaypointId >= 0
                ? visionFrame.nearestWaypointId : mapSnapshot.nextWaypoint().value_or(-1);
            if (nextMapPoint >= 0) ImGui::Text("Следующая точка: %d", nextMapPoint);
            ImGui::EndChild();
        } else if (mapSnapshot.hasWaypoints()) {
            ImGui::TextWrapped("Маршрут CSV загружен, но изображение карты не задано. Точек: %zu", mapSnapshot.waypoints().size());
        }
        ImGui::EndChild();

        ImGui::BeginChild("metrics", ImVec2(0, 58), true);
        ImGui::Text("Людей/объектов: %zu   Движение: %zu   Ширина: %.0f px   Поток: %.1f px/s   Смещение: %.0f px   Время: %.1f ms   Точка карты: %d",
                    visionFrame.detections.size(), visionFrame.movingObjects.size(), visionFrame.roadWidthPixels,
                    visionFrame.opticalFlowPixelsPerSecond, visionFrame.travelledPixels, visionFrame.processingMs,
                    visionFrame.nearestWaypointId);
        ImGui::TextDisabled("Расстояние в метрах не рассчитывается без калибровки/датчика глубины. Визуальная оценка погоды не является прогнозом.");
        ImGui::EndChild();

        auto toggleCamera = [&]() {
            if (cameraWanted) {
                cameraWanted = false;
                camera.stop();
                running = false;
                status = "Камера остановлена";
                addLog(logState, status);
            } else {
                cameraWanted = true;
                running = camera.start([&](std::vector<uint8_t>&& rgba, int width, int height) {
                    FrameData copy{std::move(rgba), width, height, ++frameNumber};
                    { std::lock_guard<std::mutex> lock(frameMutex); latestFrame = copy; }
                    if (navigationEnabled.load() && copy.version % 2 == 0) {
                        std::lock_guard<std::mutex> lock(inferenceMutex);
                        pendingInference = std::move(copy);
                        inferenceCv.notify_one();
                    }
                }, kFrameWidth, kFrameHeight, kCameraFps);
                status = running ? "Камера перезапущена" : "Ошибка камеры: " + camera.lastError();
                addLog(logState, status);
            }
        };
        if (expanded) {
            const float bw = (ImGui::GetContentRegionAvail().x - 4 * ImGui::GetStyle().ItemSpacing.x) / 5.0f;
            if (ImGui::Button(cameraWanted ? "КАМЕРА · ON" : "КАМЕРА · OFF", ImVec2(bw, 46))) toggleCamera();
            ImGui::SameLine();
            if (ImGui::Button(navigationEnabled ? "НАВИГАЦИЯ · ON" : "НАВИГАЦИЯ · OFF", ImVec2(bw, 46))) {
                navigationEnabled.store(!navigationEnabled.load());
                if (navigationEnabled.load()) status = "Классическая обработка включена";
                else status = "Обработка остановлена · видеопоток остаётся доступен";
                addLog(logState, status);
            }
            ImGui::SameLine();
            if (ImGui::Button("ТОЧКА ДОСТИГНУТА", ImVec2(bw, 46))) confirmWaypointRequested.store(true);
            ImGui::SameLine();
            if (ImGui::Button("СОБРАТЬ ЛОГ", ImVec2(bw, 46))) {
                addLog(logState, "Запрошен экспорт полного журнала с момента запуска");
                std::string exported;
                if (exportSessionLog(logState, exported)) addLog(logState, "Полный лог скопирован: " + exported);
                else addLog(logState, "Не удалось экспортировать лог; исходный журнал хранится в ~/.local/share/diplomka/logs");
            }
            ImGui::SameLine();
            if (ImGui::Button(showLog ? "СКРЫТЬ ЛОГ" : "ПОКАЗАТЬ ЛОГ", ImVec2(bw, 46))) showLog = !showLog;
        } else {
            if (ImGui::Button(cameraWanted ? "КАМ" : "OFF", ImVec2(74, 44))) toggleCamera();
            ImGui::SameLine();
            if (ImGui::Button(navigationEnabled ? "НАВ" : "НАВ OFF", ImVec2(86, 44))) navigationEnabled.store(!navigationEnabled.load());
            ImGui::SameLine();
            if (ImGui::Button("ТОЧКА +", ImVec2(100, 44))) confirmWaypointRequested.store(true);
            ImGui::SameLine();
            if (ImGui::Button("ЛОГ", ImVec2(70, 44))) showLog = !showLog;
        }
        if (showLog) {
            ImGui::BeginChild("log", ImVec2(0, 82), true);
            ImGui::TextColored(ImVec4(0.82f, 0.75f, 1.0f, 1.0f), "ЖУРНАЛ");
            std::vector<std::string> snapshot;
            { std::lock_guard<std::mutex> lock(logState.mutex); snapshot = logState.lines; }
            const size_t start = snapshot.size() > 4 ? snapshot.size() - 4 : 0;
            for (size_t i = start; i < snapshot.size(); ++i) ImGui::TextWrapped("• %s", snapshot[i].c_str());
            ImGui::EndChild();
        }
        ImGui::End();

        ImGui::Render();
        glViewport(0, 0, displayW, displayH);
        glClearColor(0.035f, 0.055f, 0.065f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        SDL_GL_SwapWindow(window);
        SDL_Delay(1);
    }

    camera.stop();
    stopWorker.store(true);
    inferenceCv.notify_all();
    if (inferenceThread.joinable()) inferenceThread.join();
    if (cameraTexture) glDeleteTextures(1, &cameraTexture);
    if (mapTexture) glDeleteTextures(1, &mapTexture);
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    SDL_GL_DeleteContext(glContext);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
