# Состав комплекта Diplomka 2.7.4

## Корневая структура

- `app/` — Android NativeActivity, C++20/NDK, Camera2, UI, OpenCV, сессионный лог, разрешения, launcher icon resources.
- `raspberry_pi/` — самостоятельная программа C++ для Raspberry Pi 4B, камера CSI через `rpicam-vid`, UI SDL2/OpenGL ES, примеры CSV маршрута.
- `tests/` — portable C++ tests для фильтра направления и логгера.
- `docs/` — архитектура, паспорт проекта, статус, список задач, changelog, новая иконка.
- `build-astro-cpp.yml` — GitHub Actions для Android arm64-v8a.
- `VERSION.txt` — версии платформ.
- `THIRD_PARTY_NOTICES.md` — сторонние компоненты.

## Файлы, которые выдаются отдельно

- `Diplomka_Android_2.7.4_Source.zip` — Gradle Android project и связанные docs/tests.
- `Diplomka_Native_CPP_Source_2.7.4.zip` — полный source archive Android + Raspberry Pi.
- `build-astro-cpp-2.7.4.yml` — workflow отдельно.
- `Diplomka_Android_2.7.4_GitHub_Kit.zip` — source ZIP с ожидаемым workflow именем и сам workflow, готовый для загрузки в репозиторий двумя файлами.
- `Diplomka_2.7.4_FULL_PROJECT.zip` — текущий полный проект, документы и материалы в одном архиве.

## GitHub: загрузка Android

1. Распаковать `Diplomka_Android_2.7.4_GitHub_Kit.zip`.
2. Загрузить `Diplomka_Native_CPP_Source.zip` в корень репозитория.
3. Загрузить `build-astro-cpp.yml` в `.github/workflows/build-astro-cpp.yml`.
4. Открыть Actions, выбрать `Build Diplomka Native C++ APK · 2.7.4`, запустить `Run workflow`.
5. После успешной сборки скачать `Diplomka-Android-APK-2.7.4` из Artifacts.

APK не вложен в исходный комплект. Полная Android сборка 2.7.4 в данной среде не запускалась.


## Сохранность GitHub репозитория

Workflow имеет только `contents: read` и после сборки не удаляет файлы, не создаёт cleanup-коммит и не очищает корень репозитория. Архив исходников остаётся на месте и может использоваться для следующих запусков.
